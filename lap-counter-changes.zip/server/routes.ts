import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import multer from "multer";
import { unlink } from "fs/promises";
import { DEFAULT_SCENES_DATA } from "./default-scenes-data";
import { z } from "zod";
import QRCode from "qrcode";
import { storage } from "./storage";
import { FileStorage } from "./file-storage";
import { lynxListener } from "./lynx-listener";
import { getResulTVParser } from "./parsers/resultv-parser";
import { mergeFlightsForEvent, type MergedFieldStandings } from "./parsers/lff-parser";
import type { TrackDisplayMode, FieldDisplayMode, LynxPortType, MeetLiveState, Meet, FieldEventUpdatePayload } from "@shared/schema";
import {
  isHeightEvent,
  insertEventSchema,
  insertAthleteSchema,
  insertEntrySchema,
  insertMeetSchema,
  insertSeasonSchema,
  insertTeamSchema,
  insertDivisionSchema,
  insertDisplayThemeSchema,
  insertBoardConfigSchema,
  insertDisplayLayoutSchema,
  insertLayoutCellSchema,
  insertCompositeLayoutSchema,
  insertLayoutZoneSchema,
  updateLayoutZoneSchema,
  insertLayoutSceneSchema,
  insertLayoutObjectSchema,
  insertRecordBookSchema,
  insertRecordSchema,
  insertMeetScoringProfileSchema,
  insertEventSplitConfigSchema,
  insertEntrySplitSchema,
  insertWindReadingSchema,
  insertFieldAttemptSchema,
  insertJudgeTokenSchema,
  insertSponsorSchema,
  insertSponsorAssignmentSchema,
  insertSponsorRotationProfileSchema,
  insertCombinedEventSchema,
  insertCombinedEventComponentSchema,
  overlayConfigSchema,
  insertWeatherConfigSchema,
  insertFieldEventSessionSchema,
  insertFieldHeightSchema,
  insertFieldEventFlightSchema,
  insertFieldEventAthleteSchema,
  insertFieldEventMarkSchema,
  insertExternalScoreboardSchema,
  type DisplayBoardState,
  type WSMessage,
  type EntrySplit,
  type FieldAttempt,
  type SelectSponsor,
} from "@shared/schema";
import { importCompleteMDB } from "./import-mdb-complete";
import { generateEventCSV, generateMeetCSV } from "./export-utils";
import { ingestLIFResults } from "./finishlynx-ingestion";
// ARCHIVED: Certificate generation feature
// import { generateCertificatePDF, type CertificateData } from './certificate-generator';
import { startWeatherPolling, stopWeatherPolling } from './weather-poller';
import archiver from 'archiver';
import syncRouter from './sync/routes';
import { 
  calculateHorizontalStandings, 
  calculateVerticalStandings,
  isEliminatedVertical 
} from './field-standings';
import { exportSessionToLFF, generateLFFContent } from './lff-exporter';
import { syncAthletesFromEVT, startEVTWatcher, stopEVTWatcher, initEVTWatchers } from './evt-watcher';
import { parseEVTDirectory, getAthletesFromDirectory, type EVTEventSummary, type EVTAthlete } from './evt-parser';
import { 
  startTrackHeatWatcher, 
  stopTrackHeatWatcher, 
  getTotalHeatsFromCache,
  getTotalHeatsFromAnyWatcher,
  getAllHeatCountsForMeet,
  getActiveTrackHeatWatchers,
  setHeatCountBroadcastCallback,
  type HeatCountData 
} from './track-heat-watcher';
import { startHytekMdbWatcher, stopHytekMdbWatcher, getActiveHytekMdbWatchers, loadHytekMdbConfigs, saveHytekMdbConfigs, triggerManualImport, setHytekImportCallback } from './hytek-mdb-watcher';
import { externalScoreboardService, buildFieldScoreboardPayload } from './external-scoreboard-service';
import * as fs from 'fs';
import * as path from 'path';
import { APP_VERSION, VERSION_DATE, RELEASE_NOTES } from '@shared/version';

function abbreviateEventName(name: string): string {
  const n = name.trim();
  const tail = '(\\s+(Dash|Run|Race))?';

  if (/Shuttle\s+Hurdle\s+Relay/i.test(n)) return 'SHR';
  if (/Distance\s+Medley\s+Relay|^DMR$/i.test(n)) return 'DMR';
  if (/Sprint\s+Medley\s+Relay|^SMR$/i.test(n)) return 'SMR';

  if (/4\s*x\s*100/i.test(n)) return '4x1';
  if (/4\s*x\s*200/i.test(n)) return '4x2';
  if (/4\s*x\s*400/i.test(n)) return '4x4';
  if (/4\s*x\s*800/i.test(n)) return '4x8';

  if (new RegExp('^(2[,.]?000|2000)\\s*m?(eters?)?\\s+(Steeplechase|SC)', 'i').test(n)) return '2KSC';
  if (new RegExp('^(3[,.]?000|3000)\\s*m?(eters?)?\\s+(Steeplechase|SC)', 'i').test(n)) return '3KSC';

  if (new RegExp('^55\\s*m?(eters?)?\\s*H(urdles)?' + tail + '$', 'i').test(n)) return '55H';
  if (new RegExp('^60\\s*m?(eters?)?\\s*H(urdles)?' + tail + '$', 'i').test(n)) return '60H';
  if (new RegExp('^100\\s*m?(eters?)?\\s*H(urdles)?' + tail + '$', 'i').test(n)) return '100H';
  if (new RegExp('^110\\s*m?(eters?)?\\s*H(urdles)?' + tail + '$', 'i').test(n)) return '110H';
  if (new RegExp('^300\\s*m?(eters?)?\\s*H(urdles)?' + tail + '$', 'i').test(n)) return '300H';
  if (new RegExp('^400\\s*m?(eters?)?\\s*H(urdles)?' + tail + '$', 'i').test(n)) return '400H';

  if (new RegExp('^55\\s*(Meters?|m)?' + tail + '$', 'i').test(n)) return '55';
  if (new RegExp('^60\\s*(Meters?|m)?' + tail + '$', 'i').test(n)) return '60';
  if (new RegExp('^100\\s*(Meters?|m)?' + tail + '$', 'i').test(n)) return '100';
  if (new RegExp('^200\\s*(Meters?|m)?' + tail + '$', 'i').test(n)) return '200';
  if (new RegExp('^300\\s*(Meters?|m)?' + tail + '$', 'i').test(n)) return '300';
  if (new RegExp('^400\\s*(Meters?|m)?' + tail + '$', 'i').test(n)) return '400';
  if (new RegExp('^500\\s*(Meters?|m)?' + tail + '$', 'i').test(n)) return '500';
  if (new RegExp('^600\\s*(Meters?|m)?' + tail + '$', 'i').test(n)) return '600';
  if (new RegExp('^800\\s*(Meters?|m)?' + tail + '$', 'i').test(n)) return '800';
  if (new RegExp('^(1[,.]?000|1000)\\s*(Meters?|m)?' + tail + '$', 'i').test(n)) return '1K';
  if (new RegExp('^(1[,.]?500|1500)\\s*(Meters?|m)?' + tail + '$', 'i').test(n)) return '1500';
  if (new RegExp('^(1[,.]?600|1600)\\s*(Meters?|m)?' + tail + '$', 'i').test(n)) return '1600';
  if (/^(1\s+)?Mile$/i.test(n)) return 'MILE';
  if (new RegExp('^(3[,.]?000|3000)\\s*(Meters?|m)?' + tail + '$', 'i').test(n)) return '3K';
  if (new RegExp('^(3[,.]?200|3200)\\s*(Meters?|m)?' + tail + '$', 'i').test(n)) return '3200';
  if (new RegExp('^(5[,.]?000|5000)\\s*(Meters?|m)?' + tail + '$', 'i').test(n)) return '5K';
  if (new RegExp('^(10[,.]?000|10000)\\s*(Meters?|m)?' + tail + '$', 'i').test(n)) return '10K';

  if (/High\s+Jump|^HJ$/i.test(n)) return 'HJ';
  if (/Pole\s+Vault|^PV$/i.test(n)) return 'PV';
  if (/Long\s+Jump|^LJ$/i.test(n)) return 'LJ';
  if (/Triple\s+Jump|^TJ$/i.test(n)) return 'TJ';
  if (/Shot\s+Put|^SP$/i.test(n)) return 'SP';
  if (/Discus/i.test(n)) return 'DIS';
  if (/Javelin/i.test(n)) return 'JAV';
  if (/Hammer/i.test(n)) return 'HT';
  if (/Weight\s+Throw|^WT$/i.test(n)) return 'WT';

  if (/Decathlon/i.test(n)) return 'DEC';
  if (/Heptathlon/i.test(n)) return 'HEP';
  if (/Pentathlon/i.test(n)) return 'PEN';

  const rwMatch = n.match(/^(\d+[,.]?\d*)\s*(km|k|m)?\s*Race\s+Walk$/i);
  if (rwMatch) {
    const rawDist = rwMatch[1].replace(/[,.]/g, '');
    const unit = (rwMatch[2] || '').toLowerCase();
    const num = parseInt(rawDist, 10);
    if (unit === 'km' || unit === 'k') return num + 'KRW';
    if (num >= 1000) return Math.round(num / 1000) + 'KRW';
    return num + 'RW';
  }
  if (/Race\s+Walk/i.test(n)) return 'RW';

  return n.length > 8 ? n.substring(0, 8) : n;
}

// Check-in validation schemas
const checkInSchema = z.object({
  operator: z.string().min(1),
  method: z.string().default('manual')
});

const bulkCheckInSchema = z.object({
  entryIds: z.array(z.string().uuid()).min(1),
  operator: z.string().min(1),
  method: z.string().default('bulk')
});

// Overlay validation schemas
const overlayUpdateSchema = z.object({
  overlayType: z.enum(['lower-third', 'scorebug', 'athlete-spotlight', 'team-standings']),
  data: z.object({
    meetId: z.string().optional(),
    eventId: z.string().optional(),
    athleteId: z.string().optional(),
    teamId: z.string().optional()
  })
});

const overlayHideSchema = z.object({
  overlayType: z.enum(['lower-third', 'scorebug', 'athlete-spotlight', 'team-standings'])
});

// Track connected WebSocket clients
const displayClients = new Set<WebSocket>();

// Track display devices with their WebSocket connections
interface ConnectedDisplayDevice {
  ws: WebSocket;
  deviceId: string;
  deviceName: string;
  meetId: string;
  displayType: string;
  autoMode: boolean; // Auto-switching based on Lynx timing data
  pagingSize: number; // Number of results per page (1-20)
  pagingInterval: number; // Seconds between page scrolls (1-60)
}
const connectedDisplayDevices = new Map<string, ConnectedDisplayDevice>();

// Track field event session subscribers (sessionId -> Set of WebSocket clients)
const fieldSessionSubscribers = new Map<number, Set<WebSocket>>();

// Map template names to display modes (for manual mode scene lookup)
function getDisplayModeFromTemplate(template: string): string | null {
  const templateLower = template.toLowerCase().replace(/-/g, '_');
  if (templateLower.includes('start_list')) return 'start_list';
  if (templateLower.includes('running_time')) return 'running_time';
  if (templateLower.includes('track_results') || (templateLower.includes('results') && !templateLower.includes('field'))) return 'track_results';
  if (templateLower.includes('field_results')) return 'field_results';
  if (templateLower.includes('field_standings')) return 'field_standings';
  if (templateLower.includes('team_scores')) return 'team_scores';
  if (templateLower.includes('meet_logo')) return 'meet_logo';
  return null;
}

// Pre-fetch scene data for instant display switching (eliminates HTTP round-trips)
async function prefetchSceneData(sceneId: number): Promise<{ scene: any; objects: any[] } | null> {
  try {
    const scene = await storage.getLayoutScene(sceneId);
    if (!scene) return null;
    const objects = await storage.getLayoutObjects(sceneId);
    return { scene, objects };
  } catch (err) {
    console.error(`[Prefetch] Error loading scene ${sceneId}:`, err);
    return null;
  }
}

// Broadcast function - Layout switching is now controlled by FinishLynx via layout-command events
function broadcastToDisplays(message: WSMessage) {
  const messageStr = JSON.stringify(message);
  displayClients.forEach((client) => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(messageStr);
    }
  });
}

// Send targeted message to a specific display device
function sendToDisplayDevice(deviceId: string, message: WSMessage) {
  const device = connectedDisplayDevices.get(deviceId);
  if (device && device.ws.readyState === WebSocket.OPEN) {
    device.ws.send(JSON.stringify(message));
    return true;
  }
  return false;
}

// Get list of connected display devices for a meet
function getConnectedDevicesForMeet(meetId: string): string[] {
  const devices: string[] = [];
  connectedDisplayDevices.forEach((device, id) => {
    if (device.meetId === meetId) {
      devices.push(id);
    }
  });
  return devices;
}

// Get the active meet ID from connected displays (for Lynx heat count lookup)
// Returns the meetId that has the most connected displays, or null if none connected
function getActiveMeetIdFromDisplays(): string | null {
  const meetCounts = new Map<string, number>();
  connectedDisplayDevices.forEach((device) => {
    if (device.meetId) {
      meetCounts.set(device.meetId, (meetCounts.get(device.meetId) || 0) + 1);
    }
  });
  
  // Return the meet with the most connected displays
  let activeMeetId: string | null = null;
  let maxCount = 0;
  meetCounts.forEach((count, meetId) => {
    if (count > maxCount) {
      maxCount = count;
      activeMeetId = meetId;
    }
  });
  
  return activeMeetId;
}

// Cached active meet ID from database (for local/edge mode without connected displays)
let cachedDbActiveMeetId: string | null = null;
let cachedDbActiveMeetTimestamp = 0;

// Get the active meet ID, preferring connected displays, then falling back to database
async function getActiveMeetId(): Promise<string | null> {
  // First try connected displays
  const fromDisplays = getActiveMeetIdFromDisplays();
  if (fromDisplays) return fromDisplays;
  
  // Fallback: get most recent in_progress or upcoming meet from database
  // Cache for 10 seconds to avoid hitting DB on every Lynx message
  const now = Date.now();
  if (cachedDbActiveMeetId && (now - cachedDbActiveMeetTimestamp) < 10000) {
    return cachedDbActiveMeetId;
  }
  
  try {
    const meets = await storage.getMeets();
    const activeMeet = meets.find(m => m.status === 'in_progress') 
      || meets.find(m => m.status === 'scheduled')
      || (meets.length > 0 ? meets[meets.length - 1] : null);
    cachedDbActiveMeetId = activeMeet?.id || null;
    cachedDbActiveMeetTimestamp = now;
    return cachedDbActiveMeetId;
  } catch (error) {
    return null;
  }
}

// Helper to broadcast current event state
async function broadcastCurrentEvent() {
  const currentEvent = await storage.getCurrentEvent();
  
  // Get the meet associated with the current event, or fall back to most recent active meet
  let meet: Meet | undefined;
  if (currentEvent?.meetId) {
    meet = await storage.getMeet(currentEvent.meetId);
  }
  
  // If no meet found from current event, get the most recent in_progress or upcoming meet
  if (!meet) {
    const meets = await storage.getMeets();
    meet = meets.find(m => m.status === 'in_progress') 
        || meets.find(m => m.status === 'upcoming')
        || meets[0];
  }

  const boardState: DisplayBoardState = {
    mode: "live",
    currentEvent,
    meet,
    timestamp: Date.now(),
  };

  broadcastToDisplays({
    type: "board_update",
    data: boardState,
  });
}

// Broadcast field event update to subscribers and all displays
// deviceName is optional - used for device-specific scoreboard routing
async function broadcastFieldEventUpdate(sessionId: number, deviceName?: string) {
  try {
    const session = await storage.getFieldEventSessionWithDetails(sessionId);
    if (!session) {
      console.log(`[Field Broadcast] Session ${sessionId} not found`);
      return;
    }

    const event = await storage.getEvent(session.eventId);
    if (!event) {
      console.log(`[Field Broadcast] Event ${session.eventId} not found`);
      return;
    }

    const isVertical = isHeightEvent(event.eventType);
    
    let standings: any[] = [];
    if (session.athletes && session.marks) {
      if (isVertical && session.heights) {
        standings = calculateVerticalStandings(
          session.athletes as any,
          session.marks,
          session.heights
        );
      } else {
        standings = calculateHorizontalStandings(
          session.athletes as any,
          session.marks
        );
      }
    }

    // Get actual athlete ID from the current index (null if no current athlete)
    let currentAthleteId: number | null = null;
    const currentAthleteIndex = session.currentAthleteIndex;
    if (currentAthleteIndex !== null && currentAthleteIndex !== undefined && 
        session.athletes && currentAthleteIndex >= 0 && currentAthleteIndex < session.athletes.length) {
      currentAthleteId = session.athletes[currentAthleteIndex]?.id ?? null;
    }

    const update: FieldEventUpdatePayload = {
      athletes: session.athletes || [],
      marks: session.marks || [],
      heights: session.heights,
      standings: standings,
      currentAthleteId: currentAthleteId,
      currentAttempt: session.currentAttemptNumber,
      currentHeight: isVertical ? session.currentHeightIndex : undefined,
      sessionStatus: session.status,
      eventType: isVertical ? 'vertical' : 'horizontal'
    };

    const message: WSMessage = {
      type: 'field_event_update',
      sessionId: sessionId,
      eventId: session.eventId,
      meetId: event.meetId,
      update
    };

    // Broadcast to session-specific subscribers
    const subscribers = fieldSessionSubscribers.get(sessionId);
    if (subscribers) {
      const messageStr = JSON.stringify(message);
      subscribers.forEach(client => {
        if (client.readyState === WebSocket.OPEN) {
          client.send(messageStr);
        }
      });
      console.log(`[Field Broadcast] Session ${sessionId}: sent to ${subscribers.size} subscribers`);
    }

    // Also broadcast to all display clients
    broadcastToDisplays(message);
    console.log(`[Field Broadcast] Session ${sessionId}: broadcast complete`);

    // Send to external scoreboards
    try {
      const lastMark = session.marks && session.marks.length > 0
        ? session.marks.sort((a, b) => 
            new Date(b.recordedAt || 0).getTime() - new Date(a.recordedAt || 0).getTime()
          )[0]
        : null;

      const scoreboardPayload = buildFieldScoreboardPayload(session, currentAthleteId, lastMark);
      scoreboardPayload.deviceName = deviceName;
      await externalScoreboardService.sendToSession(sessionId, scoreboardPayload, deviceName);
      console.log(`[Field Broadcast] Session ${sessionId}: sent to external scoreboards (device: ${deviceName || 'all'})`);
    } catch (extError) {
      console.error(`[Field Broadcast] Error sending to external scoreboards:`, extError);
    }
  } catch (error) {
    console.error(`[Field Broadcast] Error broadcasting session ${sessionId}:`, error);
  }
}

// Auto-export LFF file after every mark change if export path is configured
async function autoExportLFF(sessionId: number) {
  try {
    const session = await storage.getFieldEventSessionWithDetails(sessionId);
    if (!session || !session.lffExportPath) {
      return; // No export path configured, skip auto-export
    }
    
    const measurementSystem = (session.measurementUnit === 'english' ? 'English' : 'Metric') as 'Metric' | 'English';
    
    const filePath = await exportSessionToLFF(session, {
      outputDir: session.lffExportPath,
      measurementSystem
    });
    
    console.log(`[LFF Auto-Export] Session ${sessionId}: exported to ${filePath}`);
  } catch (error) {
    console.error(`[LFF Auto-Export] Error exporting session ${sessionId}:`, error);
  }
}

// Load default scenes template from embedded data (baked into the code)
let defaultScenesTemplate: { scenes: any[]; sceneMappings?: any[] } | null = null;
function loadDefaultScenesTemplate(): { scenes: any[]; sceneMappings?: any[] } | null {
  if (defaultScenesTemplate !== null) {
    return defaultScenesTemplate;
  }
  
  // Use embedded data - no file reading required
  defaultScenesTemplate = { 
    scenes: DEFAULT_SCENES_DATA.scenes as any[] || [],
    sceneMappings: DEFAULT_SCENES_DATA.sceneMappings as any[] || [],
  };
  console.log(`✅ Loaded ${defaultScenesTemplate.scenes.length} default scene templates with ${defaultScenesTemplate.sceneMappings?.length || 0} mappings (embedded)`);
  return defaultScenesTemplate;
}

// Seed default scenes for a new meet
async function seedDefaultScenes(meetId: string): Promise<number> {
  const template = loadDefaultScenesTemplate();
  if (!template || template.scenes.length === 0) {
    return 0;
  }
  
  // Map to track scene name -> new scene ID for mapping creation
  const sceneNameToId: Record<string, number> = {};
  
  let seededCount = 0;
  for (const sceneData of template.scenes) {
    const { objects, id: _id, meetId: _meetId, createdAt: _createdAt, updatedAt: _updatedAt, ...sceneFields } = sceneData;
    
    const newScene = await storage.createLayoutScene({
      ...sceneFields,
      meetId: meetId,
    });
    
    // Track scene name to new ID mapping
    sceneNameToId[newScene.name] = newScene.id;
    
    // Create objects for this scene
    if (objects && Array.isArray(objects)) {
      for (const objData of objects) {
        const { id: _objId, sceneId: _sceneId, createdAt: _objCreated, ...objectFields } = objData;
        await storage.createLayoutObject({
          ...objectFields,
          sceneId: newScene.id,
        });
      }
    }
    seededCount++;
  }
  
  // Create scene template mappings
  if (template.sceneMappings && Array.isArray(template.sceneMappings)) {
    for (const mapping of template.sceneMappings) {
      const sceneId = sceneNameToId[mapping.sceneName];
      if (sceneId) {
        await storage.setSceneTemplateMapping({
          meetId: meetId,
          displayType: mapping.displayType,
          displayMode: mapping.displayMode,
          sceneId: sceneId,
        });
      }
    }
    console.log(`✅ Seeded ${template.sceneMappings.length} scene template mappings for meet ${meetId}`);
  }
  
  console.log(`✅ Seeded ${seededCount} default scenes for meet ${meetId}`);
  return seededCount;
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Configure multer for file uploads (disk storage for large files like MDB)
  const upload = multer({
    dest: "uploads/",
    limits: {
      fileSize: 50 * 1024 * 1024, // 50MB limit
    },
  });

  // Configure multer for image uploads (memory storage for processing)
  const imageUpload = multer({
    storage: multer.memoryStorage(),
    limits: {
      fileSize: 10 * 1024 * 1024, // 10MB limit for images
    },
    fileFilter: (req, file, cb) => {
      const allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
      if (allowedTypes.includes(file.mimetype)) {
        cb(null, true);
      } else {
        cb(new Error('Invalid file type. Only JPEG, PNG, and GIF are allowed.'));
      }
    },
  });

  // Initialize FileStorage for photo/logo management
  const fileStorage = new FileStorage();

  // Register sync routes for edge-cloud synchronization
  app.use('/api/sync', syncRouter);

  // ===== VERSION API =====
  // Version endpoint for Edge Mode update checking
  app.get("/api/version", (req, res) => {
    res.json({
      version: APP_VERSION,
      date: VERSION_DATE,
      releaseNotes: RELEASE_NOTES,
      edgeMode: process.env.EDGE_MODE === 'true',
    });
  });

  // Edge config endpoint - returns cloud URL for update checking
  app.get("/api/edge-config", (req, res) => {
    try {
      const configPath = './data/edge-config.json';
      if (fs.existsSync(configPath)) {
        const config = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
        res.json({ cloudUrl: config.cloudUrl || '', edgeId: config.edgeId || '' });
      } else {
        res.json({ cloudUrl: '', edgeId: '' });
      }
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.put("/api/edge-config", (req, res) => {
    try {
      const { cloudUrl } = req.body;
      const configPath = './data/edge-config.json';
      const dataDir = './data';
      
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }
      
      let config: any = {};
      if (fs.existsSync(configPath)) {
        config = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
      }
      
      config.cloudUrl = cloudUrl || '';
      fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
      res.json({ success: true, cloudUrl: config.cloudUrl });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // ===== CLOUD SYNC API =====
  // Preview a meet from cloud before downloading
  app.post("/api/cloud-sync/preview", async (req, res) => {
    try {
      const { cloudSyncPreviewSchema, CloudSyncError } = await import('./cloud-sync');
      
      // Validate request body
      const validation = cloudSyncPreviewSchema.safeParse(req.body);
      if (!validation.success) {
        const errorMessages = validation.error.errors
          .map(err => `${err.path.join('.')}: ${err.message}`)
          .join('; ');
        return res.status(400).json({ 
          error: `Invalid request: ${errorMessages}`,
          details: validation.error.errors
        });
      }
      
      const { cloudUrl, meetCode } = validation.data;
      const { previewCloudMeet } = await import('./cloud-sync');
      
      try {
        const result = await previewCloudMeet(cloudUrl, meetCode);
        res.json(result);
      } catch (error: any) {
        // Handle CloudSyncError with proper status codes
        if (error instanceof CloudSyncError) {
          const statusCode = error.statusCode || 500;
          return res.status(statusCode).json({ 
            error: error.message,
            ...(error.details && { details: error.details })
          });
        }
        throw error;
      }
    } catch (error: any) {
      console.error('[Cloud Sync Preview Error]', error);
      res.status(500).json({ error: 'Internal server error while previewing meet' });
    }
  });

  // Download a meet from cloud
  app.post("/api/cloud-sync/download", async (req, res) => {
    try {
      const { cloudSyncDownloadSchema, CloudSyncError } = await import('./cloud-sync');
      
      // Validate request body
      const validation = cloudSyncDownloadSchema.safeParse(req.body);
      if (!validation.success) {
        const errorMessages = validation.error.errors
          .map(err => `${err.path.join('.')}: ${err.message}`)
          .join('; ');
        return res.status(400).json({ 
          error: `Invalid request: ${errorMessages}`,
          details: validation.error.errors
        });
      }
      
      const { cloudUrl, meetCode } = validation.data;
      const { syncFromCloud } = await import('./cloud-sync');
      
      try {
        const result = await syncFromCloud(cloudUrl, meetCode);
        
        if (result.success) {
          res.json(result);
        } else {
          // Check if this is a user error (4xx) or server error (5xx)
          // Based on the error message, determine appropriate status code
          const error = result.error || '';
          let statusCode = 500;
          
          if (error.includes('not found') || error.includes('Meet with code')) {
            statusCode = 404;
          } else if (error.includes('Invalid') || error.includes('Failed to connect')) {
            statusCode = 400;
          }
          
          res.status(statusCode).json({ error: result.error });
        }
      } catch (error: any) {
        // Handle CloudSyncError with proper status codes
        if (error instanceof CloudSyncError) {
          const statusCode = error.statusCode || 500;
          return res.status(statusCode).json({ 
            error: error.message,
            ...(error.details && { details: error.details })
          });
        }
        throw error;
      }
    } catch (error: any) {
      console.error('[Cloud Sync Download Error]', error);
      res.status(500).json({ error: 'Internal server error while syncing meet' });
    }
  });

  // ===== MEET PACKAGE API (Dropbox sync) =====
  
  // List available meet packages
  app.get("/api/meet-packages", async (req, res) => {
    try {
      const { listMeetPackages } = await import('./meet-package');
      const packages = await listMeetPackages();
      res.json(packages);
    } catch (error: any) {
      console.error('[Meet Packages List Error]', error);
      res.status(500).json({ error: error.message });
    }
  });

  // Export a meet to a package
  app.post("/api/meet-packages/export/:meetId", async (req, res) => {
    try {
      const { exportMeetPackage } = await import('./meet-package');
      const result = await exportMeetPackage(req.params.meetId);
      
      if (result.success) {
        res.json(result);
      } else {
        res.status(400).json({ error: result.error });
      }
    } catch (error: any) {
      console.error('[Meet Package Export Error]', error);
      res.status(500).json({ error: error.message });
    }
  });

  // Import a meet from a package
  app.post("/api/meet-packages/import/:packageName", async (req, res) => {
    try {
      const { importMeetPackage } = await import('./meet-package');
      const result = await importMeetPackage(req.params.packageName);
      
      if (result.success) {
        res.json(result);
      } else {
        res.status(400).json({ error: result.error });
      }
    } catch (error: any) {
      console.error('[Meet Package Import Error]', error);
      res.status(500).json({ error: error.message });
    }
  });

  // Delete a meet package
  app.delete("/api/meet-packages/:packageName", async (req, res) => {
    try {
      const { deleteMeetPackage } = await import('./meet-package');
      const result = await deleteMeetPackage(req.params.packageName);
      
      if (result.success) {
        res.json({ success: true });
      } else {
        res.status(400).json({ error: result.error });
      }
    } catch (error: any) {
      console.error('[Meet Package Delete Error]', error);
      res.status(500).json({ error: error.message });
    }
  });

  // ===== PUBLIC SPECTATOR API =====

  // Get current meet (public info only)
  app.get("/api/public/current-meet", async (req, res) => {
    try {
      const meets = await storage.getMeets();
      // Prefer in_progress meet, then upcoming, then most recent
      const currentMeet = meets.find(m => m.status === 'in_progress') 
                       || meets.find(m => m.status === 'upcoming')
                       || (meets.length > 0 ? meets[0] : null);
      
      if (!currentMeet) {
        return res.status(404).json({ error: "No active meet" });
      }
      
      res.json({
        id: currentMeet.id,
        name: currentMeet.name,
        startDate: currentMeet.startDate,
        endDate: currentMeet.endDate,
        location: currentMeet.location
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get events for spectator view
  app.get("/api/public/meets/:meetId/events", async (req, res) => {
    try {
      const events = await storage.getEventsByMeetId(req.params.meetId);
      
      const publicEvents = events.map(e => ({
        id: e.id,
        name: e.name,
        eventType: e.eventType,
        gender: e.gender,
        status: e.status,
        eventTime: e.eventTime
      }));
      
      res.json(publicEvents);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get event results (with athlete info)
  app.get("/api/public/events/:eventId/results", async (req, res) => {
    try {
      const event = await storage.getEventWithEntries(req.params.eventId);
      
      if (!event) {
        return res.status(404).json({ error: "Event not found" });
      }
      
      const results = event.entries.map(entry => ({
        id: entry.id,
        athleteName: entry.athlete ? `${entry.athlete.firstName} ${entry.athlete.lastName}` : "Unknown",
        athleteId: entry.athlete?.id,
        teamName: entry.team?.name,
        bibNumber: entry.athlete?.bibNumber,
        finalPlace: entry.finalPlace,
        finalMark: entry.finalMark
      })).sort((a, b) => (a.finalPlace || 999) - (b.finalPlace || 999));
      
      res.json({
        event: {
          id: event.id,
          name: event.name,
          eventType: event.eventType,
          status: event.status
        },
        results
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get team standings split by gender with logo URLs
  app.get("/api/public/meets/:meetId/team-standings", async (req, res) => {
    try {
      const meetId = req.params.meetId;
      const [menStandings, womenStandings] = await Promise.all([
        storage.getTeamStandings(meetId, { gender: "M" }),
        storage.getTeamStandings(meetId, { gender: "W" }),
      ]);

      res.json({
        men: menStandings,
        women: womenStandings,
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get medal standings
  app.get("/api/public/meets/:meetId/medal-standings", async (req, res) => {
    try {
      const standings = await storage.getMedalStandings(req.params.meetId);
      res.json(standings);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get athletes (public info only)
  app.get("/api/public/meets/:meetId/athletes", async (req, res) => {
    try {
      const athletes = await storage.getAthletesByMeetId(req.params.meetId);
      
      const publicAthletes = await Promise.all(athletes.map(async (a) => {
        const team = a.teamId ? await storage.getTeam(a.teamId) : null;
        return {
          id: a.id,
          firstName: a.firstName,
          lastName: a.lastName,
          bibNumber: a.bibNumber,
          teamId: a.teamId,
          teamName: team?.name
        };
      }));
      
      res.json(publicAthletes);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get single athlete details
  app.get("/api/public/athletes/:athleteId", async (req, res) => {
    try {
      const athlete = await storage.getAthlete(req.params.athleteId);
      
      if (!athlete) {
        return res.status(404).json({ error: "Athlete not found" });
      }
      
      let photoUrl = null;
      try {
        const photo = await storage.getAthletePhoto(athlete.id);
        if (photo?.storageKey) {
          photoUrl = fileStorage.publicUrlForKey(photo.storageKey);
        }
      } catch (e) {
        // Photo not available
      }
      
      const team = athlete.teamId ? await storage.getTeam(athlete.teamId) : null;
      
      res.json({
        id: athlete.id,
        firstName: athlete.firstName,
        lastName: athlete.lastName,
        bibNumber: athlete.bibNumber,
        teamName: team?.name,
        photoUrl
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Events
  app.get("/api/events", async (req, res) => {
    try {
      const { meetId } = req.query;
      if (meetId) {
        const events = await storage.getEventsByMeetId(meetId as string);
        return res.json(events);
      }
      const events = await storage.getEvents();
      res.json(events);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/events/current", async (req, res) => {
    const event = await storage.getCurrentEvent();
    if (!event) {
      return res.status(404).json({ error: "No current event" });
    }
    res.json(event);
  });

  app.get("/api/events/:id", async (req, res) => {
    const event = await storage.getEvent(req.params.id);
    if (!event) {
      return res.status(404).json({ error: "Event not found" });
    }
    res.json(event);
  });

  app.post("/api/events", async (req, res) => {
    try {
      const data = insertEventSchema.parse(req.body);
      const event = await storage.createEvent(data);
      await broadcastCurrentEvent();
      res.json(event);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.patch("/api/events/:id/status", async (req, res) => {
    try {
      const { status } = req.body;
      const event = await storage.updateEventStatus(req.params.id, status);
      if (!event) {
        return res.status(404).json({ error: "Event not found" });
      }
      await broadcastCurrentEvent();
      res.json(event);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.patch("/api/events/:id", async (req, res) => {
    try {
      const existing = await storage.getEvent(req.params.id);
      if (!existing) {
        return res.status(404).json({ error: "Event not found" });
      }
      const allowedFields = ['name', 'advanceByPlace', 'advanceByTime', 'hytekStatus', 'isScored', 'status', 'numRounds', 'numLanes'];
      const updates: Record<string, any> = {};
      for (const field of allowedFields) {
        if (req.body[field] !== undefined) {
          updates[field] = req.body[field];
        }
      }
      if (Object.keys(updates).length === 0) {
        return res.status(400).json({ error: "No valid fields to update" });
      }
      const event = await storage.updateEvent(req.params.id, updates);
      if (!event) {
        return res.status(404).json({ error: "Event not found" });
      }
      await broadcastCurrentEvent();
      res.json(event);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.get("/api/events/:id/entries", async (req, res) => {
    const eventWithEntries = await storage.getEventWithEntries(req.params.id);
    if (!eventWithEntries) {
      return res.status(404).json({ error: "Event not found" });
    }
    res.json(eventWithEntries);
  });

  // Export endpoints for events
  app.get("/api/events/:id/export", async (req, res) => {
    try {
      const { format } = req.query;
      
      // Only support CSV - print/PDF use React routes
      if (format !== 'csv') {
        return res.status(400).json({ error: 'Only CSV format supported. Use /print/events/:id for printing.' });
      }
      
      const eventWithEntries = await storage.getEventWithEntries(req.params.id);
      
      if (!eventWithEntries) {
        return res.status(404).json({ error: "Event not found" });
      }
      
      const csv = generateEventCSV(eventWithEntries);
      const filename = `${eventWithEntries.name.replace(/\s+/g, '-')}-results.csv`;
      
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      res.send(csv);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Athletes
  app.get("/api/athletes", async (req, res) => {
    try {
      const { meetId, search } = req.query;
      let athletes;
      if (meetId) {
        athletes = await storage.getAthletesByMeetId(meetId as string);
        // Get teams to include team names
        const teams = await storage.getTeamsByMeetId(meetId as string);
        const teamMap = new Map(teams.map(t => [t.id, t.name]));
        let athletesWithTeams = athletes.map(a => ({
          ...a,
          teamName: a.teamId ? teamMap.get(a.teamId) || null : null
        }));
        
        // Filter by search if provided
        if (search && typeof search === 'string' && search.trim()) {
          const searchLower = search.toLowerCase().trim();
          athletesWithTeams = athletesWithTeams.filter(a => {
            const fullName = `${a.firstName || ''} ${a.lastName || ''}`.toLowerCase();
            const bibNumber = (a.bibNumber || '').toLowerCase();
            return fullName.includes(searchLower) || bibNumber.includes(searchLower);
          });
        }
        
        return res.json(athletesWithTeams);
      }
      athletes = await storage.getAthletes();
      
      // Filter by search if provided
      if (search && typeof search === 'string' && search.trim()) {
        const searchLower = search.toLowerCase().trim();
        athletes = athletes.filter(a => {
          const fullName = `${a.firstName || ''} ${a.lastName || ''}`.toLowerCase();
          const bibNumber = (a.bibNumber || '').toLowerCase();
          return fullName.includes(searchLower) || bibNumber.includes(searchLower);
        });
      }
      
      res.json(athletes);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/athletes/:id", async (req, res) => {
    const athlete = await storage.getAthlete(req.params.id);
    if (!athlete) {
      return res.status(404).json({ error: "Athlete not found" });
    }
    res.json(athlete);
  });

  // Get events for an athlete
  app.get("/api/athletes/:id/events", async (req, res) => {
    try {
      const athlete = await storage.getAthlete(req.params.id);
      if (!athlete) {
        return res.status(404).json({ error: "Athlete not found" });
      }
      
      const entries = await storage.getEntriesByAthlete(req.params.id);
      
      // Extract unique events with entry details
      const eventsMap = new Map<string, { event: any; entry: any }>();
      for (const entry of entries) {
        if (entry.event && !eventsMap.has(entry.event.id)) {
          eventsMap.set(entry.event.id, {
            event: entry.event,
            entry: {
              id: entry.id,
              seedMark: entry.seedMark,
              finalMark: entry.finalMark,
              finalPlace: entry.finalPlace,
              isScratched: entry.isScratched,
              isDisqualified: entry.isDisqualified,
              checkInStatus: entry.checkInStatus,
              // Heat/Lane assignments (use most relevant round)
              heat: entry.finalHeat || entry.semifinalHeat || entry.quarterfinalHeat || entry.preliminaryHeat,
              lane: entry.finalLane || entry.semifinalLane || entry.quarterfinalLane || entry.preliminaryLane,
            }
          });
        }
      }
      
      // Sort by event number
      const events = Array.from(eventsMap.values())
        .sort((a, b) => (a.event.eventNumber || 0) - (b.event.eventNumber || 0));
      
      res.json(events);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/athletes", async (req, res) => {
    try {
      const data = insertAthleteSchema.parse(req.body);
      const athlete = await storage.createAthlete(data);
      res.json(athlete);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Entries (unified results for track and field)
  app.get("/api/entries", async (req, res) => {
    const entries = await storage.getEntries();
    res.json(entries);
  });

  app.get("/api/entries/event/:eventId", async (req, res) => {
    const entries = await storage.getEntriesByEvent(req.params.eventId);
    res.json(entries);
  });

  app.get("/api/entries/event/:eventId/details", async (req, res) => {
    const entries = await storage.getEntriesWithDetails(req.params.eventId);
    res.json(entries);
  });

  app.post("/api/entries", async (req, res) => {
    try {
      const data = insertEntrySchema.parse(req.body);
      const entry = await storage.createEntry(data);
      await broadcastCurrentEvent();
      res.json(entry);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.patch("/api/entries/:id", async (req, res) => {
    try {
      const entry = await storage.updateEntry(req.params.id, req.body);
      if (!entry) {
        return res.status(404).json({ error: "Entry not found" });
      }
      await broadcastCurrentEvent();
      res.json(entry);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Check-in endpoints
  app.post("/api/entries/:id/check-in", async (req, res) => {
    try {
      // Validate request body
      const validated = checkInSchema.parse(req.body);
      
      // Verify entry exists and get initial entry with full details
      const entry = await storage.getEntry(req.params.id);
      if (!entry) {
        return res.status(404).json({ error: "Entry not found" });
      }
      
      const updated = await storage.markCheckedIn(
        req.params.id, 
        validated.operator, 
        validated.method
      );
      
      // Broadcast full entry data
      broadcastToDisplays({
        type: 'check_in_update',
        meetId: entry.event.meetId,
        eventId: entry.eventId,
        entry: updated
      });
      
      res.json(updated);
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid request", details: error.errors });
      }
      res.status(400).json({ error: error.message });
    }
  });

  app.post("/api/events/:eventId/bulk-check-in", async (req, res) => {
    try {
      const validated = bulkCheckInSchema.parse(req.body);
      const event = await storage.getEvent(req.params.eventId);
      if (!event) {
        return res.status(404).json({ error: "Event not found" });
      }
      
      // SHORT-CIRCUIT: Verify ALL entries BEFORE any updates
      const invalidIds: string[] = [];
      
      for (const id of validated.entryIds) {
        const entry = await storage.getEntry(id);
        if (!entry || entry.eventId !== req.params.eventId) {
          invalidIds.push(id);
        }
      }
      
      if (invalidIds.length > 0) {
        return res.status(400).json({ 
          error: "Some entries do not belong to this event or do not exist",
          invalidIds,
          invalidCount: invalidIds.length
        });
      }
      
      // All entries valid, safe to update
      const updated = await storage.bulkCheckIn(
        validated.entryIds, 
        validated.operator, 
        validated.method
      );
      
      // Broadcast each updated entry
      for (const entry of updated) {
        broadcastToDisplays({
          type: 'check_in_update',
          meetId: event.meetId,
          eventId: event.id,
          entry
        });
      }
      
      res.json(updated);
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid request", details: error.errors });
      }
      res.status(400).json({ error: error.message });
    }
  });

  app.get("/api/events/:eventId/check-in-stats", async (req, res) => {
    try {
      const stats = await storage.getCheckInStats(req.params.eventId);
      res.json(stats);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Split Times
  app.get("/api/events/:eventId/splits/config", async (req, res) => {
    const configs = await storage.getSplitConfigs(req.params.eventId);
    res.json(configs);
  });

  app.put("/api/events/:eventId/splits/config", async (req, res) => {
    try {
      const event = await storage.getEvent(req.params.eventId);
      if (!event) {
        return res.status(404).json({ error: "Event not found" });
      }
      
      const validated = z.array(insertEventSplitConfigSchema).parse(req.body);
      const updated = await storage.updateSplitConfigs(event.eventType, event.meetId, validated);
      res.json(updated);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid request", details: error.errors });
      }
      throw error;
    }
  });

  app.post("/api/entries/:entryId/splits", async (req, res) => {
    try {
      const validated = insertEntrySplitSchema.parse(req.body);
      const entry = await storage.getEntry(req.params.entryId);
      if (!entry) {
        return res.status(404).json({ error: "Entry not found" });
      }
      
      const split = await storage.createEntrySplit({
        ...validated,
        entryId: req.params.entryId
      });
      
      const allSplits = await storage.getEntrySplits(entry.eventId);
      broadcastToDisplays({
        type: 'split_update',
        meetId: entry.event.meetId,
        eventId: entry.eventId,
        entryId: entry.id,
        splits: allSplits.get(entry.id) || []
      });
      
      res.json(split);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid request", details: error.errors });
      }
      throw error;
    }
  });

  app.post("/api/events/:eventId/splits/batch", async (req, res) => {
    try {
      const validated = z.array(insertEntrySplitSchema).parse(req.body);
      const event = await storage.getEvent(req.params.eventId);
      if (!event) {
        return res.status(404).json({ error: "Event not found" });
      }
      
      const splits = await storage.createEntrySplitsBatch(validated);
      
      const affectedEntryIds = [...new Set(splits.map(s => s.entryId))];
      const allSplits = await storage.getEntrySplits(event.id);
      
      for (const entryId of affectedEntryIds) {
        broadcastToDisplays({
          type: 'split_update',
          meetId: event.meetId,
          eventId: event.id,
          entryId,
          splits: allSplits.get(entryId) || []
        });
      }
      
      res.json(splits);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid request", details: error.errors });
      }
      throw error;
    }
  });

  app.get("/api/events/:eventId/splits", async (req, res) => {
    const splits = await storage.getEntrySplits(req.params.eventId);
    const obj: Record<string, EntrySplit[]> = {};
    splits.forEach((value, key) => { obj[key] = value; });
    res.json(obj);
  });

  app.delete("/api/entries/:entryId/splits/:splitIndex", async (req, res) => {
    const entry = await storage.getEntry(req.params.entryId);
    if (!entry) {
      return res.status(404).json({ error: "Entry not found" });
    }
    
    await storage.deleteEntrySplit(req.params.entryId, parseInt(req.params.splitIndex));
    
    const allSplits = await storage.getEntrySplits(entry.eventId);
    broadcastToDisplays({
      type: 'split_update',
      meetId: entry.event.meetId,
      eventId: entry.eventId,
      entryId: entry.id,
      splits: allSplits.get(entry.id) || []
    });
    
    res.status(204).send();
  });

  // Wind Readings
  app.post("/api/events/:eventId/wind-readings", async (req, res) => {
    try {
      const event = await storage.getEvent(req.params.eventId);
      if (!event) {
        return res.status(404).json({ error: "Event not found" });
      }
      
      // Validate wind speed is in reasonable range
      const validated = insertWindReadingSchema.extend({
        windSpeed: z.number().min(-5.0).max(9.9)
      }).parse(req.body);
      
      const reading = await storage.createWindReading({
        ...validated,
        eventId: req.params.eventId
      });
      
      // Broadcast update
      broadcastToDisplays({
        type: 'wind_update',
        meetId: event.meetId,
        eventId: event.id,
        reading
      });
      
      res.json(reading);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid request", details: error.errors });
      }
      throw error;
    }
  });

  app.get("/api/events/:eventId/wind-readings", async (req, res) => {
    const readings = await storage.getWindReadings(req.params.eventId);
    res.json(readings);
  });

  app.patch("/api/wind-readings/:id", async (req, res) => {
    try {
      const validated = z.object({
        windSpeed: z.number().min(-5.0).max(9.9)
      }).parse(req.body);
      
      const reading = await storage.updateWindReading(req.params.id, validated.windSpeed);
      
      // Get event to broadcast
      const eventId = reading.eventId;
      const event = await storage.getEvent(eventId);
      if (event) {
        broadcastToDisplays({
          type: 'wind_update',
          meetId: event.meetId,
          eventId: event.id,
          reading
        });
      }
      
      res.json(reading);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid request", details: error.errors });
      }
      throw error;
    }
  });

  app.delete("/api/wind-readings/:id", async (req, res) => {
    await storage.deleteWindReading(req.params.id);
    res.status(204).send();
  });

  // ARCHIVED: Judge token system

  // Validate judge token (login)
  app.post("/api/judge/login", async (req, res) => {
    try {
      const { code, pin } = z.object({
        code: z.string(),
        pin: z.string().optional()
      }).parse(req.body);
      
      const token = await storage.getJudgeToken(code);
      if (!token) {
        return res.status(401).json({ error: "Invalid code" });
      }
      
      if (token.pin && token.pin !== pin) {
        return res.status(401).json({ error: "Invalid PIN" });
      }
      
      res.json({ token, judgeId: token.id });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid request", details: error.errors });
      }
      throw error;
    }
  });

  // ===== FIELD ATTEMPTS =====

  // Create field attempt
  app.post("/api/field-attempts", async (req, res) => {
    try {
      const validated = insertFieldAttemptSchema.extend({
        attemptIndex: z.number().min(1).max(6),
        status: z.enum(["mark", "foul", "pass", "scratch"]),
        measurement: z.number().positive().optional()
      }).parse(req.body);
      
      // Validate: mark status requires measurement
      if (validated.status === "mark" && !validated.measurement) {
        return res.status(400).json({ error: "Mark requires measurement" });
      }
      
      // Get entry to find event
      const entry = await storage.getEntry(validated.entryId);
      if (!entry) {
        return res.status(404).json({ error: "Entry not found" });
      }
      
      const attempt = await storage.createFieldAttempt(validated);
      
      // Broadcast update
      broadcastToDisplays({
        type: 'field_attempt_update',
        meetId: entry.event.meetId,
        eventId: entry.eventId,
        entryId: entry.id,
        attempt
      });
      
      res.json(attempt);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid request", details: error.errors });
      }
      throw error;
    }
  });

  // Get attempts for entry
  app.get("/api/entries/:entryId/field-attempts", async (req, res) => {
    const attempts = await storage.getFieldAttempts(req.params.entryId);
    res.json(attempts);
  });

  // Get all attempts for event
  app.get("/api/events/:eventId/field-attempts", async (req, res) => {
    const attempts = await storage.getEventFieldAttempts(req.params.eventId);
    const obj: Record<string, FieldAttempt[]> = {};
    attempts.forEach((value, key) => { obj[key] = value; });
    res.json(obj);
  });

  // Update field attempt
  app.patch("/api/field-attempts/:id", async (req, res) => {
    try {
      const validated = z.object({
        status: z.enum(["mark", "foul", "pass", "scratch"]).optional(),
        measurement: z.number().positive().optional(),
        notes: z.string().optional()
      }).parse(req.body);
      
      const attempt = await storage.updateFieldAttempt(req.params.id, validated);
      
      // Get entry to broadcast
      const entry = await storage.getEntry(attempt.entryId);
      if (entry) {
        broadcastToDisplays({
          type: 'field_attempt_update',
          meetId: entry.event.meetId,
          eventId: entry.eventId,
          entryId: entry.id,
          attempt
        });
      }
      
      res.json(attempt);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid request", details: error.errors });
      }
      throw error;
    }
  });

  // Delete field attempt
  app.delete("/api/field-attempts/:id", async (req, res) => {
    await storage.deleteFieldAttempt(req.params.id);
    res.status(204).send();
  });

  // Teams
  app.get("/api/teams", async (req, res) => {
    try {
      const { meetId } = req.query;
      if (meetId) {
        const teams = await storage.getTeamsByMeetId(meetId as string);
        return res.json(teams);
      }
      const teams = await storage.getTeams();
      res.json(teams);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/teams", async (req, res) => {
    try {
      const data = insertTeamSchema.parse(req.body);
      const team = await storage.createTeam(data);
      res.json(team);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.patch("/api/teams/:id/score-override", async (req, res) => {
    try {
      const teamId = req.params.id;
      const { gender, score } = req.body;
      
      if (!gender || (gender !== 'M' && gender !== 'W')) {
        return res.status(400).json({ error: "Gender must be 'M' or 'W'" });
      }
      
      const team = await storage.getTeam(teamId);
      if (!team) {
        return res.status(404).json({ error: "Team not found" });
      }
      
      const numericScore = score !== null && score !== undefined && score !== '' ? Number(score) : null;
      if (numericScore !== null && (!isFinite(numericScore) || numericScore < 0)) {
        return res.status(400).json({ error: "Score must be a non-negative number" });
      }
      
      const updateData: any = {};
      if (gender === 'M') {
        updateData.menScoreOverride = numericScore;
      } else {
        updateData.womenScoreOverride = numericScore;
      }
      
      await storage.updateTeam(teamId, updateData);
      res.json({ success: true });
    } catch (error: any) {
      console.error("Error updating team score override:", error);
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/meets/:meetId/refresh-team-scores", async (req, res) => {
    try {
      const meetId = req.params.meetId;
      
      const meetTeams = await storage.getTeamsByMeetId(meetId);
      for (const team of meetTeams) {
        await storage.updateTeam(team.id, { 
          menScoreOverride: null, 
          womenScoreOverride: null 
        });
      }
      
      const meet = await storage.getMeet(meetId);
      if (meet?.mdbPath) {
        try {
          const { importCompleteMDB } = await import('./import-mdb-complete');
          await importCompleteMDB(meet.mdbPath, meetId);
          console.log(`[Refresh Team Scores] Re-imported MDB for meet ${meetId}`);
        } catch (err) {
          console.log(`[Refresh Team Scores] MDB re-import failed:`, err);
        }
      }
      
      const [menStandings, womenStandings] = await Promise.all([
        storage.getTeamStandings(meetId, { gender: "M" }),
        storage.getTeamStandings(meetId, { gender: "W" }),
      ]);
      
      res.json({ men: menStandings, women: womenStandings });
    } catch (error: any) {
      console.error("Error refreshing team scores:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // Divisions
  app.get("/api/divisions", async (req, res) => {
    const divisions = await storage.getDivisions();
    res.json(divisions);
  });

  app.post("/api/divisions", async (req, res) => {
    try {
      const data = insertDivisionSchema.parse(req.body);
      const division = await storage.createDivision(data);
      res.json(division);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // ARCHIVED: Season management feature

  // Meets
  app.get("/api/meets", async (req, res) => {
    try {
      const { seasonId } = req.query;
      if (seasonId) {
        const meets = await storage.getMeetsBySeason(parseInt(seasonId as string));
        return res.json(meets);
      }
      const meets = await storage.getMeets();
      res.json(meets);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Lookup meet by code - used for "Join Meet" functionality
  // This must come BEFORE /api/meets/:id to avoid "code" being matched as an ID
  app.get("/api/meets/code/:code", async (req, res) => {
    try {
      const meetCode = req.params.code.toUpperCase();
      const meet = await storage.getMeetByCode(meetCode);
      if (!meet) {
        return res.status(404).json({ message: "No meet found with that code. Please check the code and try again." });
      }
      res.json(meet);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/meets/:id", async (req, res) => {
    const meet = await storage.getMeet(req.params.id);
    if (!meet) {
      return res.status(404).json({ error: "Meet not found" });
    }
    res.json(meet);
  });

  app.post("/api/meets", async (req, res) => {
    try {
      const data = insertMeetSchema.parse(req.body);
      const meet = await storage.createMeet(data);
      
      // Seed default scenes for new meet
      await seedDefaultScenes(meet.id);
      
      await broadcastCurrentEvent();
      res.json(meet);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.patch("/api/meets/:id", async (req, res) => {
    try {
      const updateSchema = z.object({
        name: z.string().optional(),
        location: z.string().optional(),
        startDate: z.coerce.date().optional(),
        autoRefresh: z.boolean().optional(),
        refreshInterval: z.number().min(5).max(300).optional(),
        primaryColor: z.string().regex(/^#[0-9A-Fa-f]{6}$/).optional(),
        secondaryColor: z.string().regex(/^#[0-9A-Fa-f]{6}$/).optional(),
        accentColor: z.string().regex(/^#[0-9A-Fa-f]{6}$/).optional(),
        textColor: z.string().regex(/^#[0-9A-Fa-f]{6}$/).optional(),
      });

      const data = updateSchema.parse(req.body);
      const meet = await storage.updateMeet(req.params.id, data);

      if (!meet) {
        return res.status(404).json({ error: "Meet not found" });
      }

      res.json(meet);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.patch("/api/meets/:id/status", async (req, res) => {
    try {
      const { status } = req.body;
      if (!status) {
        return res.status(400).json({ error: "Status is required" });
      }
      const meet = await storage.updateMeetStatus(req.params.id, status);
      if (!meet) {
        return res.status(404).json({ error: "Meet not found" });
      }
      await broadcastCurrentEvent();
      res.json(meet);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Seed default scenes for an existing meet (useful for meets created before default scenes were added)
  app.post("/api/meets/:id/seed-default-scenes", async (req, res) => {
    try {
      const meetId = req.params.id;
      const meet = await storage.getMeet(meetId);
      
      if (!meet) {
        return res.status(404).json({ error: "Meet not found" });
      }
      
      // Check if meet already has scenes
      const existingScenes = await storage.getLayoutScenes(meetId);
      if (existingScenes.length > 0) {
        return res.status(400).json({ 
          error: "Meet already has scenes", 
          sceneCount: existingScenes.length,
          message: "Delete existing scenes first if you want to re-seed defaults"
        });
      }
      
      const seededCount = await seedDefaultScenes(meetId);
      res.json({ 
        success: true, 
        message: `Seeded ${seededCount} default scenes for meet`,
        seededCount 
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Upload meet logo
  app.post("/api/meets/:id/logo", imageUpload.single("logo"), async (req, res) => {
    try {
      const meetId = req.params.id;
      const meet = await storage.getMeet(meetId);
      
      if (!meet) {
        return res.status(404).json({ error: "Meet not found" });
      }
      
      if (!req.file) {
        return res.status(400).json({ error: "No logo file uploaded" });
      }
      
      const result = await fileStorage.saveMeetLogo(
        req.file.buffer,
        meetId,
        req.file.originalname
      );
      
      const logoUrl = fileStorage.publicUrlForKey(result.storageKey);
      
      // Extract color scheme from logo
      const colorScheme = await fileStorage.extractColorsFromImage(req.file.buffer);
      console.log(`Extracted color scheme from logo:`, colorScheme);
      
      // Update meet with logo URL and extracted color scheme
      const updatedMeet = await storage.updateMeet(meetId, { 
        logoUrl,
        ...colorScheme 
      });
      
      res.json({ 
        success: true, 
        logoUrl,
        colorScheme,
        meet: updatedMeet
      });
    } catch (error: any) {
      console.error("Error uploading meet logo:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // Delete meet logo
  app.delete("/api/meets/:id/logo", async (req, res) => {
    try {
      const meetId = req.params.id;
      const meet = await storage.getMeet(meetId);
      
      if (!meet) {
        return res.status(404).json({ error: "Meet not found" });
      }
      
      // Clear logo URL from meet
      const updatedMeet = await storage.updateMeet(meetId, { logoUrl: null });
      
      res.json({ 
        success: true,
        meet: updatedMeet
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.delete("/api/meets/:id", async (req, res) => {
    try {
      const meet = await storage.getMeet(req.params.id);
      if (!meet) {
        return res.status(404).json({ error: "Meet not found" });
      }
      await storage.deleteMeet(req.params.id);
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/meets/:id/reset", async (req, res) => {
    try {
      const meet = await storage.getMeet(req.params.id);
      if (!meet) {
        return res.status(404).json({ error: "Meet not found" });
      }
      const result = await storage.resetMeet(req.params.id);
      await broadcastCurrentEvent();
      res.json({ 
        success: true, 
        message: `Reset meet: deleted ${result.eventsDeleted} events, ${result.athletesDeleted} athletes, ${result.teamsDeleted} teams, ${result.divisionsDeleted} divisions`,
        ...result 
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/meets/:id/events", async (req, res) => {
    try {
      const events = await storage.getEventsByMeetId(req.params.id);
      res.json(events);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Print data endpoint for event (React print page hydration)
  app.get("/api/events/:id/print-data", async (req, res) => {
    try {
      const eventWithEntries = await storage.getEventWithEntries(req.params.id);
      
      if (!eventWithEntries) {
        return res.status(404).json({ error: "Event not found" });
      }

      const meet = await storage.getMeet(eventWithEntries.meetId);
      
      res.json({
        event: eventWithEntries,
        entries: eventWithEntries.entries || [],
        meet: meet || null
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Print data endpoint for meet (React print page hydration)
  app.get("/api/meets/:id/print-data", async (req, res) => {
    try {
      const meet = await storage.getMeet(req.params.id);
      
      if (!meet) {
        return res.status(404).json({ error: "Meet not found" });
      }

      // Get all events for this meet
      const events = await storage.getEventsByMeetId(req.params.id);
      
      // Use getEventWithEntries to get full EventWithEntries objects with all metadata
      const eventsWithEntriesRaw = await Promise.all(
        events.map(event => storage.getEventWithEntries(event.id))
      );
      
      // Normalize to always have entries as array, never undefined
      const eventsWithEntries = eventsWithEntriesRaw
        .filter((item): item is NonNullable<typeof item> => item !== null)
        .map(item => ({
          ...item,
          entries: item.entries ?? []  // Ensure entries is always an array
        }));
      
      // If some events returned null, log a warning
      if (eventsWithEntries.length < events.length) {
        console.warn(`Some events returned null from getEventWithEntries`);
      }
      
      res.json({
        meet,
        eventsWithEntries  // Now contains full EventWithEntries objects, not partial data
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Export endpoint for meets (all events)
  app.get("/api/meets/:id/export", async (req, res) => {
    try {
      const { format } = req.query;
      const meet = await storage.getMeet(req.params.id);
      
      if (!meet) {
        return res.status(404).json({ error: "Meet not found" });
      }

      // Get all events for this meet
      const events = await storage.getEventsByMeetId(req.params.id);
      
      // Use getEventWithEntries to get full EventWithEntries objects
      const eventsWithEntriesRaw = await Promise.all(
        events.map(event => storage.getEventWithEntries(event.id))
      );
      
      // Normalize to always have entries as array, never undefined
      const eventsWithEntries = eventsWithEntriesRaw
        .filter((item): item is NonNullable<typeof item> => item !== null)
        .map(item => ({
          ...item,
          entries: item.entries ?? []  // Ensure entries is always an array
        }));
      
      if (format === 'csv') {
        const csv = generateMeetCSV(meet, eventsWithEntries);
        const filename = `${meet.name.replace(/\s+/g, '-')}-results.csv`;
        
        res.setHeader('Content-Type', 'text/csv');
        res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
        res.send(csv);
      } else {
        res.status(400).json({ error: 'Invalid format. Use csv for meet exports' });
      }
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/meets/:id/upload", upload.single("mdbFile"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No file uploaded" });
      }

      const file = req.file;
      const filePath = file.path;
      const meetId = req.params.id;

      // Validate file extension
      const originalName = file.originalname.toLowerCase();
      if (!originalName.endsWith(".mdb")) {
        await unlink(filePath).catch(console.error);
        return res.status(400).json({ 
          error: "Invalid file type. Only .mdb files are allowed" 
        });
      }

      // Verify meet exists
      const existingMeet = await storage.getMeet(meetId);
      if (!existingMeet) {
        await unlink(filePath).catch(console.error);
        return res.status(404).json({ error: "Meet not found" });
      }

      console.log(`📁 Processing MDB import for meet: ${existingMeet.name} (${meetId})`);
      console.log(`📍 File: ${file.originalname}`);

      // Clear existing import data before re-importing
      const clearStats = await storage.clearMeetImportData(meetId);
      console.log(`🧹 Pre-import clear: ${JSON.stringify(clearStats)}`);

      // Run the import
      const stats = await importCompleteMDB(filePath, meetId);

      // Update meet with mdbPath and lastImportAt
      await storage.updateMeet(meetId, { 
        mdbPath: filePath,
        lastImportAt: new Date()
      });

      // Note: File is kept for auto-refresh functionality
      // (not deleted as it may be needed for periodic re-imports)

      // Broadcast current event after successful import
      await broadcastCurrentEvent();

      console.log(`✅ Import complete: ${JSON.stringify(stats)}`);

      res.json({
        success: true,
        message: "Import completed successfully",
        statistics: stats,
      });
    } catch (error: any) {
      console.error("❌ Import error:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // Display Management
  app.post("/api/displays/register", async (req, res) => {
    try {
      const { meetCode, computerName } = req.body;
      
      if (!meetCode || !computerName) {
        return res.status(400).json({ error: "meetCode and computerName are required" });
      }

      const result = await storage.registerDisplay(meetCode, computerName);
      
      if (!result) {
        return res.status(404).json({ error: "Meet not found with the provided code" });
      }

      res.json({
        displayId: result.display.id,
        authToken: result.display.authToken,
        meetId: result.meet.id,
        meetName: result.meet.name,
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.patch("/api/displays/:id/assign", async (req, res) => {
    try {
      const { targetType, targetId, layout } = req.body;
      
      if (!targetType) {
        return res.status(400).json({ error: "targetType is required" });
      }

      const assignment = await storage.assignDisplay(req.params.id, {
        targetType,
        targetId,
        layout,
      });

      if (!assignment) {
        return res.status(404).json({ error: "Display not found" });
      }

      res.json(assignment);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/displays/meet/:meetId", async (req, res) => {
    try {
      const displays = await storage.getDisplaysByMeet(req.params.meetId);
      
      const displaysWithAssignments = await Promise.all(
        displays.map(async (display) => {
          const assignment = await storage.getDisplayAssignment(display.id);
          return {
            ...display,
            assignment,
          };
        })
      );

      res.json(displaysWithAssignments);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/displays/:id/heartbeat", async (req, res) => {
    try {
      await storage.updateDisplayHeartbeat(req.params.id);
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // ===== DISPLAY DEVICES (Remote Display Control) =====

  // Get all display devices for a meet
  app.get("/api/display-devices/meet/:meetId", async (req, res) => {
    try {
      const devices = await storage.getDisplayDevices(req.params.meetId);
      res.json(devices);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Register a display device (called when display connects)
  app.post("/api/display-devices/register", async (req, res) => {
    try {
      const { meetId, deviceName } = req.body;
      
      if (!meetId || !deviceName) {
        return res.status(400).json({ error: "meetId and deviceName are required" });
      }

      // Get client IP for tracking
      const clientIp = req.headers['x-forwarded-for'] as string || 
                       req.socket.remoteAddress || 
                       'unknown';

      const device = await storage.createOrUpdateDisplayDevice({
        meetId,
        deviceName,
        lastIp: clientIp,
      });

      res.json(device);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Update device status (heartbeat)
  app.post("/api/display-devices/:id/heartbeat", async (req, res) => {
    try {
      const clientIp = req.headers['x-forwarded-for'] as string || 
                       req.socket.remoteAddress || 
                       'unknown';

      const device = await storage.updateDisplayDeviceStatus(req.params.id, 'online', clientIp);
      
      if (!device) {
        return res.status(404).json({ error: "Display device not found" });
      }

      res.json(device);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Assign an event to a display device (only for field mode displays)
  app.patch("/api/display-devices/:id/assign-event", async (req, res) => {
    try {
      const { eventId } = req.body;
      
      // Get current device to check mode
      const existingDevice = await storage.getDisplayDevice(req.params.id);
      if (!existingDevice) {
        return res.status(404).json({ error: "Display device not found" });
      }
      
      // Only field mode displays can have events manually assigned
      if (existingDevice.displayMode === 'track') {
        return res.status(400).json({ 
          error: "Track displays cannot be manually assigned to events. They automatically show data from Lynx." 
        });
      }
      
      const device = await storage.assignEventToDisplay(req.params.id, eventId || null);
      
      if (!device) {
        return res.status(404).json({ error: "Display device not found" });
      }

      // Get the event data if an event is assigned
      let eventData = null;
      if (eventId) {
        eventData = await storage.getEventWithEntries(eventId);
      }

      // Get the meet for context
      const meets = await storage.getMeets();
      const meet = meets.find(m => m.id === device.meetId);

      // Broadcast the assignment with event data to all connected displays
      broadcastToDisplays({
        type: 'display_assignment',
        data: {
          deviceId: device.id,
          deviceName: device.deviceName,
          eventId: device.assignedEventId,
          event: eventData,
          meet: meet,
        }
      } as WSMessage);

      res.json(device);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Set display mode (track = auto from Lynx, field = manual assignment)
  app.patch("/api/display-devices/:id/mode", async (req, res) => {
    try {
      const { displayMode } = req.body;
      
      if (!displayMode || !['track', 'field'].includes(displayMode)) {
        return res.status(400).json({ error: "displayMode must be 'track' or 'field'" });
      }
      
      const device = await storage.updateDisplayDeviceMode(req.params.id, displayMode);
      
      if (!device) {
        return res.status(404).json({ error: "Display device not found" });
      }

      // Broadcast the mode change
      broadcastToDisplays({
        type: 'display_mode_change',
        data: {
          deviceId: device.id,
          deviceName: device.deviceName,
          displayMode: device.displayMode,
        }
      } as WSMessage);

      res.json(device);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Set device offline
  app.patch("/api/display-devices/:id/offline", async (req, res) => {
    try {
      const device = await storage.updateDisplayDeviceStatus(req.params.id, 'offline');
      
      if (!device) {
        return res.status(404).json({ error: "Display device not found" });
      }

      res.json(device);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Delete a display device
  app.delete("/api/display-devices/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteDisplayDevice(req.params.id);
      
      if (!deleted) {
        return res.status(404).json({ error: "Display device not found" });
      }

      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Send command to a display device (push template/content)
  app.post("/api/display-devices/:id/command", async (req, res) => {
    try {
      const { template, eventId } = req.body;
      const deviceId = req.params.id;
      
      // Get the device
      const device = await storage.getDisplayDevice(deviceId);
      if (!device) {
        return res.status(404).json({ error: "Display device not found" });
      }
      
      // Validate template compatibility with device display type
      // Display type capabilities:
      // - P10 (192x96): 1 athlete max
      // - P6 (288x144): 1 athlete max  
      // - BigBoard (1920x1080): 8 athletes max
      const displayType = device.displayType || 'P10';
      const isSingleAthleteDisplay = displayType === 'P10' || displayType === 'P6';
      
      if (template && isSingleAthleteDisplay) {
        // Use the shared layout templates registry to validate compatibility
        const { getTemplateById } = await import('@shared/layout-templates');
        const templateInfo = getTemplateById(template);
        
        // Check if template exists in registry and has display type metadata
        if (templateInfo) {
          // Template found in registry - check if its displayType matches device
          if (templateInfo.displayType === 'BigBoard') {
            return res.status(400).json({ 
              error: `Template '${template}' is a BigBoard template and not compatible with ${displayType} displays. P10/P6 displays can only show one athlete at a time.`,
              suggestion: template.includes('field') 
                ? `${displayType.toLowerCase()}-field-results`
                : `${displayType.toLowerCase()}-results`,
              displayType: displayType,
              maxAthletes: 1
            });
          }
        } else {
          // Template not in registry - check by prefix/name patterns
          const templateLower = template.toLowerCase();
          
          // Explicitly incompatible: BigBoard templates and multi-athlete components
          const isExplicitlyIncompatible = 
            templateLower.startsWith('bigboard-') ||
            templateLower === 'bigboard' ||
            ['compiledresults', 'runningresults', 'fieldsidebyside'].includes(templateLower.replace(/-/g, ''));
          
          if (isExplicitlyIncompatible) {
            return res.status(400).json({ 
              error: `Template '${template}' is not compatible with ${displayType} displays. P10/P6 displays can only show one athlete at a time.`,
              suggestion: templateLower.includes('field') 
                ? `${displayType.toLowerCase()}-field-results`
                : `${displayType.toLowerCase()}-results`,
              displayType: displayType,
              maxAthletes: 1
            });
          }
        }
      }
      
      // Update the template in database
      if (template !== undefined) {
        await storage.updateDisplayTemplate(deviceId, template);
      }
      
      // If setting an event, update that too
      if (eventId !== undefined) {
        await storage.assignEventToDisplay(deviceId, eventId);
      }
      
      // Find the connected WebSocket for this device
      const connectedDevice = connectedDisplayDevices.get(deviceId);
      if (connectedDevice && connectedDevice.ws.readyState === WebSocket.OPEN) {
        // Look up custom scene mapping if template is provided
        let sceneId: number | null = null;
        let sceneData: { scene: any; objects: any[] } | null = null;
        let liveEventData: any = null;
        
        if (template && device.meetId) {
          const displayMode = getDisplayModeFromTemplate(template);
          if (displayMode) {
            try {
              const mapping = await storage.getSceneTemplateMappingByTypeAndMode(
                device.meetId,
                displayType,
                displayMode
              );
              if (mapping) {
                sceneId = mapping.sceneId;
                // Pre-fetch scene data for instant switching
                sceneData = await prefetchSceneData(sceneId);
                console.log(`[Manual Command] ${device.deviceName}: Using custom scene ${sceneId} for ${displayMode}`);
              }
            } catch (err) {
              console.error(`[Manual Command] Error looking up scene mapping:`, err);
            }
          }
          
          // Get latest live event data for modes that need it
          if (displayMode === 'start_list' || displayMode === 'running_time' || displayMode === 'track_results') {
            try {
              // Get the most recent live event data
              const liveData = await storage.getLiveEventsByMeet();
              if (liveData && liveData.length > 0) {
                // Use the most recent entry
                const latestLive = liveData[0];
                
                // Get total heats - first check EVT watcher cache, then fall back to database
                let totalHeats = 1;
                const matchingEvents = await storage.getEventsByLynxEventNumber(latestLive.eventNumber);
                if (matchingEvents.length > 0) {
                  const event = matchingEvents[0];
                  const roundNum = latestLive.round ? parseInt(String(latestLive.round)) : 1;
                  
                  // First try the EVT watcher cache
                  const cachedHeats = getTotalHeatsFromCache(event.meetId, latestLive.eventNumber, roundNum);
                  if (cachedHeats !== null) {
                    totalHeats = cachedHeats;
                  } else {
                    // Fall back to database calculation
                    const roundStr = latestLive.round ? String(latestLive.round).toLowerCase() : undefined;
                    totalHeats = await storage.getTotalHeatsForEvent(event.id, roundStr);
                  }
                }
                
                liveEventData = {
                  eventNumber: latestLive.eventNumber,
                  eventName: latestLive.eventName,
                  mode: latestLive.mode,
                  heat: latestLive.heat,
                  totalHeats, // Total heats from database for "Heat X of Y" display
                  round: latestLive.round,
                  entries: latestLive.entries,
                  wind: latestLive.wind,
                };
              }
            } catch (err) {
              console.error(`[Manual Command] Error getting live data:`, err);
            }
          }
        }
        
        // Send command to the display device
        connectedDevice.ws.send(JSON.stringify({
          type: 'display_command',
          template: sceneId ? null : template, // Use template only if no custom scene
          sceneId: sceneId, // Custom scene ID (if mapped)
          sceneData: sceneData, // Pre-fetched scene data for instant switching
          eventId,
          liveEventData,
          pagingSize: connectedDevice.pagingSize,
          pagingInterval: connectedDevice.pagingInterval,
        }));
        
        res.json({ success: true, delivered: true, sceneId });
      } else {
        // Device not connected, but command saved to database
        res.json({ success: true, delivered: false, message: "Device offline - command saved for when it reconnects" });
      }
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Toggle auto-mode for a display device
  app.post("/api/display-devices/:id/auto-mode", async (req, res) => {
    try {
      const { enabled } = req.body;
      const deviceId = req.params.id;
      
      // Persist to database
      const autoModeValue = enabled !== false;
      const updatedDevice = await storage.updateDisplayAutoMode(deviceId, autoModeValue);
      
      if (!updatedDevice) {
        return res.status(404).json({ error: "Device not found" });
      }
      
      // Update in-memory state if device is connected
      const connectedDevice = connectedDisplayDevices.get(deviceId);
      if (connectedDevice) {
        connectedDevice.autoMode = autoModeValue;
        
        // Notify the device of auto-mode status
        // Layout switching is now controlled by FinishLynx via layout-command events
        if (connectedDevice.ws.readyState === WebSocket.OPEN) {
          connectedDevice.ws.send(JSON.stringify({
            type: 'auto_mode_update',
            autoMode: connectedDevice.autoMode,
          }));
        }
      }
      
      console.log(`[Auto-Mode] ${updatedDevice.deviceName}: ${autoModeValue ? 'ENABLED' : 'DISABLED'}`);
      
      res.json({ success: true, autoMode: autoModeValue });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });
  
  // Get auto-mode status for a display device
  app.get("/api/display-devices/:id/auto-mode", async (req, res) => {
    try {
      const deviceId = req.params.id;
      
      // Get persisted value from database
      const device = await storage.getDisplayDevice(deviceId);
      if (!device) {
        return res.status(404).json({ error: "Device not found" });
      }
      
      const connectedDevice = connectedDisplayDevices.get(deviceId);
      const isConnected = !!connectedDevice;
      
      res.json({ 
        connected: isConnected, 
        autoMode: device.autoMode ?? true // Default to true
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get paging settings for a display device
  app.get("/api/display-devices/:id/paging", async (req, res) => {
    try {
      const device = await storage.getDisplayDevice(req.params.id);
      if (!device) {
        return res.status(404).json({ error: "Device not found" });
      }
      res.json({ 
        pagingSize: device.pagingSize ?? 8,
        pagingInterval: device.pagingInterval ?? 5
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Update paging settings for a display device
  app.patch("/api/display-devices/:id/paging", async (req, res) => {
    try {
      const { pagingSize, pagingInterval } = req.body;
      const deviceId = req.params.id;
      
      // Validate inputs
      const size = Math.max(1, Math.min(20, parseInt(pagingSize) || 8));
      const interval = Math.max(1, Math.min(60, parseInt(pagingInterval) || 5));
      
      const device = await storage.getDisplayDevice(deviceId);
      if (!device) {
        return res.status(404).json({ error: "Device not found" });
      }
      
      // Update paging settings in database
      const updated = await storage.updateDisplayDevice(deviceId, { 
        pagingSize: size, 
        pagingInterval: interval 
      });
      
      // Update the in-memory device record with new paging settings
      const connectedDevice = connectedDisplayDevices.get(deviceId);
      if (connectedDevice) {
        connectedDevice.pagingSize = size;
        connectedDevice.pagingInterval = interval;
        
        // Notify the connected device of the new settings
        if (connectedDevice.ws.readyState === WebSocket.OPEN) {
          connectedDevice.ws.send(JSON.stringify({
            type: 'paging_settings',
            pagingSize: size,
            pagingInterval: interval,
          }));
        }
      }
      
      res.json({ success: true, pagingSize: size, pagingInterval: interval });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Update display device config (fieldPort, isBigBoard, pagingSize, pagingInterval, displayType)
  app.patch("/api/display-devices/:id", async (req, res) => {
    try {
      const { fieldPort, isBigBoard, pagingSize, pagingInterval, displayType, displayWidth, displayHeight } = req.body;
      const id = req.params.id;

      const device = await storage.getDisplayDevice(id);
      if (!device) {
        return res.status(404).json({ error: "Device not found" });
      }

      const validDisplayTypes = ['P10', 'P6', 'BigBoard', 'Broadcast', 'Custom'];
      if (displayType) {
        if (!validDisplayTypes.includes(displayType)) {
          return res.status(400).json({ error: `Invalid display type. Must be one of: ${validDisplayTypes.join(', ')}` });
        }
        await storage.updateDisplayDeviceType(id, displayType, undefined, displayWidth, displayHeight);
      }

      const updates: Partial<{ pagingSize: number; pagingInterval: number; fieldPort: number | null; isBigBoard: boolean }> = {};
      if (fieldPort !== undefined) updates.fieldPort = fieldPort;
      if (isBigBoard !== undefined) updates.isBigBoard = isBigBoard;
      if (pagingSize !== undefined) updates.pagingSize = Math.max(1, Math.min(20, parseInt(pagingSize) || 8));
      if (pagingInterval !== undefined) updates.pagingInterval = Math.max(1, Math.min(60, parseInt(pagingInterval) || 5));

      if (Object.keys(updates).length > 0) {
        await storage.updateDisplayDevice(id, updates);
      }

      const finalDevice = await storage.getDisplayDevice(id);

      broadcastToDisplays({
        type: 'device_config_update',
        data: {
          deviceId: id,
          displayType: finalDevice?.displayType,
          fieldPort: finalDevice?.fieldPort,
          isBigBoard: finalDevice?.isBigBoard,
          pagingSize: finalDevice?.pagingSize,
          pagingInterval: finalDevice?.pagingInterval,
        }
      } as WSMessage);

      res.json(finalDevice);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Send Hytek Results to a display device (compiled results from database)
  app.post("/api/display-devices/:id/hytek-results", async (req, res) => {
    try {
      const { eventId, pagingLines, round } = req.body;
      const deviceId = req.params.id;
      
      if (!eventId) {
        return res.status(400).json({ error: "eventId is required" });
      }
      
      const device = await storage.getDisplayDevice(deviceId);
      if (!device) {
        return res.status(404).json({ error: "Display device not found" });
      }
      
      const event = await storage.getEvent(eventId);
      if (!event) {
        return res.status(404).json({ error: "Event not found" });
      }
      
      const allEntries = await storage.getEntriesByEvent(eventId);
      
      if (allEntries.length === 0) {
        return res.status(400).json({ error: "No entries found for this event", warning: true });
      }
      
      const selectedRound = round || 'final';
      
      const getRoundFields = (entry: any) => {
        switch (selectedRound) {
          case 'preliminary':
            return {
              mark: entry.preliminaryMark,
              place: entry.preliminaryPlace,
              heat: entry.preliminaryHeat,
              lane: entry.preliminaryLane,
            };
          case 'quarterfinal':
            return {
              mark: entry.quarterfinalMark,
              place: entry.quarterfinalPlace,
              heat: entry.quarterfinalHeat,
              lane: entry.quarterfinalLane,
            };
          case 'semifinal':
            return {
              mark: entry.semifinalMark,
              place: entry.semifinalPlace,
              heat: entry.semifinalHeat,
              lane: entry.semifinalLane,
            };
          case 'final':
          default:
            return {
              mark: entry.finalMark,
              place: entry.finalPlace,
              heat: entry.finalHeat,
              lane: entry.finalLane || entry.finalsLane,
            };
        }
      };
      
      const roundLabel = selectedRound === 'preliminary' ? 'Prelims'
        : selectedRound === 'quarterfinal' ? 'Quarterfinals'
        : selectedRound === 'semifinal' ? 'Semis'
        : 'Final';
      
      const relevantEntries = allEntries.filter(entry => {
        const fields = getRoundFields(entry);
        return fields.heat != null || fields.lane != null || fields.mark != null || fields.place != null;
      });
      
      const entriesToShow = relevantEntries.length > 0 ? relevantEntries : allEntries;
      
      const sortedEntries = entriesToShow.sort((a, b) => {
        const aFields = getRoundFields(a);
        const bFields = getRoundFields(b);
        const aHeat = aFields.heat || 0;
        const bHeat = bFields.heat || 0;
        if (aHeat !== bHeat) return aHeat - bHeat;
        if (aFields.place && bFields.place) {
          return aFields.place - bFields.place;
        }
        if (aFields.place) return -1;
        if (bFields.place) return 1;
        const aMark = typeof aFields.mark === 'number' ? aFields.mark : 999;
        const bMark = typeof bFields.mark === 'number' ? bFields.mark : 999;
        if (aMark !== bMark) return aMark - bMark;
        if (aFields.lane && bFields.lane) {
          return aFields.lane - bFields.lane;
        }
        return (a.seedMark || 999) - (b.seedMark || 999);
      });
      
      const athleteIds = sortedEntries.map(e => e.athleteId).filter((id): id is string => !!id);
      const uniqueAthleteIds = [...new Set(athleteIds)];
      
      const athleteMap = new Map<string, any>();
      const teamMap = new Map<string, any>();
      
      if (uniqueAthleteIds.length > 0) {
        const athletes = await Promise.all(uniqueAthleteIds.map(id => storage.getAthlete(id)));
        athletes.forEach(a => { if (a) athleteMap.set(a.id, a); });
      }
      
      const teamIds = new Set<string>();
      sortedEntries.forEach(e => {
        if (e.teamId) teamIds.add(e.teamId);
      });
      athleteMap.forEach(a => {
        if (a.teamId) teamIds.add(a.teamId);
      });
      
      if (teamIds.size > 0) {
        const teams = await Promise.all([...teamIds].map(id => storage.getTeam(id)));
        teams.forEach(t => { if (t) teamMap.set(t.id, t); });
      }
      
      const ceilToPrecision = (val: number, precision: number): number => {
        const factor = Math.pow(10, precision);
        return Math.ceil(val * factor - 1e-9) / factor;
      };
      const formatTimeSeconds = (seconds: number, precision: number = 2): string => {
        const rounded = ceilToPrecision(seconds, precision);
        if (rounded >= 3600) {
          const hours = Math.floor(rounded / 3600);
          const mins = Math.floor((rounded % 3600) / 60);
          const secs = ceilToPrecision(rounded % 60, precision).toFixed(precision);
          return `${hours}:${String(mins).padStart(2, '0')}:${secs.padStart(precision + 3, '0')}`;
        }
        if (rounded >= 60) {
          const mins = Math.floor(rounded / 60);
          const secs = ceilToPrecision(rounded % 60, precision).toFixed(precision);
          return `${mins}:${secs.padStart(precision + 3, '0')}`;
        }
        return rounded.toFixed(precision);
      };
      
      const isTrackEvent = event.eventType ? !['high_jump','pole_vault','long_jump','triple_jump','shot_put','discus','hammer','javelin','weight_throw'].some(ft => event.eventType!.toLowerCase().includes(ft.replace('_',''))) : true;
      
      const eventAdvanceByPlace = (event as any).advanceByPlace || 0;
      const eventAdvanceByTime = (event as any).advanceByTime || 0;
      const isPrelimRound = selectedRound !== 'final';
      
      const qualifierTimeSet = new Set<string>();
      if (isPrelimRound && eventAdvanceByTime > 0 && isTrackEvent) {
        const nonPlaceQualifiers: { entryId: string; mark: number }[] = [];
        sortedEntries.forEach(entry => {
          const fields = getRoundFields(entry);
          const place = fields.place || 0;
          const mark = fields.mark;
          if (typeof mark === 'number' && mark > 0 && (!place || place > eventAdvanceByPlace)) {
            nonPlaceQualifiers.push({ entryId: entry.id, mark });
          }
        });
        nonPlaceQualifiers.sort((a, b) => a.mark - b.mark);
        const timeQualifiers = nonPlaceQualifiers.slice(0, eventAdvanceByTime);
        timeQualifiers.forEach(q => qualifierTimeSet.add(q.entryId));
      }
      
      const enrichedEntries = sortedEntries.map((entry, index) => {
        const athlete = entry.athleteId ? athleteMap.get(entry.athleteId) : null;
        const teamId = entry.teamId || athlete?.teamId;
        const team = teamId ? teamMap.get(teamId) : null;
        const fields = getRoundFields(entry);
        const position = fields.place || (index + 1);
        
        const dqCode = entry.notes ? String(entry.notes).trim().toUpperCase() : null;
        const knownStatusCodes = ['NH', 'NM', 'FOUL', 'DNS', 'DNF', 'DQ', 'SCR', 'FS', 'NT'];
        const isKnownStatus = dqCode && knownStatusCodes.includes(dqCode);
        
        let markValue: string;
        if (isKnownStatus) {
          markValue = dqCode!;
        } else if (entry.isDisqualified && dqCode) {
          markValue = dqCode;
        } else if (entry.isDisqualified) {
          markValue = 'DQ';
        } else if (entry.isScratched) {
          markValue = 'SCR';
        } else {
          const rawMark = fields.mark ?? entry.seedMark ?? '';
          if (typeof rawMark === 'number') {
            markValue = isTrackEvent 
              ? formatTimeSeconds(rawMark) 
              : rawMark.toFixed(2);
          } else {
            markValue = rawMark;
          }
        }
        
        let qualifier = '';
        if (isPrelimRound && !isKnownStatus && !entry.isDisqualified && !entry.isScratched) {
          const place = fields.place || 0;
          if (place > 0 && eventAdvanceByPlace > 0 && place <= eventAdvanceByPlace) {
            qualifier = 'Q';
          } else if (qualifierTimeSet.has(entry.id)) {
            qualifier = 'q';
          }
        }
        
        const teamName = team?.name || team?.shortName || '';
        const teamAbbrev = team?.abbreviation || team?.shortName || '';
        return {
          position,
          lane: fields.lane || 0,
          heat: fields.heat || 0,
          bib: athlete?.bibNumber || athlete?.athleteNumber?.toString() || '',
          firstName: athlete?.firstName || '',
          lastName: athlete?.lastName || '',
          name: athlete ? `${athlete.firstName} ${athlete.lastName}`.trim() : 'Unknown',
          team: teamAbbrev,
          affiliation: teamName,
          time: markValue,
          mark: markValue,
          result: markValue,
          place: fields.place,
          qualifier,
        };
      });
      
      // Use paging lines (lines = seconds)
      const lines = Math.max(1, Math.min(20, parseInt(pagingLines) || 8));
      
      // Determine display type and select appropriate template
      const displayType = device.displayType || 'P10';
      const isSingleAthleteDisplay = displayType === 'P10' || displayType === 'P6';
      
      // For P10/P6 displays, use single-athlete template; for BigBoard, use compiled results
      const defaultTemplate = isSingleAthleteDisplay 
        ? `${displayType.toLowerCase()}-results` 
        : 'bigboard-compiled-results';
      
      // Find the connected WebSocket for this device
      const connectedDevice = connectedDisplayDevices.get(deviceId);
      if (connectedDevice && connectedDevice.ws.readyState === WebSocket.OPEN) {
        // Update paging settings (lines = seconds)
        connectedDevice.pagingSize = lines;
        connectedDevice.pagingInterval = lines;
        
        let sceneId: number | null = null;
        let sceneData: { scene: any; objects: any[] } | null = null;
        
        if (device.meetId) {
          try {
            let mapping = await storage.getSceneTemplateMappingByTypeAndMode(device.meetId, displayType, 'hytek_results');
            if (!mapping) {
              mapping = await storage.getSceneTemplateMappingByTypeAndMode(device.meetId, displayType, 'track_results');
            }
            if (mapping) {
              sceneId = mapping.sceneId;
              sceneData = await prefetchSceneData(sceneId);
            }
          } catch (err) {
            console.error(`[Hytek Results] Error looking up scene mapping:`, err);
          }
        }
        
        const maxHeat = sortedEntries.reduce((max, e) => {
          const h = getRoundFields(e).heat || 0;
          return h > max ? h : max;
        }, 0);
        
        connectedDevice.ws.send(JSON.stringify({
          type: 'display_command',
          template: sceneId ? null : defaultTemplate,
          sceneId,
          sceneData,
          liveEventData: {
            eventNumber: event.eventNumber || 0,
            eventName: event.name,
            roundName: roundLabel,
            totalHeats: maxHeat,
            mode: 'results',
            entries: enrichedEntries,
            advanceByPlace: eventAdvanceByPlace || undefined,
            advanceByTime: eventAdvanceByTime || undefined,
          },
          pagingSize: lines,
          pagingInterval: lines,
        }));
        
        await storage.updateDisplayDevice(deviceId, {
          pagingSize: lines,
          pagingInterval: lines,
        });
        
        console.log(`[Hytek Results] Sent ${enrichedEntries.length} entries (${roundLabel}) to ${device.deviceName} (${displayType}, paging: ${lines} lines/${lines}s)`);
        res.json({ success: true, delivered: true, entryCount: enrichedEntries.length });
      } else {
        res.json({ success: false, delivered: false, message: "Device offline" });
      }
    } catch (error: any) {
      console.error(`[Hytek Results] Error:`, error);
      res.status(500).json({ error: error.message });
    }
  });

  // Send Team Scores to a display device
  app.post("/api/display-devices/:id/team-scores", async (req, res) => {
    try {
      const { pagingLines, gender } = req.body;
      const deviceId = req.params.id;
      const selectedGender: string = gender === 'W' ? 'W' : 'M';
      const genderLabel = selectedGender === 'W' ? "Women's" : "Men's";
      
      // Get the device
      const device = await storage.getDisplayDevice(deviceId);
      if (!device) {
        return res.status(404).json({ error: "Display device not found" });
      }
      
      if (!device.meetId) {
        return res.status(400).json({ error: "Device has no assigned meet" });
      }
      
      // Collect scored events for this gender (names + count)
      let totalEventsScored = 0;
      let scoredEventNames: string[] = [];
      try {
        const allEvents = await storage.getEventsByMeetId(device.meetId);
        const filtered = allEvents.filter((e: any) => {
          if (!e.isScored) return false;
          const g = (e.gender || '').toUpperCase().charAt(0);
          return selectedGender === 'M' ? (g === 'M' || g === '') : (g === 'W' || g === 'F');
        });
        totalEventsScored = filtered.length;
        scoredEventNames = filtered
          .sort((a: any, b: any) => (a.eventNumber || 0) - (b.eventNumber || 0))
          .map((e: any) => {
            const raw = e.name || '';
            const stripped = raw
              .replace(/^(Men'?s?|Women'?s?)\s+/i, '')
              .replace(/\s+/g, ' ')
              .trim();
            return abbreviateEventName(stripped);
          })
          .filter((n: string) => n.length > 0);
      } catch (err) {
        console.log('[Team Scores] Could not count scored events');
      }
      
      // Use getTeamStandings which handles gender-filtered scoring
      let standings: any[] = [];
      let hasScores = false;
      try {
        standings = await storage.getTeamStandings(device.meetId, { gender: selectedGender });
        hasScores = standings.some((s: any) => (s.totalPoints || 0) > 0);
      } catch (err) {
        console.log('[Team Scores] getTeamStandings failed, falling back to manual scoring');
      }
      
      // If getTeamStandings returned results, use them
      let teamEntries: any[];
      if (standings.length > 0) {
        // Get team logos
        const logoMap = new Map<string, string>();
        try {
          const allLogos = await storage.getTeamLogosByMeet(device.meetId);
          for (const logo of allLogos) {
            logoMap.set(logo.teamId, fileStorage.publicUrlForKey(logo.storageKey));
          }
        } catch {}
        
        teamEntries = standings
          .filter((s: any) => (s.totalPoints || 0) > 0)
          .map((s: any, index: number) => ({
            place: String(index + 1),
            name: s.teamName || 'Unknown',
            affiliation: s.teamAbbreviation || s.teamName || '',
            team: s.teamAbbreviation || s.teamName || '',
            time: String(s.totalPoints || 0),
            mark: String(s.totalPoints || 0),
            logoUrl: logoMap.get(s.teamId) || null,
          }));
      } else {
        // Fallback: get all teams and manual scoring
        const teams = await storage.getTeamsByMeetId(device.meetId);
        if (teams.length === 0) {
          return res.status(400).json({ error: "No teams found for this meet", warning: true });
        }
        
        let teamScores: Map<string, number> = new Map();
        try {
          const scoringResults = await storage.getTeamScoringResultsByMeet(device.meetId);
          for (const result of scoringResults) {
            if (result.gender && result.gender !== selectedGender) continue;
            const current = teamScores.get(result.teamId) || 0;
            teamScores.set(result.teamId, current + (result.points || 0));
            hasScores = true;
          }
        } catch (err) {
          console.log('[Team Scores] No scoring results available');
        }
        
        const sortedTeams = [...teams].sort((a: typeof teams[0], b: typeof teams[0]) => {
          const scoreA = teamScores.get(a.id) || 0;
          const scoreB = teamScores.get(b.id) || 0;
          return scoreB - scoreA;
        });
        
        teamEntries = sortedTeams
          .filter((team: typeof teams[0]) => (teamScores.get(team.id) || 0) > 0)
          .map((team: typeof teams[0], index: number) => ({
            place: String(index + 1),
            name: team.name || team.shortName || 'Unknown',
            affiliation: team.abbreviation || team.name || team.shortName || '',
            team: team.abbreviation || team.name || team.shortName || '',
            time: String(teamScores.get(team.id) || 0),
            mark: String(teamScores.get(team.id) || 0),
          }));
      }
      
      // Use paging lines (lines = seconds)
      const lines = Math.max(1, Math.min(20, parseInt(pagingLines) || 8));
      
      // Find the connected WebSocket for this device
      const connectedDevice = connectedDisplayDevices.get(deviceId);
      if (connectedDevice && connectedDevice.ws.readyState === WebSocket.OPEN) {
        // Update paging settings (lines = seconds)
        connectedDevice.pagingSize = lines;
        connectedDevice.pagingInterval = lines;
        
        // Look up custom scene mapping for team_scores mode
        const displayType = device.displayType || 'P10';
        let sceneId: number | null = null;
        let sceneData: { scene: any; objects: any[] } | null = null;
        
        if (device.meetId) {
          try {
            const mapping = await storage.getSceneTemplateMappingByTypeAndMode(
              device.meetId,
              displayType,
              'team_scores'
            );
            if (mapping) {
              sceneId = mapping.sceneId;
              sceneData = await prefetchSceneData(sceneId);
            }
          } catch (err) {
            console.error(`[Team Scores] Error looking up scene mapping:`, err);
          }
        }
        
        // Send command to the display device
        connectedDevice.ws.send(JSON.stringify({
          type: 'display_command',
          template: sceneId ? null : 'team-scores',
          sceneId,
          sceneData,
          liveEventData: {
            mode: 'team_scores',
            eventName: `${genderLabel} Team Scores`,
            gender: selectedGender,
            totalEventsScored,
            scoredEventNames,
            entries: teamEntries,
          },
          pagingSize: lines,
          pagingInterval: lines,
        }));
        
        // Update database with paging settings
        await storage.updateDisplayDevice(deviceId, {
          pagingSize: lines,
          pagingInterval: lines,
        });
        
        console.log(`[Team Scores] Sent ${teamEntries.length} ${genderLabel} teams to ${device.deviceName} (paging: ${lines} lines/${lines}s, hasScores: ${hasScores})`);
        res.json({ 
          success: true, 
          delivered: true, 
          teamCount: teamEntries.length,
          hasScores,
          warning: hasScores ? undefined : "No scoring data available - all teams will show 0 points"
        });
      } else {
        res.json({ success: false, delivered: false, message: "Device offline" });
      }
    } catch (error: any) {
      console.error(`[Team Scores] Error:`, error);
      res.status(500).json({ error: error.message });
    }
  });

  // ===== DISPLAY THEMES =====

  // Get all themes for a meet
  app.get("/api/meets/:meetId/themes", async (req, res) => {
    try {
      const themes = await storage.getDisplayThemes(req.params.meetId);
      res.json(themes);
    } catch (error) {
      console.error("Error fetching display themes:", error);
      res.status(500).json({ error: "Failed to fetch display themes" });
    }
  });

  // Get default theme for a meet
  app.get("/api/meets/:meetId/themes/default", async (req, res) => {
    try {
      const theme = await storage.getDefaultDisplayTheme(req.params.meetId);
      if (!theme) {
        return res.status(404).json({ error: "Default theme not found" });
      }
      res.json(theme);
    } catch (error) {
      console.error("Error fetching default theme:", error);
      res.status(500).json({ error: "Failed to fetch default theme" });
    }
  });

  // Create a new theme
  app.post("/api/meets/:meetId/themes", async (req, res) => {
    try {
      const parsed = insertDisplayThemeSchema.parse({
        ...req.body,
        meetId: req.params.meetId,
      });
      const theme = await storage.createDisplayTheme(parsed);
      res.json(theme);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid theme data", details: error.errors });
      }
      console.error("Error creating display theme:", error);
      res.status(500).json({ error: "Failed to create display theme" });
    }
  });

  // Update a theme
  app.patch("/api/themes/:id", async (req, res) => {
    try {
      const parsed = insertDisplayThemeSchema.partial().parse(req.body);
      const theme = await storage.updateDisplayTheme(req.params.id, parsed);
      if (!theme) {
        return res.status(404).json({ error: "Theme not found" });
      }
      res.json(theme);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid theme data", details: error.errors });
      }
      console.error("Error updating display theme:", error);
      res.status(500).json({ error: "Failed to update display theme" });
    }
  });

  // Delete a theme
  app.delete("/api/themes/:id", async (req, res) => {
    try {
      await storage.deleteDisplayTheme(req.params.id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting display theme:", error);
      res.status(500).json({ error: "Failed to delete display theme" });
    }
  });

  // ===== BOARD CONFIGS =====

  // Get board config
  app.get("/api/meets/:meetId/boards/:boardId/config", async (req, res) => {
    try {
      const config = await storage.getBoardConfig(req.params.boardId, req.params.meetId);
      res.json(config || null);
    } catch (error) {
      console.error("Error fetching board config:", error);
      res.status(500).json({ error: "Failed to fetch board config" });
    }
  });

  // Create or update board config
  app.put("/api/meets/:meetId/boards/:boardId/config", async (req, res) => {
    try {
      // Check if config exists
      const existing = await storage.getBoardConfig(req.params.boardId, req.params.meetId);
      
      if (existing) {
        // Update existing
        const parsed = insertBoardConfigSchema.partial().parse(req.body);
        const updated = await storage.updateBoardConfig(existing.id, parsed);
        return res.json(updated);
      } else {
        // Create new
        const parsed = insertBoardConfigSchema.parse({
          ...req.body,
          meetId: req.params.meetId,
          boardId: req.params.boardId,
        });
        const created = await storage.createBoardConfig(parsed);
        return res.json(created);
      }
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid config data", details: error.errors });
      }
      console.error("Error saving board config:", error);
      res.status(500).json({ error: "Failed to save board config" });
    }
  });

  // Delete board config
  app.delete("/api/boards/:boardId/config", async (req, res) => {
    try {
      const meetId = req.query.meetId as string;
      if (!meetId) {
        return res.status(400).json({ error: "meetId query parameter required" });
      }
      
      const config = await storage.getBoardConfig(req.params.boardId, meetId);
      if (config) {
        await storage.deleteBoardConfig(config.id);
      }
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting board config:", error);
      res.status(500).json({ error: "Failed to delete board config" });
    }
  });

  // ===== DISPLAY LAYOUTS =====

  // Get all layouts for a meet
  app.get("/api/display-layouts/meet/:meetId", async (req, res) => {
    try {
      const layouts = await storage.getDisplayLayoutsByMeet(req.params.meetId);
      res.json(layouts);
    } catch (error) {
      console.error("Error fetching display layouts:", error);
      res.status(500).json({ error: "Failed to fetch display layouts" });
    }
  });

  // Get a specific layout by ID
  app.get("/api/display-layouts/:id", async (req, res) => {
    try {
      const layout = await storage.getDisplayLayoutById(req.params.id);
      if (!layout) {
        return res.status(404).json({ error: "Layout not found" });
      }
      res.json(layout);
    } catch (error) {
      console.error("Error fetching display layout:", error);
      res.status(500).json({ error: "Failed to fetch display layout" });
    }
  });

  // Create a new display layout
  app.post("/api/display-layouts", async (req, res) => {
    try {
      const parsed = insertDisplayLayoutSchema.parse(req.body);
      const layout = await storage.createDisplayLayout(parsed);
      res.json(layout);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid layout data", details: error.errors });
      }
      console.error("Error creating display layout:", error);
      res.status(500).json({ error: "Failed to create display layout" });
    }
  });

  // Update a display layout
  app.patch("/api/display-layouts/:id", async (req, res) => {
    try {
      const parsed = insertDisplayLayoutSchema.partial().parse(req.body);
      const layout = await storage.updateDisplayLayout(req.params.id, parsed);
      res.json(layout);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid layout data", details: error.errors });
      }
      console.error("Error updating display layout:", error);
      res.status(500).json({ error: "Failed to update display layout" });
    }
  });

  // Delete a display layout
  app.delete("/api/display-layouts/:id", async (req, res) => {
    try {
      await storage.deleteDisplayLayout(req.params.id);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting display layout:", error);
      res.status(500).json({ error: "Failed to delete display layout" });
    }
  });

  // ===== LAYOUT CELLS =====

  // Get all cells for a layout
  app.get("/api/layout-cells/layout/:layoutId", async (req, res) => {
    try {
      const cells = await storage.getLayoutCellsByLayout(req.params.layoutId);
      res.json(cells);
    } catch (error) {
      console.error("Error fetching layout cells:", error);
      res.status(500).json({ error: "Failed to fetch layout cells" });
    }
  });

  // Create a new layout cell
  app.post("/api/layout-cells", async (req, res) => {
    try {
      const parsed = insertLayoutCellSchema.parse(req.body);
      const cell = await storage.createLayoutCell(parsed);
      res.json(cell);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid cell data", details: error.errors });
      }
      console.error("Error creating layout cell:", error);
      res.status(500).json({ error: "Failed to create layout cell" });
    }
  });

  // Update a layout cell
  app.patch("/api/layout-cells/:id", async (req, res) => {
    try {
      const parsed = insertLayoutCellSchema.partial().parse(req.body);
      const cell = await storage.updateLayoutCell(req.params.id, parsed);
      
      // Broadcast layout_update to all connected displays when cell is updated
      // This ensures other clients stay in sync when cells are auto-cleared or manually edited
      broadcastToDisplays({
        type: "layout_update",
        data: { layoutId: cell.layoutId, cellId: cell.id },
      });
      
      res.json(cell);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid cell data", details: error.errors });
      }
      console.error("Error updating layout cell:", error);
      res.status(500).json({ error: "Failed to update layout cell" });
    }
  });

  // Delete a layout cell
  app.delete("/api/layout-cells/:id", async (req, res) => {
    try {
      await storage.deleteLayoutCell(req.params.id);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting layout cell:", error);
      res.status(500).json({ error: "Failed to delete layout cell" });
    }
  });

  // ===== OVERLAY CONTROL =====

  app.post("/api/overlay/show", async (req, res) => {
    try {
      const validated = overlayConfigSchema.parse(req.body);
      
      broadcastToDisplays({
        type: 'overlay_show',
        ...validated
      });
      
      res.json({ success: true });
    } catch (error: any) {
      if (error.name === 'ZodError') {
        res.status(400).json({ error: "Invalid overlay configuration", details: error.errors });
      } else {
        res.status(500).json({ error: error.message });
      }
    }
  });

  app.post("/api/overlay/hide", async (req, res) => {
    try {
      const validated = overlayHideSchema.parse(req.body);
      
      broadcastToDisplays({
        type: 'overlay_hide',
        ...validated
      });
      
      res.json({ success: true });
    } catch (error: any) {
      res.status(400).json({ error: "Invalid overlay type" });
    }
  });

  app.post("/api/overlay/update", async (req, res) => {
    try {
      const validated = overlayUpdateSchema.parse(req.body);
      
      broadcastToDisplays({
        type: 'overlay_update',
        ...validated
      });
      
      res.json({ success: true });
    } catch (error: any) {
      res.status(400).json({ error: "Invalid overlay update configuration" });
    }
  });

  // ===== ATHLETE PHOTOS =====

  // Upload athlete photo
  // Test with: POST /api/athletes/{athleteId}/photo with multipart/form-data photo field
  app.post("/api/athletes/:id/photo", imageUpload.single("photo"), async (req, res) => {
    let photoData: {
      storageKey: string;
      width: number;
      height: number;
      byteSize: number;
      contentType: string;
    } | null = null;

    try {
      const athleteId = req.params.id;

      if (!req.file) {
        return res.status(400).json({ error: "No photo uploaded" });
      }

      const file = req.file;
      const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB

      // Validate file size
      if (file.size > MAX_FILE_SIZE) {
        await unlink(file.path).catch(console.error);
        return res.status(400).json({ 
          error: "File too large. Maximum size is 5MB" 
        });
      }

      // Validate MIME type
      const ALLOWED_TYPES = ['image/jpeg', 'image/png', 'image/gif'];
      if (!ALLOWED_TYPES.includes(file.mimetype)) {
        await unlink(file.path).catch(console.error);
        return res.status(400).json({ 
          error: "Invalid file type. Only JPEG, PNG, and GIF are allowed" 
        });
      }

      // Check if athlete exists
      const athlete = await storage.getAthlete(athleteId);
      if (!athlete) {
        await unlink(file.path).catch(console.error);
        return res.status(404).json({ error: "Athlete not found" });
      }

      // Read file buffer
      const fs = await import('fs/promises');
      const buffer = await fs.readFile(file.path);

      // ATOMIC PATTERN:
      // 1. Save new file to disk first
      photoData = await fileStorage.saveAthletePhoto(
        buffer,
        athleteId,
        athlete.meetId,
        file.originalname
      );

      // Clean up temp file
      await unlink(file.path).catch(console.error);

      // 2. DB transaction: get old, delete old, insert new, return old storageKey
      const { newPhoto, oldPhoto } = await storage.createAthletePhoto({
        athleteId,
        meetId: athlete.meetId,
        storageKey: photoData.storageKey,
        originalFilename: file.originalname,
        contentType: photoData.contentType,
        width: photoData.width,
        height: photoData.height,
        byteSize: photoData.byteSize,
      });

      // 3. Delete old file from disk (only after DB commit succeeds)
      if (oldPhoto && oldPhoto.storageKey) {
        await fileStorage.deleteByKey(oldPhoto.storageKey).catch(console.error);
      }

      // Return photo with URL
      res.json({
        id: newPhoto.id,
        url: fileStorage.publicUrlForKey(newPhoto.storageKey),
        width: newPhoto.width,
        height: newPhoto.height,
        byteSize: newPhoto.byteSize,
      });
    } catch (error: any) {
      console.error("Error uploading athlete photo:", error);
      
      // Cleanup new file if DB transaction failed
      if (photoData && photoData.storageKey) {
        await fileStorage.deleteByKey(photoData.storageKey).catch(console.error);
      }
      
      res.status(500).json({ error: error.message });
    }
  });

  // Get athlete photo
  // Test with: GET /api/athletes/{athleteId}/photo
  app.get("/api/athletes/:id/photo", async (req, res) => {
    try {
      const athleteId = req.params.id;
      const photo = await storage.getAthletePhoto(athleteId);
      
      if (!photo) {
        return res.status(404).json({ error: "Photo not found" });
      }

      res.json({
        id: photo.id,
        url: fileStorage.publicUrlForKey(photo.storageKey),
        width: photo.width,
        height: photo.height,
        byteSize: photo.byteSize,
      });
    } catch (error: any) {
      console.error("Error fetching athlete photo:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // Delete athlete photo
  // Test with: DELETE /api/athletes/{athleteId}/photo
  app.delete("/api/athletes/:id/photo", async (req, res) => {
    try {
      const athleteId = req.params.id;
      
      // Delete from database (returns old record with storageKey)
      const result = await storage.deleteAthletePhoto(athleteId);
      
      if (!result.deleted) {
        return res.status(404).json({ error: "Photo not found" });
      }

      // Delete physical file
      await fileStorage.deleteByKey(result.photo.storageKey);

      res.json({ success: true });
    } catch (error: any) {
      console.error("Error deleting athlete photo:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // Get bulk athlete photos by athlete IDs
  // Test with: GET /api/athletes/photos/bulk?ids=id1,id2,id3
  app.get("/api/athletes/photos/bulk", async (req, res) => {
    try {
      const idsParam = req.query.ids as string;
      
      if (!idsParam) {
        return res.json([]);
      }

      const athleteIds = idsParam.split(',').map(id => id.trim()).filter(Boolean);
      
      if (athleteIds.length === 0) {
        return res.json([]);
      }

      // Fetch photos for all athlete IDs in parallel
      const photoPromises = athleteIds.map(id => storage.getAthletePhoto(id));
      const photos = await Promise.all(photoPromises);

      // Map to response format with public URLs
      const photoData = photos
        .map((photo, index) => {
          if (!photo) return null;
          return {
            athleteId: athleteIds[index],
            url: fileStorage.publicUrlForKey(photo.storageKey),
            width: photo.width,
            height: photo.height,
          };
        })
        .filter(Boolean);

      res.json(photoData);
    } catch (error: any) {
      console.error("Error fetching bulk athlete photos:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // ===== TEAM LOGOS =====

  // Get bulk team logos by team IDs
  // Test with: GET /api/teams/logos/bulk?ids=id1,id2,id3
  app.get("/api/teams/logos/bulk", async (req, res) => {
    try {
      const idsParam = req.query.ids as string;
      
      if (!idsParam) {
        return res.json([]);
      }

      const teamIds = idsParam.split(',').map(id => id.trim()).filter(Boolean);
      
      if (teamIds.length === 0) {
        return res.json([]);
      }

      // Fetch logos for all team IDs in parallel
      const logoPromises = teamIds.map(id => storage.getTeamLogo(id));
      const logos = await Promise.all(logoPromises);

      // Map to response format with public URLs
      const logoData = logos
        .map((logo, index) => {
          if (!logo) return null;
          return {
            teamId: teamIds[index],
            url: fileStorage.publicUrlForKey(logo.storageKey),
            width: logo.width,
            height: logo.height,
          };
        })
        .filter(Boolean);

      res.json(logoData);
    } catch (error: any) {
      console.error("Error fetching bulk team logos:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // Upload team logo
  // Test with: POST /api/teams/{teamId}/logo with multipart/form-data logo field
  app.post("/api/teams/:id/logo", imageUpload.single("logo"), async (req, res) => {
    let logoData: {
      storageKey: string;
      width: number;
      height: number;
      byteSize: number;
      contentType: string;
    } | null = null;

    try {
      const teamId = req.params.id;

      if (!req.file) {
        return res.status(400).json({ error: "No logo uploaded" });
      }

      const file = req.file;
      const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB

      if (file.size > MAX_FILE_SIZE) {
        return res.status(400).json({ 
          error: "File too large. Maximum size is 5MB" 
        });
      }

      const ALLOWED_TYPES = ['image/jpeg', 'image/png', 'image/gif'];
      if (!ALLOWED_TYPES.includes(file.mimetype)) {
        return res.status(400).json({ 
          error: "Invalid file type. Only JPEG, PNG, and GIF are allowed" 
        });
      }

      const team = await storage.getTeam(teamId);
      if (!team) {
        return res.status(404).json({ error: "Team not found" });
      }

      const buffer = file.buffer;

      logoData = await fileStorage.saveTeamLogo(
        buffer,
        teamId,
        team.meetId,
        file.originalname
      );

      // 2. DB transaction: get old, delete old, insert new, return old storageKey
      const { newLogo, oldLogo } = await storage.createTeamLogo({
        teamId,
        meetId: team.meetId,
        storageKey: logoData.storageKey,
        originalFilename: file.originalname,
        contentType: logoData.contentType,
        width: logoData.width,
        height: logoData.height,
        byteSize: logoData.byteSize,
      });

      // 3. Delete old file from disk (only after DB commit succeeds)
      if (oldLogo && oldLogo.storageKey) {
        await fileStorage.deleteByKey(oldLogo.storageKey).catch(console.error);
      }

      // Return logo with URL
      res.json({
        id: newLogo.id,
        url: fileStorage.publicUrlForKey(newLogo.storageKey),
        width: newLogo.width,
        height: newLogo.height,
        byteSize: newLogo.byteSize,
      });
    } catch (error: any) {
      console.error("Error uploading team logo:", error);
      
      // Cleanup new file if DB transaction failed
      if (logoData && logoData.storageKey) {
        await fileStorage.deleteByKey(logoData.storageKey).catch(console.error);
      }
      
      res.status(500).json({ error: error.message });
    }
  });

  // Get team logo
  // Test with: GET /api/teams/{teamId}/logo
  app.get("/api/teams/:id/logo", async (req, res) => {
    try {
      const teamId = req.params.id;
      const logo = await storage.getTeamLogo(teamId);
      
      if (!logo) {
        return res.status(404).json({ error: "Logo not found" });
      }

      res.json({
        id: logo.id,
        url: fileStorage.publicUrlForKey(logo.storageKey),
        width: logo.width,
        height: logo.height,
        byteSize: logo.byteSize,
      });
    } catch (error: any) {
      console.error("Error fetching team logo:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // Delete team logo
  // Test with: DELETE /api/teams/{teamId}/logo
  app.delete("/api/teams/:id/logo", async (req, res) => {
    try {
      const teamId = req.params.id;
      
      // Delete from database (returns old record with storageKey)
      const result = await storage.deleteTeamLogo(teamId);
      
      if (!result.deleted) {
        return res.status(404).json({ error: "Logo not found" });
      }

      // Delete physical file
      await fileStorage.deleteByKey(result.logo.storageKey);

      res.json({ success: true });
    } catch (error: any) {
      console.error("Error deleting team logo:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // ===== NCAA LOGO LOOKUP =====

  // Get NCAA logo URL for a team name (matches team name to pre-loaded NCAA logos)
  // Test with: GET /api/ncaa-logo?name=Bucknell
  app.get("/api/ncaa-logo", async (req, res) => {
    try {
      const teamName = req.query.name as string;
      
      if (!teamName) {
        return res.status(400).json({ error: "Team name is required" });
      }

      const fs = await import('fs/promises');
      const path = await import('path');
      const logosDir = path.join(process.cwd(), 'public', 'logos', 'NCAA');
      
      // Try to find matching logo file
      let logoPath: string | null = null;
      
      try {
        const files = await fs.readdir(logosDir);
        
        // Try exact match first (case-insensitive)
        const exactMatch = files.find(f => 
          f.toLowerCase() === `${teamName.toLowerCase()}.png`
        );
        
        if (exactMatch) {
          logoPath = `/logos/NCAA/${exactMatch}`;
        } else {
          // Normalize function for consistent matching
          const normalize = (s: string) => s.toLowerCase()
            .replace(/\./g, '')  // Remove periods
            .replace(/\s+/g, ' ') // Normalize spaces
            .trim();
          
          const normalizedName = normalize(teamName);
          
          const normalizedMatch = files.find(f => {
            const fileName = normalize(f.replace('.png', ''));
            return fileName === normalizedName;
          });
          
          if (normalizedMatch) {
            logoPath = `/logos/NCAA/${normalizedMatch}`;
          }
        }
      } catch (dirError) {
        // Directory doesn't exist
        console.warn("NCAA logos directory not found");
      }

      if (logoPath) {
        res.json({ url: logoPath, teamName });
      } else {
        res.status(404).json({ error: "Logo not found", teamName });
      }
    } catch (error: any) {
      console.error("Error looking up NCAA logo:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // Get NCAA logos for multiple teams at once
  // Test with: GET /api/ncaa-logos/bulk?names=Bucknell,Lehigh,Lafayette
  app.get("/api/ncaa-logos/bulk", async (req, res) => {
    try {
      const namesParam = req.query.names as string;
      
      if (!namesParam) {
        return res.json([]);
      }

      const teamNames = namesParam.split(',').map(n => n.trim()).filter(Boolean);
      
      if (teamNames.length === 0) {
        return res.json([]);
      }

      const fs = await import('fs/promises');
      const path = await import('path');
      const logosDir = path.join(process.cwd(), 'public', 'logos', 'NCAA');
      
      let files: string[] = [];
      try {
        files = await fs.readdir(logosDir);
      } catch (dirError) {
        return res.json([]);
      }

      // Normalize function for consistent matching
      const normalize = (s: string) => s.toLowerCase()
        .replace(/\./g, '')  // Remove periods
        .replace(/\s+/g, ' ') // Normalize spaces
        .trim();

      const results = teamNames.map(teamName => {
        // Try exact match first (case-insensitive)
        const exactMatch = files.find(f => 
          f.toLowerCase() === `${teamName.toLowerCase()}.png`
        );
        
        if (exactMatch) {
          return { teamName, url: `/logos/NCAA/${exactMatch}` };
        }
        
        // Try normalized matching
        const normalizedName = normalize(teamName);
        
        const normalizedMatch = files.find(f => {
          const fileName = normalize(f.replace('.png', ''));
          return fileName === normalizedName;
        });
        
        if (normalizedMatch) {
          return { teamName, url: `/logos/NCAA/${normalizedMatch}` };
        }
        
        return { teamName, url: null };
      });

      res.json(results);
    } catch (error: any) {
      console.error("Error looking up bulk NCAA logos:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // List all available NCAA logos
  // Test with: GET /api/ncaa-logos
  app.get("/api/ncaa-logos", async (req, res) => {
    try {
      const fs = await import('fs/promises');
      const path = await import('path');
      const logosDir = path.join(process.cwd(), 'public', 'logos', 'NCAA');
      
      const files = await fs.readdir(logosDir);
      const logos = files
        .filter(f => f.endsWith('.png') && f !== '0.png')
        .map(f => ({
          name: f.replace('.png', ''),
          url: `/logos/NCAA/${f}`
        }))
        .sort((a, b) => a.name.localeCompare(b.name));

      res.json({ count: logos.length, logos });
    } catch (error: any) {
      console.error("Error listing NCAA logos:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // MDB File Import
  app.post("/api/import/mdb", upload.single("mdbFile"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No file uploaded" });
      }

      const file = req.file;
      const filePath = file.path;

      // Validate file extension
      const originalName = file.originalname.toLowerCase();
      if (!originalName.endsWith(".mdb")) {
        // Clean up uploaded file
        await unlink(filePath).catch(console.error);
        return res.status(400).json({ 
          error: "Invalid file type. Only .mdb files are allowed" 
        });
      }

      console.log(`📁 Processing MDB import: ${file.originalname}`);

      // Get or create meet for this import
      const { meetId, meetName } = req.body;
      let targetMeetId: string;

      if (meetId) {
        // Verify meet exists
        const existingMeet = await storage.getMeet(meetId);
        if (!existingMeet) {
          await unlink(filePath).catch(console.error);
          return res.status(404).json({ error: "Meet not found" });
        }
        targetMeetId = meetId;
        console.log(`📍 Importing to existing meet: ${existingMeet.name} (${targetMeetId})`);
      } else {
        // Create new meet
        const newMeet = await storage.createMeet({
          name: meetName || file.originalname.replace('.mdb', ''),
          startDate: new Date(),
          location: null,
        });
        targetMeetId = newMeet.id;
        console.log(`📍 Created new meet: ${newMeet.name} (${targetMeetId})`);
      }

      // Clear existing import data before re-importing
      const clearStats = await storage.clearMeetImportData(targetMeetId);
      console.log(`🧹 Pre-import clear: ${JSON.stringify(clearStats)}`);

      // Run the import with meetId
      const stats = await importCompleteMDB(filePath, targetMeetId);

      // Delete the temporary file after successful import
      await unlink(filePath).catch((err) => {
        console.warn(`⚠️  Failed to delete temporary file: ${filePath}`, err);
      });

      // Broadcast current event after successful import
      await broadcastCurrentEvent();

      console.log(`✅ Import complete: ${JSON.stringify(stats)}`);

      // Return statistics
      res.json({
        success: true,
        message: "Import completed successfully",
        meetId: targetMeetId,
        statistics: stats,
      });
    } catch (error: any) {
      console.error("❌ Import failed:", error);

      // Clean up the file if it exists
      if (req.file) {
        await unlink(req.file.path).catch(console.error);
      }

      res.status(500).json({ 
        error: "Import failed", 
        details: error.message 
      });
    }
  });

  // =============================
  // COMPOSITE LAYOUTS API ROUTES
  // =============================

  // List all layouts (optionally filtered by meetId)
  app.get('/api/layouts', async (req, res) => {
    try {
      const meetId = req.query.meetId as string | undefined;
      const layouts = await storage.listLayouts(meetId);
      res.json(layouts);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get single layout by ID
  app.get('/api/layouts/:id', async (req, res) => {
    try {
      const layout = await storage.getLayout(parseInt(req.params.id));
      if (!layout) {
        return res.status(404).json({ error: 'Layout not found' });
      }
      res.json(layout);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get layout with all its zones
  app.get('/api/layouts/:id/with-zones', async (req, res) => {
    try {
      const result = await storage.getLayoutWithZones(parseInt(req.params.id));
      if (!result) {
        return res.status(404).json({ error: 'Layout not found' });
      }
      res.json(result);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Create new layout
  app.post('/api/layouts', async (req, res) => {
    try {
      const parsed = insertCompositeLayoutSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: parsed.error.errors });
      }
      const layout = await storage.createLayout(parsed.data);
      res.status(201).json(layout);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Update layout
  app.patch('/api/layouts/:id', async (req, res) => {
    try {
      const layout = await storage.updateLayout(parseInt(req.params.id), req.body);
      if (!layout) {
        return res.status(404).json({ error: 'Layout not found' });
      }
      res.json(layout);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Delete layout
  app.delete('/api/layouts/:id', async (req, res) => {
    try {
      const success = await storage.deleteLayout(parseInt(req.params.id));
      if (!success) {
        return res.status(404).json({ error: 'Layout not found' });
      }
      res.status(204).send();
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get zones for a specific layout
  app.get('/api/layouts/:id/zones', async (req, res) => {
    try {
      const zones = await storage.getZonesByLayout(parseInt(req.params.id));
      res.json(zones);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // =============================
  // LAYOUT ZONES API ROUTES
  // =============================

  // Create new zone
  app.post('/api/zones', async (req, res) => {
    try {
      console.log('[POST /api/zones] Incoming request body:', JSON.stringify(req.body, null, 2));
      
      const parsed = insertLayoutZoneSchema.safeParse(req.body);
      if (!parsed.success) {
        console.error('[POST /api/zones] Validation error:', parsed.error.errors);
        return res.status(400).json({ error: parsed.error.errors });
      }
      
      console.log('[POST /api/zones] Validated data:', JSON.stringify(parsed.data, null, 2));
      console.log('[POST /api/zones] dataBinding type:', typeof parsed.data.dataBinding, 'value:', parsed.data.dataBinding);
      console.log('[POST /api/zones] boardConfig type:', typeof parsed.data.boardConfig, 'value:', parsed.data.boardConfig);
      
      const zone = await storage.createZone(parsed.data);
      
      console.log('[POST /api/zones] Created zone:', JSON.stringify(zone, null, 2));
      console.log('[POST /api/zones] Returned dataBinding type:', typeof zone.dataBinding, 'value:', zone.dataBinding);
      
      res.status(201).json(zone);
    } catch (error: any) {
      console.error('[POST /api/zones] Error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // Update zone
  app.patch('/api/zones/:id', async (req, res) => {
    try {
      console.log(`[PATCH /api/zones/${req.params.id}] Incoming request body:`, JSON.stringify(req.body, null, 2));
      
      const parsed = updateLayoutZoneSchema.safeParse(req.body);
      if (!parsed.success) {
        console.error(`[PATCH /api/zones/${req.params.id}] Validation error:`, parsed.error.errors);
        return res.status(400).json({ error: parsed.error.errors });
      }
      
      console.log(`[PATCH /api/zones/${req.params.id}] Validated data:`, JSON.stringify(parsed.data, null, 2));
      if (parsed.data.dataBinding) {
        console.log(`[PATCH /api/zones/${req.params.id}] dataBinding type:`, typeof parsed.data.dataBinding, 'value:', parsed.data.dataBinding);
      }
      if (parsed.data.boardConfig) {
        console.log(`[PATCH /api/zones/${req.params.id}] boardConfig type:`, typeof parsed.data.boardConfig, 'value:', parsed.data.boardConfig);
      }
      
      const zone = await storage.updateZone(parseInt(req.params.id), parsed.data);
      if (!zone) {
        return res.status(404).json({ error: 'Zone not found' });
      }
      
      console.log(`[PATCH /api/zones/${req.params.id}] Updated zone:`, JSON.stringify(zone, null, 2));
      console.log(`[PATCH /api/zones/${req.params.id}] Returned dataBinding type:`, typeof zone.dataBinding, 'value:', zone.dataBinding);
      
      res.json(zone);
    } catch (error: any) {
      console.error(`[PATCH /api/zones/${req.params.id}] Error:`, error);
      res.status(500).json({ error: error.message });
    }
  });

  // Delete zone
  app.delete('/api/zones/:id', async (req, res) => {
    try {
      const success = await storage.deleteZone(parseInt(req.params.id));
      if (!success) {
        return res.status(404).json({ error: 'Zone not found' });
      }
      res.status(204).send();
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // =============================
  // LAYOUT TEMPLATES API ROUTES
  // =============================

  // Get all available layout templates
  app.get('/api/layout-templates', async (req, res) => {
    try {
      const { LAYOUT_TEMPLATES, DISPLAY_TYPES } = await import('@shared/layout-templates');
      const displayType = req.query.displayType as string | undefined;
      const category = req.query.category as string | undefined;
      
      let templates = LAYOUT_TEMPLATES;
      if (displayType) {
        templates = templates.filter(t => t.displayType === displayType);
      }
      if (category) {
        templates = templates.filter(t => t.category === category);
      }
      
      res.json({ templates, displayTypes: DISPLAY_TYPES });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Apply a layout template (creates layout + zones)
  app.post('/api/layout-templates/:templateId/apply', async (req, res) => {
    try {
      const { getTemplateById } = await import('@shared/layout-templates');
      const template = getTemplateById(req.params.templateId);
      
      if (!template) {
        return res.status(404).json({ error: 'Template not found' });
      }
      
      // Optional custom name from request body
      const customName = req.body.name || template.name;
      const customDescription = req.body.description || template.description;
      
      // Create the layout
      const layout = await storage.createLayout({
        name: customName,
        description: customDescription,
        aspectRatio: template.aspectRatio,
        baseTheme: 'stadium',
      });
      
      // Create all zones for this layout - validate each zone through schema
      for (const zoneTemplate of template.zones) {
        const zoneData = {
          layoutId: layout.id,
          order: zoneTemplate.order,
          xPercent: zoneTemplate.xPercent,
          yPercent: zoneTemplate.yPercent,
          widthPercent: zoneTemplate.widthPercent,
          heightPercent: zoneTemplate.heightPercent,
          boardType: zoneTemplate.boardType,
          dataBinding: zoneTemplate.dataBinding as any,
          boardConfig: zoneTemplate.boardConfig as any,
          stylePreset: zoneTemplate.stylePreset || 'none',
        };
        
        // Validate through the schema
        const parsed = insertLayoutZoneSchema.safeParse(zoneData);
        if (!parsed.success) {
          console.error('Zone validation failed for template', template.id, ':', parsed.error.errors);
          throw new Error(`Zone validation failed: ${parsed.error.errors.map(e => e.message).join(', ')}`);
        }
        
        await storage.createZone(parsed.data);
      }
      
      // Return the created layout with zones
      const result = await storage.getLayoutWithZones(layout.id);
      res.status(201).json(result);
    } catch (error: any) {
      console.error('Error applying template:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // ===== LAYOUT SCENES API ROUTES =====

  // Get all scenes (optional ?meetId= filter)
  app.get('/api/layout-scenes', async (req, res) => {
    try {
      const meetId = req.query.meetId as string | undefined;
      const scenes = await storage.getLayoutScenes(meetId);
      res.json(scenes);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get single scene with all objects
  app.get('/api/layout-scenes/:id', async (req, res) => {
    try {
      const scene = await storage.getLayoutScene(parseInt(req.params.id));
      if (!scene) {
        return res.status(404).json({ error: 'Scene not found' });
      }
      res.json(scene);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Create new scene
  app.post('/api/layout-scenes', async (req, res) => {
    try {
      const parsed = insertLayoutSceneSchema.parse(req.body);
      const scene = await storage.createLayoutScene(parsed);
      res.status(201).json(scene);
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: 'Invalid scene data', details: error.errors });
      }
      res.status(500).json({ error: error.message });
    }
  });

  // Update scene (with objects)
  app.patch('/api/layout-scenes/:id', async (req, res) => {
    try {
      const sceneId = parseInt(req.params.id);
      const { objects, ...sceneData } = req.body;
      
      // Update scene metadata
      const parsed = insertLayoutSceneSchema.partial().parse(sceneData);
      const scene = await storage.updateLayoutScene(sceneId, parsed);
      if (!scene) {
        return res.status(404).json({ error: 'Scene not found' });
      }
      
      // If objects array is provided, replace all objects
      if (Array.isArray(objects)) {
        // Delete existing objects for this scene
        const existingObjects = await storage.getLayoutObjects(sceneId);
        for (const obj of existingObjects) {
          await storage.deleteLayoutObject(obj.id);
        }
        
        // Create new objects
        for (const obj of objects) {
          await storage.createLayoutObject({ ...obj, sceneId });
        }
      }
      
      // Return updated scene with objects
      const updatedScene = await storage.getLayoutScene(sceneId);
      
      // Broadcast scene update to all connected displays for real-time updates
      broadcastToDisplays({
        type: 'scene_update',
        data: { sceneId, scene: updatedScene }
      });
      
      res.json(updatedScene);
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: 'Invalid scene data', details: error.errors });
      }
      res.status(500).json({ error: error.message });
    }
  });

  // Delete scene
  app.delete('/api/layout-scenes/:id', async (req, res) => {
    try {
      const success = await storage.deleteLayoutScene(parseInt(req.params.id));
      if (!success) {
        return res.status(404).json({ error: 'Scene not found' });
      }
      res.status(204).send();
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // ===== LAYOUT OBJECTS API ROUTES =====

  // Get all objects in a scene (via query parameter)
  app.get('/api/layout-objects', async (req, res) => {
    try {
      const sceneIdParam = req.query.sceneId;
      if (!sceneIdParam) {
        return res.json([]);
      }
      const sceneId = parseInt(sceneIdParam as string);
      if (isNaN(sceneId)) {
        return res.status(400).json({ error: 'Invalid sceneId' });
      }
      const objects = await storage.getLayoutObjects(sceneId);
      res.json(objects);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get all objects in a scene (via path parameter)
  app.get('/api/layout-scenes/:sceneId/objects', async (req, res) => {
    try {
      const objects = await storage.getLayoutObjects(parseInt(req.params.sceneId));
      res.json(objects);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get single object
  app.get('/api/layout-objects/:id', async (req, res) => {
    try {
      const object = await storage.getLayoutObject(parseInt(req.params.id));
      if (!object) {
        return res.status(404).json({ error: 'Object not found' });
      }
      res.json(object);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Create new object in scene
  app.post('/api/layout-scenes/:sceneId/objects', async (req, res) => {
    try {
      const sceneId = parseInt(req.params.sceneId);
      const parsed = insertLayoutObjectSchema.parse({ ...req.body, sceneId });
      const object = await storage.createLayoutObject(parsed);
      res.status(201).json(object);
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: 'Invalid object data', details: error.errors });
      }
      res.status(500).json({ error: error.message });
    }
  });

  // Update object
  app.patch('/api/layout-objects/:id', async (req, res) => {
    try {
      const parsed = insertLayoutObjectSchema.partial().parse(req.body);
      const object = await storage.updateLayoutObject(parseInt(req.params.id), parsed);
      if (!object) {
        return res.status(404).json({ error: 'Object not found' });
      }
      
      // Broadcast object update to all connected displays for real-time updates
      broadcastToDisplays({
        type: 'scene_update',
        data: { sceneId: object.sceneId, objectId: object.id }
      });
      
      res.json(object);
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: 'Invalid object data', details: error.errors });
      }
      res.status(500).json({ error: error.message });
    }
  });

  // Delete object
  app.delete('/api/layout-objects/:id', async (req, res) => {
    try {
      const success = await storage.deleteLayoutObject(parseInt(req.params.id));
      if (!success) {
        return res.status(404).json({ error: 'Object not found' });
      }
      res.status(204).send();
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Reorder objects in a scene
  app.post('/api/layout-scenes/:sceneId/objects/reorder', async (req, res) => {
    try {
      const sceneId = parseInt(req.params.sceneId);
      const { objectIds } = req.body;
      
      if (!Array.isArray(objectIds) || !objectIds.every(id => typeof id === 'number')) {
        return res.status(400).json({ error: 'objectIds must be an array of numbers' });
      }
      
      const objects = await storage.reorderObjects(sceneId, objectIds);
      res.json(objects);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });
  
  // Batch update objects positions (for alignment/distribute operations)
  app.post('/api/layout-objects/batch-update', async (req, res) => {
    try {
      const { updates } = req.body as { updates: Array<{ id: number; data: { x?: number; y?: number; width?: number; height?: number } }> };
      
      if (!Array.isArray(updates) || updates.length === 0) {
        return res.status(400).json({ error: 'updates must be a non-empty array' });
      }
      
      // Validate each update
      for (const update of updates) {
        if (typeof update.id !== 'number' || !update.data) {
          return res.status(400).json({ error: 'Each update must have id (number) and data' });
        }
      }
      
      // Process all updates and track results
      const results: Array<{ id: number; success: boolean; object?: any; error?: string }> = [];
      
      for (const { id, data } of updates) {
        try {
          const parsed = insertLayoutObjectSchema.partial().parse(data);
          const object = await storage.updateLayoutObject(id, parsed);
          if (object) {
            results.push({ id, success: true, object });
          } else {
            results.push({ id, success: false, error: 'Object not found' });
          }
        } catch (err: any) {
          results.push({ id, success: false, error: err.message || 'Update failed' });
        }
      }
      
      // Check if any updates failed
      const failures = results.filter(r => !r.success);
      if (failures.length > 0) {
        return res.status(207).json({
          message: `${failures.length} of ${updates.length} updates failed`,
          results,
          failedIds: failures.map(f => f.id),
        });
      }
      
      res.json({ success: true, results });
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: 'Invalid object data', details: error.errors });
      }
      res.status(500).json({ error: error.message });
    }
  });

  // Scene Template Mappings - assign custom scenes to display types and modes
  app.get('/api/scene-template-mappings/:meetId', async (req, res) => {
    try {
      const mappings = await storage.getSceneTemplateMappings(req.params.meetId);
      res.json(mappings);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get('/api/scene-template-mappings/:meetId/:displayType/:displayMode', async (req, res) => {
    try {
      const { meetId, displayType, displayMode } = req.params;
      const mapping = await storage.getSceneTemplateMappingByTypeAndMode(meetId, displayType, displayMode);
      if (!mapping) {
        return res.status(404).json({ error: 'Mapping not found' });
      }
      res.json(mapping);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/scene-template-mappings', async (req, res) => {
    try {
      const { meetId, displayType, displayMode, sceneId } = req.body;
      
      if (!meetId || !displayType || !displayMode || !sceneId) {
        return res.status(400).json({ error: 'Missing required fields: meetId, displayType, displayMode, sceneId' });
      }
      
      const mapping = await storage.setSceneTemplateMapping({
        meetId,
        displayType,
        displayMode,
        sceneId: parseInt(sceneId),
      });
      
      // Broadcast mapping change to all displays so they update without refresh
      broadcastToDisplays({
        type: 'scene_mapping_changed',
        meetId,
        displayType,
        displayMode,
        sceneId: parseInt(sceneId),
      });
      
      res.json(mapping);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.delete('/api/scene-template-mappings/:id', async (req, res) => {
    try {
      const success = await storage.deleteSceneTemplateMapping(parseInt(req.params.id));
      if (!success) {
        return res.status(404).json({ error: 'Mapping not found' });
      }
      res.status(204).send();
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // ===== SCENE EXPORT/IMPORT =====
  
  // Export all scenes for a meet (or all scenes if no meetId provided)
  app.get('/api/scenes/export', async (req, res) => {
    try {
      const meetId = req.query.meetId as string | undefined;
      const scenes = await storage.getLayoutScenes(meetId);
      
      // Get objects for each scene
      const scenesWithObjects = await Promise.all(
        scenes.map(async (scene) => {
          const objects = await storage.getLayoutObjects(scene.id);
          return {
            ...scene,
            objects,
          };
        })
      );
      
      const exportData = {
        version: '1.0',
        exportedAt: new Date().toISOString(),
        meetId: meetId || null,
        scenes: scenesWithObjects,
      };
      
      res.setHeader('Content-Type', 'application/json');
      res.setHeader('Content-Disposition', `attachment; filename="scenes-export-${Date.now()}.json"`);
      res.json(exportData);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });
  
  // Import scenes from JSON
  app.post('/api/scenes/import', async (req, res) => {
    try {
      const { scenes, targetMeetId, replaceExisting } = req.body;
      
      if (!scenes || !Array.isArray(scenes)) {
        return res.status(400).json({ error: 'Invalid import data: scenes array required' });
      }
      
      const importResults: Array<{ originalId: number; newId: number; name: string; objectCount: number }> = [];
      
      // If replaceExisting, delete existing scenes for this meet first
      if (replaceExisting && targetMeetId) {
        const existingScenes = await storage.getLayoutScenes(targetMeetId);
        for (const scene of existingScenes) {
          await storage.deleteLayoutScene(scene.id);
        }
      }
      
      for (const sceneData of scenes) {
        const { objects, id: originalId, ...sceneFields } = sceneData;
        
        // Create the scene with the target meet ID if provided
        const newScene = await storage.createLayoutScene({
          ...sceneFields,
          meetId: targetMeetId || sceneFields.meetId,
        });
        
        let objectCount = 0;
        
        // Create objects for this scene
        if (objects && Array.isArray(objects)) {
          for (const objData of objects) {
            const { id: _objId, sceneId: _sceneId, ...objectFields } = objData;
            await storage.createLayoutObject({
              ...objectFields,
              sceneId: newScene.id,
            });
            objectCount++;
          }
        }
        
        importResults.push({
          originalId,
          newId: newScene.id,
          name: newScene.name,
          objectCount,
        });
      }
      
      res.json({
        success: true,
        imported: importResults.length,
        scenes: importResults,
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // ARCHIVED: Record books feature (first set)

  app.get('/api/records/check', async (req, res) => {
    try {
      const { eventType, performance, gender } = req.query;
      
      if (!eventType || !performance || !gender) {
        return res.status(400).json({ 
          error: 'Missing required parameters: eventType, performance, gender' 
        });
      }
      
      const checks = await storage.checkForRecords(
        eventType as string,
        gender as string,
        performance as string
      );
      
      res.json(checks);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get('/api/records/:id', async (req, res) => {
    try {
      const record = await storage.getRecord(parseInt(req.params.id));
      if (!record) {
        return res.status(404).json({ error: 'Record not found' });
      }
      res.json(record);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/records', async (req, res) => {
    try {
      const data = insertRecordSchema.parse(req.body);
      const record = await storage.createRecord(data);
      res.json(record);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.patch('/api/records/:id', async (req, res) => {
    try {
      const data = insertRecordSchema.partial().parse(req.body);
      const record = await storage.updateRecord(parseInt(req.params.id), data);
      if (!record) {
        return res.status(404).json({ error: 'Record not found' });
      }
      res.json(record);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.delete('/api/records/:id', async (req, res) => {
    try {
      await storage.deleteRecord(parseInt(req.params.id));
      res.status(204).send();
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // ARCHIVED: Team scoring calculation feature (MDB team score import still active)

  // Get meet scoring configuration
  app.get('/api/meets/:meetId/scoring', async (req, res) => {
    try {
      const profile = await storage.getMeetScoringProfile(req.params.meetId);
      
      // If no profile exists, return sensible defaults so UI can configure
      if (!profile) {
        const presets = await storage.getScoringPresets();
        const defaultPreset = presets.find(p => p.category === 'invitational') || presets[0];
        
        return res.json({
          meetId: req.params.meetId,
          presetId: defaultPreset?.id || 1,
          genderMode: 'combined',
          divisionMode: 'overall',
          allowRelayScoring: true,
          overrides: []
        });
      }
      
      const overrides = await storage.getMeetScoringOverrides(profile.id);
      res.json({ ...profile, overrides }); // Flatten into single object
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get('/api/meets/:meetId/scoring/standings', async (req, res) => {
    try {
      const meetId = req.params.meetId;
      const gender = req.query.gender as string | undefined;
      const division = req.query.division as string | undefined;

      const scope: { gender?: string; division?: string } = {};
      if (gender && gender !== 'all') scope.gender = gender;
      if (division && division !== 'all') scope.division = division;

      const standings = await storage.getTeamStandings(meetId, Object.keys(scope).length > 0 ? scope : undefined);

      res.json(standings);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Update meet scoring configuration
  app.put('/api/meets/:meetId/scoring', async (req, res) => {
    try {
      const { overrides, ...profileData } = req.body;
      
      // Validate profile data
      const validated = insertMeetScoringProfileSchema.parse({
        ...profileData,
        meetId: req.params.meetId,
      });
      
      // Upsert profile
      const profile = await storage.upsertMeetScoringProfile(validated);
      
      // Only handle overrides if explicitly provided (not undefined)
      if (overrides !== undefined && Array.isArray(overrides)) {
        // Delete existing overrides for this profile
        await storage.deleteScoringOverrides(profile.id);
        
        // Insert new overrides
        for (const override of overrides) {
          await storage.upsertScoringOverride({
            profileId: profile.id,
            eventId: override.eventId,
            pointsMap: override.pointsMap,
            relayMultiplier: override.relayMultiplier,
          });
        }
      }
      
      // Broadcast scoring update
      broadcastToDisplays({
        type: 'team_scoring_update',
        meetId: req.params.meetId
      });
      
      // Return updated profile with overrides
      const updatedOverrides = await storage.getMeetScoringOverrides(profile.id);
      res.json({ ...profile, overrides: updatedOverrides });
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid scoring configuration", details: error.errors });
      }
      res.status(400).json({ error: error.message });
    }
  });

  // Get event points breakdown
  app.get('/api/events/:eventId/points', async (req, res) => {
    try {
      const breakdown = await storage.getEventPoints(req.params.eventId);
      res.json(breakdown);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // ARCHIVED: Record books feature (second set)

  // ARCHIVED: Sponsor system

  // ===== MEDAL TRACKING =====

  // Get medal standings for meet
  app.get("/api/meets/:meetId/medal-standings", async (req, res) => {
    const standings = await storage.getMedalStandings(req.params.meetId);
    res.json(standings);
  });

  // Get medal awards for meet
  app.get("/api/meets/:meetId/medal-awards", async (req, res) => {
    const awards = await storage.getMedalAwards(req.params.meetId);
    res.json(awards);
  });

  // Get medal awards for event
  app.get("/api/events/:eventId/medal-awards", async (req, res) => {
    const awards = await storage.getEventMedalAwards(req.params.eventId);
    res.json(awards);
  });

  // Recompute medals for event
  app.post("/api/events/:eventId/medal-recompute", async (req, res) => {
    const event = await storage.getEvent(req.params.eventId);
    if (!event) {
      return res.status(404).json({ error: "Event not found" });
    }
    
    await storage.recomputeMedalsForEvent(req.params.eventId);
    
    // Get updated standings
    const standings = await storage.getMedalStandings(event.meetId);
    
    // Broadcast update
    broadcastToDisplays({
      type: 'medal_standings_update',
      meetId: event.meetId,
      standings
    });
    
    res.json({ success: true, standings });
  });

  // Recompute medals for entire meet
  app.post("/api/meets/:meetId/medal-recompute-all", async (req, res) => {
    const meet = await storage.getMeet(req.params.meetId);
    if (!meet) {
      return res.status(404).json({ error: "Meet not found" });
    }
    
    // Get all completed events
    const allEvents = await storage.getEventsByMeetId(req.params.meetId);
    const completedEvents = allEvents.filter(e => e.status === 'completed');
    
    // Recompute medals for each event
    for (const event of completedEvents) {
      await storage.recomputeMedalsForEvent(event.id);
    }
    
    const standings = await storage.getMedalStandings(req.params.meetId);
    
    broadcastToDisplays({
      type: 'medal_standings_update',
      meetId: req.params.meetId,
      standings
    });
    
    res.json({ success: true, standings });
  });

  // ===== COMBINED EVENTS (Decathlon/Heptathlon) =====

  // Get combined events for meet
  app.get("/api/meets/:meetId/combined-events", async (req, res) => {
    const events = await storage.getCombinedEvents(req.params.meetId);
    res.json(events);
  });

  // Get combined event
  app.get("/api/combined-events/:id", async (req, res) => {
    const event = await storage.getCombinedEvent(parseInt(req.params.id));
    if (!event) {
      return res.status(404).json({ error: "Combined event not found" });
    }
    res.json(event);
  });

  // Create combined event
  app.post("/api/combined-events", async (req, res) => {
    try {
      const validated = insertCombinedEventSchema.parse(req.body);
      const event = await storage.createCombinedEvent(validated);
      res.json(event);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid request", details: error.errors });
      }
      throw error;
    }
  });

  // Get combined event components
  app.get("/api/combined-events/:id/components", async (req, res) => {
    const components = await storage.getCombinedEventComponents(parseInt(req.params.id));
    res.json(components);
  });

  // Add component to combined event
  app.post("/api/combined-events/:id/components", async (req, res) => {
    try {
      const validated = insertCombinedEventComponentSchema.parse(req.body);
      const component = await storage.createCombinedEventComponent({
        ...validated,
        combinedEventId: parseInt(req.params.id)
      });
      res.json(component);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid request", details: error.errors });
      }
      throw error;
    }
  });

  // Get combined event standings
  app.get("/api/combined-events/:id/standings", async (req, res) => {
    const standings = await storage.getCombinedEventStandings(parseInt(req.params.id));
    res.json(standings);
  });

  // Recompute combined event totals
  app.post("/api/combined-events/:id/recompute", async (req, res) => {
    const event = await storage.getCombinedEvent(parseInt(req.params.id));
    if (!event) {
      return res.status(404).json({ error: "Combined event not found" });
    }
    
    await storage.updateCombinedEventTotals(event.id);
    const standings = await storage.getCombinedEventStandings(event.id);
    
    broadcastToDisplays({
      type: 'combined_event_update',
      meetId: event.meetId,
      combinedEventId: event.id,
      standings
    });
    
    res.json({ success: true, standings });
  });
  
  // Add athlete to combined event
  app.post("/api/combined-events/:id/athletes", async (req, res) => {
    try {
      const { athleteId } = req.body;
      const combinedEventId = parseInt(req.params.id);
      
      const event = await storage.getCombinedEvent(combinedEventId);
      if (!event) {
        return res.status(404).json({ error: "Combined event not found" });
      }
      
      await storage.addAthleteToCombinedEvent(combinedEventId, athleteId);
      res.json({ success: true });
    } catch (error) {
      console.error("Failed to add athlete to combined event:", error);
      res.status(500).json({ error: "Failed to add athlete" });
    }
  });
  
  // Remove athlete from combined event
  app.delete("/api/combined-events/:id/athletes/:athleteId", async (req, res) => {
    try {
      const combinedEventId = parseInt(req.params.id);
      const { athleteId } = req.params;
      
      await storage.removeAthleteFromCombinedEvent(combinedEventId, athleteId);
      res.json({ success: true });
    } catch (error) {
      console.error("Failed to remove athlete from combined event:", error);
      res.status(500).json({ error: "Failed to remove athlete" });
    }
  });
  
  // Delete combined event
  app.delete("/api/combined-events/:id", async (req, res) => {
    try {
      await storage.deleteCombinedEvent(parseInt(req.params.id));
      res.json({ success: true });
    } catch (error) {
      console.error("Failed to delete combined event:", error);
      res.status(500).json({ error: "Failed to delete combined event" });
    }
  });
  
  // Update combined event status
  app.patch("/api/combined-events/:id/status", async (req, res) => {
    try {
      const { status } = req.body;
      const updated = await storage.updateCombinedEventStatus(parseInt(req.params.id), status);
      if (!updated) {
        return res.status(404).json({ error: "Combined event not found" });
      }
      res.json(updated);
    } catch (error) {
      console.error("Failed to update combined event status:", error);
      res.status(500).json({ error: "Failed to update status" });
    }
  });
  
  // Get scoring coefficients for reference
  app.get("/api/combined-events/scoring-tables", async (req, res) => {
    const { SCORING_TABLES, COMBINED_EVENT_DEFINITIONS } = await import('./combined-events-scoring');
    res.json({ scoringTables: SCORING_TABLES, eventDefinitions: COMBINED_EVENT_DEFINITIONS });
  });
  
  // Calculate points for a single performance
  app.post("/api/combined-events/calculate-points", async (req, res) => {
    try {
      const { eventType, performance, gender } = req.body;
      const { calculateEventPoints, normalizeEventType } = await import('./combined-events-scoring');
      
      const normalizedEvent = normalizeEventType(eventType);
      const points = calculateEventPoints(normalizedEvent, performance, gender);
      
      res.json({ eventType: normalizedEvent, performance, gender, points });
    } catch (error) {
      console.error("Failed to calculate points:", error);
      res.status(500).json({ error: "Failed to calculate points" });
    }
  });

  // ===== SOCIAL MEDIA CONTENT GENERATOR =====

  // Generate event result post
  app.post("/api/social-media/event-result", async (req, res) => {
    try {
      const { eventId } = req.body;
      
      const event = await storage.getEventWithEntries(eventId);
      if (!event) {
        return res.status(404).json({ error: "Event not found" });
      }
      
      const meet = await storage.getMeet(event.meetId);
      if (!meet) {
        return res.status(404).json({ error: "Meet not found" });
      }
      
      const results = event.entries
        .filter(e => e.finalPlace)
        .sort((a, b) => (a.finalPlace || 999) - (b.finalPlace || 999))
        .slice(0, 3)
        .map(e => ({
          athleteName: e.athlete ? `${e.athlete.firstName} ${e.athlete.lastName}` : "Unknown",
          teamName: e.team?.name,
          finalMark: e.finalMark?.toString(),
          finalPlace: e.finalPlace || undefined
        }));
      
      const { generateEventResultCaption } = await import('./social-media-captions');
      const caption = generateEventResultCaption(event, results, meet.name);
      
      const post = await storage.createSocialMediaPost({
        type: 'event_result',
        caption,
        hashtags: ['TrackAndField', event.eventType.replace(/\s+/g, '')],
        eventId: event.id
      });
      
      res.json(post);
    } catch (error) {
      console.error("Failed to generate event result post:", error);
      res.status(500).json({ error: "Failed to generate post" });
    }
  });

  // Generate medal count post
  app.post("/api/social-media/medal-count", async (req, res) => {
    try {
      const { meetId } = req.body;
      
      const meet = await storage.getMeet(meetId);
      if (!meet) {
        return res.status(404).json({ error: "Meet not found" });
      }
      
      const standings = await storage.getMedalStandings(meetId);
      const { generateMedalCountCaption } = await import('./social-media-captions');
      const caption = generateMedalCountCaption(standings, meet.name);
      
      const post = await storage.createSocialMediaPost({
        type: 'medal_count',
        caption,
        hashtags: ['TrackAndField', 'MedalCount']
      });
      
      res.json(post);
    } catch (error) {
      console.error("Failed to generate medal count post:", error);
      res.status(500).json({ error: "Failed to generate post" });
    }
  });

  // Generate meet highlight post
  app.post("/api/social-media/meet-highlight", async (req, res) => {
    try {
      const { meetId } = req.body;
      
      const meet = await storage.getMeet(meetId);
      if (!meet) {
        return res.status(404).json({ error: "Meet not found" });
      }
      
      const events = await storage.getEventsByMeetId(meetId);
      const athletes = await storage.getAthletesByMeetId(meetId);
      
      const { generateMeetHighlightCaption } = await import('./social-media-captions');
      const caption = generateMeetHighlightCaption(
        meet.name,
        meet.location || "Unknown",
        events.length,
        athletes.length
      );
      
      const post = await storage.createSocialMediaPost({
        type: 'meet_highlight',
        caption,
        hashtags: ['TrackAndField', 'Athletics', 'TrackMeet']
      });
      
      res.json(post);
    } catch (error) {
      console.error("Failed to generate meet highlight post:", error);
      res.status(500).json({ error: "Failed to generate post" });
    }
  });

  // Get all social media posts
  app.get("/api/social-media/posts", async (req, res) => {
    const posts = await storage.getSocialMediaPosts();
    res.json(posts);
  });

  // Delete social media post
  app.delete("/api/social-media/posts/:id", async (req, res) => {
    await storage.deleteSocialMediaPost(req.params.id);
    res.status(204).send();
  });

  // ===== FINISHLYNX INTEGRATION =====

  // Upload LIF file
  app.post("/api/finishlynx/upload", upload.single("lif"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No file uploaded" });
      }
      
      const { meetId } = req.body;
      if (!meetId) {
        return res.status(400).json({ error: "meetId required" });
      }
      
      const fileContent = req.file.buffer.toString('utf-8');
      const result = await ingestLIFResults(fileContent, meetId);
      
      // Broadcast update to displays
      broadcastToDisplays({
        type: 'finishlynx_update',
        meetId,
        timestamp: new Date().toISOString()
      });
      
      res.json(result);
    } catch (error) {
      console.error("FinishLynx upload error:", error);
      res.status(500).json({ error: "Failed to process file" });
    }
  });

  // Clear old signatures (cleanup)
  app.post("/api/finishlynx/cleanup", async (req, res) => {
    const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
    await storage.clearOldSignatures(oneDayAgo);
    res.json({ success: true });
  });

  // ===== RTV FILE IMPORT =====

  // Configure multer for RTV binary uploads (memory storage for buffer access)
  const rtvUpload = multer({
    storage: multer.memoryStorage(),
    limits: {
      fileSize: 20 * 1024 * 1024, // 20MB limit for RTV files
    },
    fileFilter: (req, file, cb) => {
      const ext = file.originalname.toLowerCase();
      if (ext.endsWith('.rtv') || ext.endsWith('.bin') || file.mimetype === 'application/octet-stream') {
        cb(null, true);
      } else {
        cb(new Error('Invalid file type. Only .rtv files are allowed.'));
      }
    },
  });

  // Import RTV file and parse text objects
  app.post("/api/import-rtv", rtvUpload.single("rtv"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No file uploaded" });
      }

      const { parseRtvFile } = await import('./rtv-parser');
      const result = parseRtvFile(req.file.buffer);

      if (!result.success && result.objects.length === 0) {
        return res.status(400).json({
          error: "Failed to parse RTV file",
          warnings: result.warnings,
        });
      }

      res.json({
        success: result.success,
        objects: result.objects,
        warnings: result.warnings,
        fileVersion: result.fileVersion,
        fileName: req.file.originalname,
      });
    } catch (error: any) {
      console.error("RTV import error:", error);
      res.status(500).json({ error: "Failed to process RTV file", details: error.message });
    }
  });

  // ===== CERTIFICATE GENERATION =====

  // ARCHIVED: Certificate generation feature - moved to archived/server/
  // See archived/server/certificate-generator.ts for implementation

  // ARCHIVED: QR Code generation feature

  // ===== WEATHER STATION =====

  // Get weather config (don't expose API key)
  app.get("/api/weather/config/:meetId", async (req, res) => {
    const config = await storage.getWeatherConfig(req.params.meetId);
    if (!config) {
      return res.json(null);
    }
    
    // Return config without API key
    const { apiKey, ...safeConfig } = config;
    res.json({ ...safeConfig, hasApiKey: !!apiKey });
  });

  // Set weather config and start polling
  app.post("/api/weather/config", async (req, res) => {
    try {
      const validated = insertWeatherConfigSchema.parse(req.body);
      await storage.setWeatherConfig(validated);
      startWeatherPolling(validated.meetId, broadcastToDisplays);
      res.json({ success: true });
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Delete weather config and stop polling
  app.delete("/api/weather/config/:meetId", async (req, res) => {
    await storage.deleteWeatherConfig(req.params.meetId);
    stopWeatherPolling(req.params.meetId);
    res.json({ success: true });
  });

  // Get current weather
  app.get("/api/weather/current/:meetId", async (req, res) => {
    const reading = await storage.getLatestWeatherReading(req.params.meetId);
    res.json(reading);
  });

  // Get weather history
  app.get("/api/weather/history/:meetId", async (req, res) => {
    const hours = parseInt(req.query.hours as string) || 2;
    const history = await storage.getWeatherHistory(req.params.meetId, hours);
    res.json(history);
  });

  // Manual refresh
  app.post("/api/weather/refresh/:meetId", async (req, res) => {
    const config = await storage.getWeatherConfig(req.params.meetId);
    if (!config) {
      return res.status(404).json({ error: "Weather config not found" });
    }
    
    // Restart polling (triggers immediate fetch)
    startWeatherPolling(config.meetId, broadcastToDisplays);
    res.json({ success: true });
  });

  // ===== LAP COUNTER =====
  let currentLap = 0;
  let currentLapMode: "lap" | "logo" = "lap";
  let currentLapMeetId: string | undefined = undefined;

  app.get("/api/lap-counter", (_req, res) => {
    res.json({ lap: currentLap, mode: currentLapMode, meetId: currentLapMeetId });
  });

  app.post("/api/lap-counter", (req, res) => {
    const { lap, mode, meetId } = req.body;
    if (meetId) currentLapMeetId = meetId;
    if (mode === "logo") {
      currentLapMode = "logo";
      broadcastToDisplays({ type: "lap_counter_update", lap: currentLap, mode: "logo", meetId: currentLapMeetId });
      return res.json({ lap: currentLap, mode: currentLapMode, meetId: currentLapMeetId });
    }
    const parsed = Number(lap);
    if (!Number.isInteger(parsed) || parsed < 0 || parsed > 25) {
      return res.status(400).json({ error: "Lap must be an integer 0-25" });
    }
    currentLap = parsed;
    currentLapMode = "lap";
    broadcastToDisplays({ type: "lap_counter_update", lap: currentLap, mode: "lap", meetId: currentLapMeetId });
    res.json({ lap: currentLap, mode: currentLapMode, meetId: currentLapMeetId });
  });

  const httpServer = createServer(app);

  // WebSocket Server on /ws path
  const wss = new WebSocketServer({ server: httpServer, path: "/ws" });

  wss.on("connection", (ws: WebSocket) => {
    console.log("WebSocket client connected");
    let registeredDeviceId: string | null = null;

    // Handle incoming messages for client identification
    ws.on('message', async (message) => {
      try {
        const data = JSON.parse(message.toString());
        
        // Handle client identification
        if (data.type === 'identify' && data.clientType === 'overlay') {
          console.log('Overlay client identified');
          displayClients.add(ws);
          
          // Send connection confirmation to overlay
          ws.send(
            JSON.stringify({
              type: "connection_status",
              connected: true,
            } as WSMessage)
          );
        }
        
        // Handle display device registration
        if (data.type === 'register_display_device') {
          const { meetId, deviceName, displayType, deviceId: clientDeviceId, displayWidth, displayHeight } = data;
          
          if (meetId && deviceName) {
            console.log(`Display device registering: ${deviceName} (${displayType}) for meet ${meetId}, clientDeviceId: ${clientDeviceId || 'new'}`);
            
            try {
              // If client provides a deviceId, try to find and update that device
              let device;
              if (clientDeviceId) {
                const existingDevice = await storage.getDisplayDevice(clientDeviceId);
                if (existingDevice && existingDevice.meetId === meetId) {
                  // Update existing device status
                  device = await storage.updateDisplayDeviceStatus(clientDeviceId, 'online');
                  
                  if (device && displayType && (displayType !== existingDevice.displayType || deviceName !== existingDevice.deviceName)) {
                    device = await storage.updateDisplayDeviceType(clientDeviceId, displayType, deviceName, displayWidth, displayHeight) || device;
                    console.log(`Updated device type: ${deviceName} (${displayType})`);
                  }
                  
                  console.log(`Reconnected existing device: ${device?.deviceName} (${clientDeviceId})`);
                }
              }
              
              // If no existing device found, create a new one
              if (!device) {
                device = await storage.createOrUpdateDisplayDevice({
                  meetId,
                  deviceName,
                  displayType: displayType || 'P10',
                  displayWidth: displayType === 'Custom' ? displayWidth : undefined,
                  displayHeight: displayType === 'Custom' ? displayHeight : undefined,
                } as any);
                console.log(`Created new device: ${device.deviceName} (${device.id})`);
              }
              
              registeredDeviceId = device.id;
              
              // Track this WebSocket connection with the device (including displayType)
              // Load persisted autoMode from database, default to true for track displays
              const deviceAutoMode = device.autoMode ?? (device.displayMode === 'track');
              connectedDisplayDevices.set(device.id, {
                ws,
                deviceId: device.id,
                deviceName: device.deviceName,
                meetId: device.meetId,
                displayType: displayType || 'P10',
                autoMode: deviceAutoMode,
                pagingSize: device.pagingSize ?? 8,
                pagingInterval: device.pagingInterval ?? 5,
              });
              
              // Send registration confirmation with assigned event
              ws.send(JSON.stringify({
                type: 'device_registered',
                data: {
                  deviceId: device.id,
                  deviceName: device.deviceName,
                  meetId: device.meetId,
                  assignedEventId: device.assignedEventId,
                  status: device.status,
                  displayType: displayType || 'P10',
                  fieldPort: device.fieldPort,
                  isBigBoard: device.isBigBoard,
                  displayMode: device.displayMode,
                  autoMode: deviceAutoMode,
                }
              }));
              
              // Notify control panel that device list has changed
              broadcastToDisplays({
                type: 'devices_updated',
                data: { meetId: device.meetId }
              } as WSMessage);
              
              console.log(`Display device registered: ${device.deviceName} (${device.id})`);
            } catch (error) {
              console.error('Failed to register display device:', error);
              ws.send(JSON.stringify({
                type: 'device_registration_error',
                error: 'Failed to register device'
              }));
            }
          }
        }
        
        // Handle display device heartbeat via WebSocket
        if (data.type === 'device_heartbeat' && registeredDeviceId) {
          await storage.updateDisplayDeviceStatus(registeredDeviceId, 'online');
        }
        
        // Handle field session subscription
        if (data.type === 'subscribe_field_session') {
          const sessionId = parseInt(data.sessionId);
          if (!isNaN(sessionId)) {
            if (!fieldSessionSubscribers.has(sessionId)) {
              fieldSessionSubscribers.set(sessionId, new Set());
            }
            fieldSessionSubscribers.get(sessionId)!.add(ws);
            console.log(`[Field WS] Client subscribed to session ${sessionId}`);
            
            // Send current state immediately
            broadcastFieldEventUpdate(sessionId).catch(console.error);
          }
        }
        
        // Handle field session unsubscription
        if (data.type === 'unsubscribe_field_session') {
          const sessionId = parseInt(data.sessionId);
          if (!isNaN(sessionId) && fieldSessionSubscribers.has(sessionId)) {
            fieldSessionSubscribers.get(sessionId)!.delete(ws);
            console.log(`[Field WS] Client unsubscribed from session ${sessionId}`);
          }
        }
      } catch (error) {
        // Not a control message, could be other WebSocket traffic
      }
    });

    // Non-overlay clients are added immediately
    // They will receive all broadcasts but can filter on client side
    displayClients.add(ws);

    // Send current state immediately on connection
    broadcastCurrentEvent().catch(console.error);

    // Send connection status
    ws.send(
      JSON.stringify({
        type: "connection_status",
        connected: true,
      } as WSMessage)
    );

    ws.on("close", async () => {
      console.log("WebSocket client disconnected");
      displayClients.delete(ws);
      
      // Clean up field session subscriptions
      fieldSessionSubscribers.forEach((subscribers, sessionId) => {
        if (subscribers.has(ws)) {
          subscribers.delete(ws);
          console.log(`[Field WS] Client removed from session ${sessionId} on close`);
        }
      });
      
      // If this was a registered display device, update its status
      if (registeredDeviceId) {
        connectedDisplayDevices.delete(registeredDeviceId);
        try {
          const device = await storage.updateDisplayDeviceStatus(registeredDeviceId, 'offline');
          if (device) {
            // Notify control panel that device went offline
            broadcastToDisplays({
              type: 'devices_updated',
              data: { meetId: device.meetId }
            } as WSMessage);
            console.log(`Display device offline: ${device.deviceName}`);
          }
        } catch (error) {
          console.error('Failed to update device status:', error);
        }
      }
    });

    ws.on("error", (error) => {
      console.error("WebSocket error:", error);
      displayClients.delete(ws);
      
      // Clean up field session subscriptions
      fieldSessionSubscribers.forEach((subscribers, sessionId) => {
        if (subscribers.has(ws)) {
          subscribers.delete(ws);
        }
      });
      
      // Clean up device tracking on error
      if (registeredDeviceId) {
        connectedDisplayDevices.delete(registeredDeviceId);
      }
    });
  });

  // Initialize weather polling for all meets on server start
  setImmediate(async () => {
    try {
      const meets = await storage.getMeets();
      
      for (const meet of meets) {
        const config = await storage.getWeatherConfig(meet.id);
        if (config) {
          startWeatherPolling(meet.id, broadcastToDisplays);
          console.log(`✅ Resumed weather polling for meet: ${meet.name}`);
        }
      }
    } catch (error) {
      console.error('❌ Failed to initialize weather polling:', error);
    }
  });

  // ===== RESULTV PARSER EVENT WIRING =====
  // Wire up the ResulTV parser to broadcast events via WebSocket
  const resultvParser = getResulTVParser();

  // Broadcast layout commands to displays (scene switching)
  resultvParser.on('layout-command', (layoutName: string, cmd: any) => {
    console.log(`[ResulTV] Broadcasting layout-command: ${layoutName}`);
    broadcastToDisplays({
      type: 'layout-command',
      data: { layout: layoutName, command: cmd }
    } as WSMessage);
  });

  // Broadcast clock updates
  resultvParser.on('clock', (time: string, isRunning: boolean) => {
    broadcastToDisplays({
      type: 'lynx_clock',
      data: { time, isRunning }
    } as WSMessage);
  });

  // Broadcast wind readings
  resultvParser.on('wind', (wind: string) => {
    broadcastToDisplays({
      type: 'lynx_wind',
      data: { wind }
    } as WSMessage);
  });

  // Broadcast complete page state (debounced, with all entries)
  resultvParser.on('page', (page: any) => {
    broadcastToDisplays({
      type: 'lynx_page',
      data: page
    } as WSMessage);
  });

  console.log('✅ ResulTV parser event handlers registered');

  // ===== LYNX DATA INGEST API =====

  // In-memory live state (will be persisted when we add database support)
  const liveState = {
    trackMode: 'idle' as TrackDisplayMode,
    currentEventNumber: 0,
    currentHeatNumber: 1,
    runningTime: '0:00.00',
    isArmed: false,
    isRunning: false,
    activeFieldEvents: new Map<number, { mode: FieldDisplayMode; athleteName?: string; attemptNumber?: number; mark?: string }>(),
  };

  // Entry accumulator: FinishLynx sends entries one-by-one, we accumulate them
  // Entry accumulators - separate for big board and small board
  // Reset on layout-command "Start List", then accumulate entries as they arrive
  // Display reads entries[0] for Line 1, entries[1] for Line 2, etc.
  const createEmptyAccumulator = () => ({
    entries: [] as any[],
    eventNumber: 0,
    heat: 1,
    eventName: '',
    distance: '',
    lastLayoutCommand: '',
  });
  const entryAccumulator = createEmptyAccumulator(); // Standard/small board
  const entryAccumulatorBig = createEmptyAccumulator(); // Big board

  // Get Lynx connection status (used by UI)
  app.get("/api/lynx/status", async (req, res) => {
    try {
      const status = lynxListener.getStatus();
      res.json({
        ports: status.map(p => ({
          portType: p.portType,
          port: p.port,
          connected: p.connected,
          lastDataAt: p.lastDataAt,
        })),
        currentEventNumber: lynxListener.getCurrentEventNumber(),
        currentHeatNumber: lynxListener.getCurrentHeatNumber(),
        isClockRunning: lynxListener.isClockRunning(),
        lastClockTime: lynxListener.getLastClockTime(),
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get Lynx port configuration
  app.get("/api/lynx/config", async (req, res) => {
    try {
      const status = lynxListener.getStatus();
      res.json({
        configured: status.length > 0,
        ports: status,
        currentEventNumber: lynxListener.getCurrentEventNumber(),
        currentHeatNumber: lynxListener.getCurrentHeatNumber(),
        isClockRunning: lynxListener.isClockRunning(),
        lastClockTime: lynxListener.getLastClockTime(),
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Configure Lynx ports
  app.post("/api/lynx/config", async (req, res) => {
    try {
      const configSchema = z.object({
        ports: z.array(z.object({
          port: z.number().min(1024).max(65535),
          portType: z.enum(['clock', 'results', 'field', 'start_list']),
          name: z.string(),
          host: z.string().optional(),
        })),
        meetId: z.string().optional(),
        saveToDatabase: z.boolean().optional(),
      });
      
      const { ports, meetId, saveToDatabase } = configSchema.parse(req.body);
      
      // Stop existing listeners
      lynxListener.stop();
      
      // Configure and start new listeners
      lynxListener.configure(ports);
      lynxListener.start();
      
      // Save config to database for auto-start on boot
      if (saveToDatabase !== false) {
        // Clear existing configs for this meet
        await storage.deleteLynxConfigs(meetId);
        
        // Save new configs
        for (const port of ports) {
          await storage.saveLynxConfig({
            port: port.port,
            portType: port.portType,
            name: port.name,
            host: port.host || null,
            meetId: meetId || null,
            enabled: true,
          });
        }
        console.log(`[Lynx] Saved ${ports.length} port configs to database`);
      }
      
      res.json({ success: true, ports: lynxListener.getStatus() });
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Start Lynx listeners
  app.post("/api/lynx/start", async (req, res) => {
    try {
      lynxListener.start();
      res.json({ success: true, status: lynxListener.getStatus() });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Stop Lynx listeners
  app.post("/api/lynx/stop", async (req, res) => {
    try {
      lynxListener.stop();
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get Lynx config for a specific meet
  app.get("/api/lynx/config/:meetId", async (req, res) => {
    try {
      // Return current configuration based on listener status
      const status = lynxListener.getStatus();
      const clockPort = status.find(p => p.portType === 'clock')?.port || 4000;
      const resultsPort = status.find(p => p.portType === 'results')?.port || 4001;
      const startListPort = status.find(p => p.portType === 'start_list')?.port || 4002;
      const fieldPort = status.find(p => p.portType === 'field')?.port || 4003;
      const enabled = status.some(p => p.connected);
      
      res.json({
        meetId: req.params.meetId,
        clockPort,
        resultsPort,
        startListPort,
        fieldPort,
        enabled,
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Update Lynx config for a specific meet
  app.post("/api/lynx/config/:meetId", async (req, res) => {
    try {
      const { meetId } = req.params;
      const { clockPort, resultsPort, startListPort, fieldPort, enabled, host } = req.body;
      
      // Reconfigure the listener with new ports
      const ports = [
        { port: clockPort || 4000, portType: 'clock' as const, name: 'Clock', host },
        { port: resultsPort || 4001, portType: 'results' as const, name: 'Results', host },
        { port: startListPort || 4002, portType: 'start_list' as const, name: 'Start List', host },
        { port: fieldPort || 4003, portType: 'field' as const, name: 'Field', host },
      ];
      
      lynxListener.stop();
      lynxListener.configure(ports);
      
      if (enabled) {
        lynxListener.start();
      }
      
      // Save config to database for auto-start on boot
      await storage.deleteLynxConfigs(meetId);
      for (const port of ports) {
        await storage.saveLynxConfig({
          port: port.port,
          portType: port.portType,
          name: port.name,
          host: port.host || null,
          meetId: meetId,
          enabled: enabled !== false,
        });
      }
      console.log(`[Lynx] Saved ${ports.length} port configs for meet ${meetId}`);
      
      res.json({ success: true, status: lynxListener.getStatus() });
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Reconnect Lynx listeners
  app.post("/api/lynx/reconnect/:meetId", async (req, res) => {
    try {
      lynxListener.stop();
      lynxListener.start();
      res.json({ success: true, status: lynxListener.getStatus() });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Receive forwarded Lynx data from remote TCP forwarders (legacy JSON format)
  // This endpoint allows FinishLynx/FieldLynx data to be sent via HTTP
  // when direct TCP connection isn't possible (e.g., different networks)
  app.post("/api/lynx/forward", async (req, res) => {
    try {
      const { data, portType, portName } = req.body;
      
      if (!data || typeof data !== 'string') {
        return res.status(400).json({ error: 'Missing or invalid data' });
      }
      
      const validPortTypes = ['clock', 'results', 'field', 'start_list'];
      if (!portType || !validPortTypes.includes(portType)) {
        return res.status(400).json({ error: 'Invalid portType. Must be one of: clock, results, field, start_list' });
      }
      
      // Process the forwarded data through the Lynx listener
      lynxListener.processForwardedData(data, portType as LynxPortType, portName || 'HTTP Forward');
      
      res.json({ success: true, processed: data.length });
    } catch (error: any) {
      console.error('[Lynx Forward] Error:', error.message);
      res.status(500).json({ error: error.message });
    }
  });

  // Diagnostic buffer for incoming field data - stores last 50 messages
  const fieldDataDiagnostics: Array<{
    timestamp: string;
    portType: string;
    rawText: string;
    rawHex: string;
    parsedFields: Record<string, string>;
  }> = [];
  const MAX_DIAGNOSTICS = 50;

  // Track which field port data is coming from (for port-based routing)
  // This allows displays to subscribe to specific field ports
  let currentFieldPort: number | null = null;
  
  // Valid field ports: 4560-4569 (10 field event slots)
  const FIELD_PORT_MIN = 4560;
  const FIELD_PORT_MAX = 4569;

  // Field Port State Tracking for Auto-Standings
  // Tracks event info and last update time per port to trigger automatic standings after idle
  interface FieldPortState {
    eventNumber: number;
    roundNumber: number;
    lastUpdateTime: number;  // Timestamp of last data received
    inStandingsMode: boolean;  // Whether we've switched to standings display
    standingsPageTimer?: ReturnType<typeof setTimeout>;  // Timer for page cycling (setTimeout, not interval)
    currentPage: number;
    totalPages: number;
    standings?: MergedFieldStandings;  // Cached standings data
  }
  
  const fieldPortStates: Map<number, FieldPortState> = new Map();
  const STANDINGS_IDLE_TIMEOUT = 120 * 1000;  // 120 seconds before switching to standings
  
  // Check for idle field ports and trigger standings mode
  const checkFieldPortsForStandings = async () => {
    const now = Date.now();
    
    const entries = Array.from(fieldPortStates.entries());
    for (const [port, state] of entries) {
      // Skip if already in standings mode
      if (state.inStandingsMode) continue;
      
      // Check if idle timeout has passed
      if (now - state.lastUpdateTime >= STANDINGS_IDLE_TIMEOUT) {
        console.log(`[Field Auto-Standings] Port ${port} idle for 120s, switching to standings mode for event ${state.eventNumber}`);
        await triggerFieldStandingsMode(port, state);
      }
    }
  };
  
  // Check every 10 seconds for idle ports
  setInterval(checkFieldPortsForStandings, 10000);
  
  // Trigger standings mode for a port - find LFF files and start paging
  async function triggerFieldStandingsMode(port: number, state: FieldPortState) {
    try {
      // Get meet's ingestion settings to find the lynx directory
      // Use the first meet that has ingestion settings configured
      const meets = await storage.getMeets();
      if (meets.length === 0) {
        console.log(`[Field Auto-Standings] No meets found, cannot load standings`);
        return;
      }
      
      // Try to find a meet with ingestion settings configured
      let ingestionSettings = null;
      let activeMeet = null;
      for (const meet of meets) {
        const settings = await storage.getIngestionSettings(meet.id);
        if (settings?.lynxFilesDirectory) {
          ingestionSettings = settings;
          activeMeet = meet;
          break;
        }
      }
      
      if (!activeMeet) {
        console.log(`[Field Auto-Standings] No meet with lynx directory configured`);
        return;
      }
      
      const ingestionSettingsResult = ingestionSettings;
      if (!ingestionSettings?.lynxFilesDirectory) {
        console.log(`[Field Auto-Standings] No lynx directory configured for meet ${activeMeet.id}`);
        return;
      }
      
      // Merge all flights for this event from LFF files
      const standings = await mergeFlightsForEvent(
        ingestionSettings.lynxFilesDirectory,
        state.eventNumber,
        state.roundNumber
      );
      
      if (!standings || standings.athletes.length === 0) {
        console.log(`[Field Auto-Standings] No LFF files found for event ${state.eventNumber} round ${state.roundNumber}`);
        return;
      }
      
      console.log(`[Field Auto-Standings] Found ${standings.athletes.length} athletes from ${standings.flights.length} flights for event ${state.eventNumber}`);
      
      // Update state
      state.inStandingsMode = true;
      state.standings = standings;
      state.currentPage = 0;
      
      // Broadcast first page and start paging timer
      broadcastFieldStandingsPage(port, state);
    } catch (error) {
      console.error(`[Field Auto-Standings] Error loading standings for port ${port}:`, error);
    }
  }
  
  // Broadcast a page of standings data
  function broadcastFieldStandingsPage(port: number, state: FieldPortState) {
    if (!state.standings) return;
    
    // Get page size from scene layout - will be provided by display
    // For now, use a default of 8 and displays will request based on their layout
    const pageSize = 8;  // This will be dynamically set by displays
    
    const athletes = state.standings.athletes.filter(a => !a.isDNS);  // Filter out DNS
    state.totalPages = Math.ceil(athletes.length / pageSize);
    
    if (state.totalPages === 0) {
      state.totalPages = 1;
    }
    
    // Get current page of athletes
    const startIdx = state.currentPage * pageSize;
    const endIdx = Math.min(startIdx + pageSize, athletes.length);
    const pageAthletes = athletes.slice(startIdx, endIdx);
    
    // Format entries with additional field data for templates
    const entriesWithDetails = pageAthletes.map((athlete, idx) => ({
      place: athlete.overallPlace.toString(),
      lane: (startIdx + idx + 1).toString(),
      name: `${athlete.firstName} ${athlete.lastName}`.trim(),
      firstName: athlete.firstName,
      lastName: athlete.lastName,
      affiliation: athlete.team || '',
      team: athlete.team || '',
      bib: athlete.bibNumber.toString(),
      bestMark: athlete.bestMarkFormatted,
      mark: athlete.bestMarkFormatted,
      time: athlete.bestMarkFormatted,
      // Include attempts for field templates
      attempts: athlete.attempts,
      attemptMarks: athlete.attempts.map(a => {
        if (a.isFoul) return 'F';
        if (a.isPassed) return 'P';
        if (a.isCleared) return 'O';
        if (a.isMissed) return 'X';
        return a.mark !== null ? a.mark.toFixed(2) : '';
      }),
      // Include wind per attempt for horizontal events
      attemptWinds: athlete.attempts.map(a => a.wind !== null ? a.wind.toFixed(1) : ''),
      flightNumber: athlete.flightNumber,
    }));
    
    // Broadcast standings update to all field mode display devices
    const standingsMessage = {
      type: 'field_standings',
      data: {
        eventNumber: state.standings.eventNumber,
        eventName: state.standings.eventName,
        displayMode: 'field_standings',
        fieldPort: port,
        currentPage: state.currentPage + 1,
        totalPages: state.totalPages,
        pageSize,
        totalAthletes: athletes.length,
        isStandings: true,
        entries: entriesWithDetails,
        flights: state.standings.flights,
        isVerticalEvent: state.standings.isVerticalEvent,
        heights: state.standings.heights,
      }
    };
    
    // Send to all connected display devices that are in field mode and on this port
    connectedDisplayDevices.forEach((device) => {
      if (device.ws.readyState === WebSocket.OPEN) {
        // Send to all - let client filter by port
        device.ws.send(JSON.stringify(standingsMessage));
      }
    });
    
    // Also send to displayClients (non-device WebSocket connections)
    displayClients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(JSON.stringify(standingsMessage));
      }
    });
    
    console.log(`[Field Auto-Standings] Broadcast page ${state.currentPage + 1}/${state.totalPages} for event ${state.standings.eventNumber} on port ${port}`);
    
    // Set up next page timer - recalculate each time for dynamic page sizes
    // Clear any existing timer first
    if (state.standingsPageTimer) {
      clearTimeout(state.standingsPageTimer);
      state.standingsPageTimer = undefined;
    }
    
    // Only continue paging if there are multiple pages
    if (state.totalPages > 1) {
      // Calculate display time: 1 second per line shown on this page
      const displayTimeMs = pageAthletes.length * 1000;
      
      state.standingsPageTimer = setTimeout(() => {
        state.currentPage = (state.currentPage + 1) % state.totalPages;
        broadcastFieldStandingsPage(port, state);
      }, displayTimeMs);
    }
  }
  
  // Exit standings mode and return to live display
  function exitFieldStandingsMode(port: number) {
    const state = fieldPortStates.get(port);
    if (!state) return;
    
    if (state.standingsPageTimer) {
      clearTimeout(state.standingsPageTimer);
      state.standingsPageTimer = undefined;
    }
    
    state.inStandingsMode = false;
    state.standings = undefined;
    state.currentPage = 0;
    state.totalPages = 0;
    
    console.log(`[Field Auto-Standings] Exited standings mode for port ${port}`);
  }
  
  // Update field port state when new data arrives
  function updateFieldPortState(port: number, eventNumber: number, roundNumber: number = 1) {
    const existing = fieldPortStates.get(port);
    
    // If we were in standings mode, exit it
    if (existing?.inStandingsMode) {
      exitFieldStandingsMode(port);
    }
    
    fieldPortStates.set(port, {
      eventNumber,
      roundNumber,
      lastUpdateTime: Date.now(),
      inStandingsMode: false,
      currentPage: 0,
      totalPages: 0,
    });
  }

  // NEW: Receive raw bytes from TCP forwarder (ResulTV/LSS binary format)
  // This is the new endpoint for the base64-encoded raw data
  app.post("/api/lynx/raw", async (req, res) => {
    try {
      const { data, encoding, portType, timestamp, fieldPort } = req.body;
      
      if (!data || typeof data !== 'string') {
        return res.status(400).json({ error: 'Missing or invalid data' });
      }
      
      if (encoding !== 'base64') {
        return res.status(400).json({ error: 'Invalid encoding. Must be base64' });
      }
      
      const validPortTypes = ['clock', 'results', 'field'];
      if (!portType || !validPortTypes.includes(portType)) {
        return res.status(400).json({ error: 'Invalid portType. Must be one of: clock, results, field' });
      }
      
      // For field data, validate and store the field port for routing
      if (portType === 'field' && fieldPort) {
        const port = parseInt(fieldPort);
        if (port >= FIELD_PORT_MIN && port <= FIELD_PORT_MAX) {
          currentFieldPort = port;
          console.log(`[Lynx Raw] Field data from port ${port}`);
        } else {
          console.warn(`[Lynx Raw] Invalid field port ${fieldPort}, must be ${FIELD_PORT_MIN}-${FIELD_PORT_MAX}`);
        }
      }
      
      // Decode base64 to buffer
      const rawBytes = Buffer.from(data, 'base64');
      
      // Enhanced diagnostic logging for field data
      if (portType === 'field') {
        const rawText = rawBytes.toString('utf8');
        const rawHex = rawBytes.toString('hex');
        
        // Try to extract any key=value pairs from the data
        const parsedFields: Record<string, string> = {};
        const kvMatches = rawText.matchAll(/([A-Za-z_]+)\s*[=:]\s*([^;\r\n]+)/g);
        for (const match of kvMatches) {
          parsedFields[match[1]] = match[2].trim();
        }
        
        // Look for common device name patterns
        const devicePatterns = [
          /Device[Name]*\s*[=:]\s*([^;\r\n]+)/i,
          /Target[Device]*\s*[=:]\s*([^;\r\n]+)/i,
          /Scoreboard\s*[=:]\s*([^;\r\n]+)/i,
          /Display\s*[=:]\s*([^;\r\n]+)/i,
          /Board\s*[=:]\s*([^;\r\n]+)/i,
        ];
        
        for (const pattern of devicePatterns) {
          const match = rawText.match(pattern);
          if (match) {
            parsedFields['_DETECTED_DEVICE'] = match[1].trim();
            console.log(`[Field Diagnostic] DEVICE NAME DETECTED: "${match[1].trim()}"`);
          }
        }
        
        console.log(`[Field Diagnostic] ========== INCOMING FIELD DATA ==========`);
        console.log(`[Field Diagnostic] Raw text (first 500 chars): ${rawText.substring(0, 500)}`);
        console.log(`[Field Diagnostic] Parsed key-value pairs:`, parsedFields);
        console.log(`[Field Diagnostic] ===========================================`);
        
        // Store for retrieval via API
        fieldDataDiagnostics.push({
          timestamp: new Date().toISOString(),
          portType,
          rawText: rawText.substring(0, 2000), // Limit stored size
          rawHex: rawHex.substring(0, 500),
          parsedFields,
        });
        
        // Keep only last N entries
        while (fieldDataDiagnostics.length > MAX_DIAGNOSTICS) {
          fieldDataDiagnostics.shift();
        }
      }
      
      // Process through the ResulTV parser
      const parser = getResulTVParser();
      parser.processRawData(rawBytes, portType);
      
      res.json({ success: true, bytesProcessed: rawBytes.length });
    } catch (error: any) {
      console.error('[Lynx Raw] Error:', error.message);
      res.status(500).json({ error: error.message });
    }
  });

  // Diagnostic endpoint to view recent field data
  app.get("/api/field-diagnostics", async (req, res) => {
    res.json({
      count: fieldDataDiagnostics.length,
      messages: fieldDataDiagnostics,
      hint: "Look for 'Device', 'Target', 'Scoreboard', or 'Board' fields in parsedFields",
    });
  });

  // Clear diagnostics buffer
  app.delete("/api/field-diagnostics", async (req, res) => {
    fieldDataDiagnostics.length = 0;
    res.json({ success: true, message: "Diagnostics buffer cleared" });
  });

  // Get live event data by event number
  app.get("/api/live-events/:eventNumber", async (req, res) => {
    try {
      const eventNumber = parseInt(req.params.eventNumber);
      const meetId = req.query.meetId as string | undefined;
      
      const data = await storage.getLiveEventData(eventNumber, meetId);
      if (!data) {
        return res.status(404).json({ error: "No live data for this event" });
      }
      
      res.json(data);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get all live events for a meet
  app.get("/api/live-events", async (req, res) => {
    try {
      const meetId = req.query.meetId as string | undefined;
      const events = await storage.getLiveEventsByMeet(meetId);
      res.json(events);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Clear live event data
  app.delete("/api/live-events", async (req, res) => {
    try {
      const meetId = req.query.meetId as string | undefined;
      await storage.clearLiveEventData(meetId);
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // ==================== Athlete Bests API ====================

  // Get all bests for an athlete
  app.get("/api/athletes/:athleteId/bests", async (req, res) => {
    try {
      const { athleteId } = req.params;
      const bests = await storage.getAthleteBests(athleteId);
      res.json(bests);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get all bests for athletes in a meet
  app.get("/api/meets/:meetId/athlete-bests", async (req, res) => {
    try {
      const { meetId } = req.params;
      const bests = await storage.getAthleteBestsByMeet(meetId);
      res.json(bests);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Create or update an athlete best
  app.post("/api/athlete-bests", async (req, res) => {
    try {
      const data = req.body;
      
      // Validate required fields
      if (!data.athleteId || !data.eventType || !data.bestType || data.mark === undefined) {
        return res.status(400).json({ error: "Missing required fields: athleteId, eventType, bestType, mark" });
      }
      
      // Validate bestType
      if (!['college', 'season'].includes(data.bestType)) {
        return res.status(400).json({ error: "bestType must be 'college' or 'season'" });
      }
      
      const best = await storage.upsertAthleteBest({
        athleteId: data.athleteId,
        eventType: data.eventType,
        bestType: data.bestType,
        mark: parseFloat(data.mark),
        seasonId: data.seasonId || null,
        achievedAt: data.achievedAt ? new Date(data.achievedAt) : null,
        meetName: data.meetName || null,
        source: data.source || 'manual',
      });
      
      res.status(201).json(best);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Update an athlete best
  app.patch("/api/athlete-bests/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      
      const best = await storage.updateAthleteBest(id, updates);
      if (!best) {
        return res.status(404).json({ error: "Athlete best not found" });
      }
      
      res.json(best);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Delete an athlete best
  app.delete("/api/athlete-bests/:id", async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deleteAthleteBest(id);
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Bulk import athlete bests from CSV
  app.post("/api/meets/:meetId/athlete-bests/import", async (req, res) => {
    try {
      const { meetId } = req.params;
      const { bests } = req.body; // Array of { athleteNumber, eventType, bestType, mark, meetName?, achievedAt? }
      
      if (!Array.isArray(bests)) {
        return res.status(400).json({ error: "bests must be an array" });
      }
      
      // Get all athletes in the meet for lookup by number
      const athletes = await storage.getAthletesByMeetId(meetId);
      const athletesByNumber = new Map(athletes.map(a => [String(a.athleteNumber), a]));
      
      // Get current season for the meet
      const meet = await storage.getMeet(meetId);
      const seasonId = meet?.seasonId || null;
      
      const results: { success: number; failed: number; errors: string[] } = {
        success: 0,
        failed: 0,
        errors: [],
      };
      
      for (const item of bests) {
        try {
          const athlete = athletesByNumber.get(String(item.athleteNumber));
          if (!athlete) {
            results.failed++;
            results.errors.push(`Athlete ${item.athleteNumber} not found`);
            continue;
          }
          
          await storage.upsertAthleteBest({
            athleteId: athlete.id,
            eventType: item.eventType,
            bestType: item.bestType,
            mark: parseFloat(item.mark),
            seasonId: item.bestType === 'season' ? seasonId : null,
            achievedAt: item.achievedAt ? new Date(item.achievedAt) : null,
            meetName: item.meetName || null,
            source: 'import',
          });
          
          results.success++;
        } catch (err: any) {
          results.failed++;
          results.errors.push(`Error for athlete ${item.athleteNumber}: ${err.message}`);
        }
      }
      
      res.json(results);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get saved Lynx configs
  app.get("/api/lynx/saved-configs", async (req, res) => {
    try {
      const meetId = req.query.meetId as string | undefined;
      const configs = await storage.getLynxConfigs(meetId);
      res.json(configs);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // ===============================
  // INGESTION SETTINGS ROUTES
  // ===============================

  // Get ingestion settings for a meet
  app.get("/api/meets/:meetId/ingestion-settings", async (req, res) => {
    try {
      const { meetId } = req.params;
      const settings = await storage.getIngestionSettings(meetId);
      res.json(settings || {
        meetId,
        lynxFilesDirectory: null,
        lynxFilesEnabled: false,
        hytekMdbPath: null,
        hytekMdbEnabled: false,
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Update ingestion settings for a meet
  app.patch("/api/meets/:meetId/ingestion-settings", async (req, res) => {
    try {
      const { meetId } = req.params;
      const settings = await storage.upsertIngestionSettings({
        meetId,
        ...req.body,
      });
      
      // Restart watchers if enabled
      const { ingestionManager } = await import('./ingestion-manager');
      if (settings.lynxFilesEnabled || settings.hytekMdbEnabled) {
        await ingestionManager.startWatchersForMeet(meetId);
      } else {
        await ingestionManager.stopWatchersForMeet(meetId);
      }
      
      res.json(settings);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get ingestion status for a meet
  app.get("/api/meets/:meetId/ingestion-status", async (req, res) => {
    try {
      const { meetId } = req.params;
      const { ingestionManager } = await import('./ingestion-manager');
      const status = await ingestionManager.getStatus(meetId);
      res.json(status);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Test Lynx files directory
  app.post("/api/meets/:meetId/ingestion-settings/test-lynx-directory", async (req, res) => {
    try {
      const { directory } = req.body;
      const { ingestionManager } = await import('./ingestion-manager');
      const result = await ingestionManager.testLynxDirectory(directory);
      res.json(result);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Test HyTek MDB file path
  app.post("/api/meets/:meetId/ingestion-settings/test-mdb-path", async (req, res) => {
    try {
      const { path } = req.body;
      const { ingestionManager } = await import('./ingestion-manager');
      const result = await ingestionManager.testMdbPath(path);
      res.json(result);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Start ingestion for a meet
  app.post("/api/meets/:meetId/ingestion-settings/start", async (req, res) => {
    try {
      const { meetId } = req.params;
      const { ingestionManager } = await import('./ingestion-manager');
      const result = await ingestionManager.startWatchersForMeet(meetId);
      res.json(result);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Stop ingestion for a meet
  app.post("/api/meets/:meetId/ingestion-settings/stop", async (req, res) => {
    try {
      const { meetId } = req.params;
      const { ingestionManager } = await import('./ingestion-manager');
      await ingestionManager.stopWatchersForMeet(meetId);
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get processed files for a meet
  app.get("/api/meets/:meetId/processed-files", async (req, res) => {
    try {
      const { meetId } = req.params;
      const files = await storage.getProcessedFiles(meetId);
      res.json(files);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Clear processed files for a meet
  app.delete("/api/meets/:meetId/processed-files", async (req, res) => {
    try {
      const { meetId } = req.params;
      await storage.clearProcessedFiles(meetId);
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Trigger immediate MDB import
  app.post("/api/meets/:meetId/ingestion-settings/import-mdb", async (req, res) => {
    try {
      const { meetId } = req.params;
      const settings = await storage.getIngestionSettings(meetId);
      
      if (!settings?.hytekMdbPath) {
        return res.status(400).json({ error: 'No MDB path configured' });
      }
      
      // Clear existing import data before re-importing
      const clearStats = await storage.clearMeetImportData(meetId);
      console.log(`🧹 Pre-import clear: ${JSON.stringify(clearStats)}`);
      
      const stats = await importCompleteMDB(settings.hytekMdbPath, meetId);
      
      await storage.updateIngestionSettings(meetId, {
        hytekMdbLastImportAt: new Date(),
      } as any);
      
      res.json({ success: true, stats });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get live meet state (aggregated)
  app.get("/api/meets/:meetId/live", async (req, res) => {
    try {
      const { meetId } = req.params;
      const events = await storage.getEventsByMeetId(meetId);
      const currentEventNumber = lynxListener.getCurrentEventNumber();
      
      // Find active track event
      const activeTrackEvent = events.find(e => 
        e.eventNumber === currentEventNumber && 
        (e.eventType?.includes('m') || e.eventType?.includes('hurdles') || e.eventType?.includes('relay'))
      );
      
      // Find active field events (in_progress status)
      const activeFieldEvents = events.filter(e => 
        e.status === 'in_progress' && 
        !e.eventType?.includes('m') && 
        !e.eventType?.includes('hurdles') && 
        !e.eventType?.includes('relay')
      );
      
      const response: MeetLiveState = {
        meetId,
        activeTrackEvent: activeTrackEvent ? {
          event: activeTrackEvent,
          mode: liveState.trackMode,
          runningTime: liveState.runningTime,
          isArmed: liveState.isArmed,
          isRunning: liveState.isRunning,
        } : undefined,
        activeFieldEvents: await Promise.all(activeFieldEvents.map(async event => {
          const fieldState = liveState.activeFieldEvents.get(event.eventNumber || 0);
          return {
            event,
            mode: fieldState?.mode || 'idle' as FieldDisplayMode,
            currentAthlete: undefined, // Would need to look up by name
            currentAttemptNumber: fieldState?.attemptNumber,
            currentHeight: fieldState?.mark,
          };
        })),
        recentResults: [], // Would populate from entries with recent times
        timestamp: Date.now(),
      };
      
      res.json(response);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Track mode change handler - SIMPLIFIED: just pass through raw data from FinishLynx
  // Layout switching is now controlled by FinishLynx via layout-command events
  lynxListener.on('track-mode-change', async (eventNumber, mode, data) => {
    const isBigBoard = data.sourcePortType === 'results_big';
    console.log(`[Lynx] Track mode change: Event ${eventNumber} → ${mode} (${isBigBoard ? 'BIG BOARD' : 'standard'})`);
    liveState.trackMode = mode;
    liveState.currentEventNumber = eventNumber;
    liveState.isArmed = data.armed || false;
    
    try {
      // Auto-activate event when data arrives (set to in_progress if scheduled)
      const allMatchingEvents = await storage.getEventsByLynxEventNumber(eventNumber);

      // Get total heats from EVT watcher for the active meet
      const roundNum = data.round ? parseInt(String(data.round)) : 1;
      const activeMeetId = await getActiveMeetId();

      // Filter to active meet's events to avoid stale data from old meets
      const matchingEvents = activeMeetId 
        ? allMatchingEvents.filter(e => e.meetId === activeMeetId) 
        : allMatchingEvents;
      // Fallback to all events if no matches in active meet
      const effectiveEvents = matchingEvents.length > 0 ? matchingEvents : allMatchingEvents;

      for (const event of effectiveEvents) {
        if (event.status === 'scheduled') {
          await storage.updateEventStatus(event.id, 'in_progress');
          console.log(`[Lynx] Auto-activated event ${event.name} (${event.id}) to in_progress`);
          await broadcastCurrentEvent();
        }
      }

      let evtHeats: number | null = null;
      if (activeMeetId) {
        evtHeats = getTotalHeatsFromCache(activeMeetId, data.eventNumber, roundNum);
        console.log(`[Lynx Heat] eventNumber=${data.eventNumber}, round=${roundNum}, totalHeats=${evtHeats} (active meet: ${activeMeetId})`);
      } else {
        evtHeats = getTotalHeatsFromAnyWatcher(data.eventNumber, roundNum);
        console.log(`[Lynx Heat] eventNumber=${data.eventNumber}, round=${roundNum}, totalHeats=${evtHeats} (no active meet, searched all)`);
      }
      const totalHeats = evtHeats ?? 1;
      
      // Get round name and advancement formula from database if event exists
      // Use only events from the active meet to avoid stale advancement formulas from old meets
      let roundName = 'Finals';
      let totalRounds = 1;
      let advanceByPlace: number | null = null;
      let advanceByTime: number | null = null;
      let isMultiEvent: boolean = false;
      let eventType: string | null = null;
      let eventGender: string | null = null;
      
      if (effectiveEvents.length > 0) {
        const event = effectiveEvents[0];
        totalRounds = event.numRounds || 1;
        advanceByPlace = event.advanceByPlace ?? null;
        advanceByTime = event.advanceByTime ?? null;
        isMultiEvent = event.isMultiEvent ?? false;
        eventType = event.eventType ?? null;
        eventGender = event.gender ?? null;
        
        // Determine round name based on event configuration
        if (totalRounds === 1) {
          roundName = 'Finals';
        } else if (totalRounds === 2) {
          roundName = roundNum === 1 ? 'Prelims' : 'Finals';
        } else if (totalRounds === 3) {
          if (roundNum === 1) roundName = 'Prelims';
          else if (roundNum === 2) roundName = 'Semis';
          else roundName = 'Finals';
        } else if (totalRounds === 4) {
          if (roundNum === 1) roundName = 'Prelims';
          else if (roundNum === 2) roundName = 'Quarters';
          else if (roundNum === 3) roundName = 'Semis';
          else roundName = 'Finals';
        } else {
          if (roundNum === totalRounds) roundName = 'Finals';
          else if (roundNum === totalRounds - 1) roundName = 'Semis';
          else roundName = `Round ${roundNum}`;
        }
      }

      // Determine display mode for scene template mapping
      // Multi-events use 'multi_track' instead of 'track_results' to show points
      let displayMode = mode === 'results' ? 'track_results' : 
                        mode === 'running' ? 'running_time' : 
                        mode === 'start_list' ? 'start_list' : mode;
      if (isMultiEvent && mode === 'results') {
        displayMode = 'multi_track';
      }
      
      // Broadcast to different channels based on source port
      // Big board data goes to 'track_mode_change_big', regular goes to 'track_mode_change'
      const messageType = isBigBoard ? 'track_mode_change_big' : 'track_mode_change';
      broadcastToDisplays({
        type: messageType,
        data: {
          eventNumber,
          mode,
          displayMode, // Scene template mapping mode (multi_track for multi-events)
          totalHeats, // Include total heats for "Heat X of Y" display
          roundName, // Include round name for "Prelims", "Finals", etc.
          totalRounds, // Total rounds configured for event
          advanceByPlace, // For qualifier display (big Q)
          advanceByTime, // For qualifier display (little q)
          isMultiEvent, // For multi-event points display
          eventType, // For calculating multi-event points
          gender: eventGender, // For calculating multi-event points
          ...data, // Pass through all raw data from FinishLynx
        }
      } as any);
    } catch (error) {
      console.error('[Lynx] Error handling track mode change:', error);
    }
  });

  // Clock handler - NO SMART LOGIC, just pass through exactly what FinishLynx sends
  lynxListener.on('clock-update', (eventNumber, time, command) => {
    // Just broadcast the raw clock data to all displays
    broadcastToDisplays({
      type: 'clock_update',
      data: {
        eventNumber,
        time,
        command,
      }
    } as WSMessage);
  });

  // Layout command handler - FinishLynx tells us when to switch layouts
  // Uses ResulTV-style Command=LayoutDraw;Name=XXX; format
  // IMPORTANT: "Start List" command signals start of a new page - clear accumulated entries
  lynxListener.on('layout-command', (layoutName: string, sourcePortType?: string) => {
    const isBigBoard = sourcePortType === 'results_big';
    const acc = isBigBoard ? entryAccumulatorBig : entryAccumulator;
    console.log(`[Lynx] Layout command: ${layoutName} (${isBigBoard ? 'BIG BOARD' : 'standard'})`);
    
    // Clear accumulated entries ONLY on exact "Start List" command (page boundary)
    // FinishLynx sends "Command=LayoutDraw;Name=Start List;" before each page of entries
    // Don't clear on "Results" or other commands - that's a different display mode
    const normalizedLayout = layoutName.toLowerCase().trim();
    if (normalizedLayout === 'start list' || normalizedLayout === 'startlist') {
      console.log(`[Lynx] Clearing ${isBigBoard ? 'big board' : 'standard'} entry accumulator for new page (${acc.entries.length} entries cleared)`);
      acc.entries = [];
      acc.lastLayoutCommand = layoutName;
    }
    
    // Broadcast layout switch command - big board uses separate channel
    const messageType = isBigBoard ? 'layout_command_big' : 'layout_command';
    broadcastToDisplays({
      type: messageType,
      data: {
        layoutName,
      }
    } as any);
  });

  lynxListener.on('result', async (eventNumber, lane, place, time, athleteName) => {
    console.log(`[Lynx] Result: Event ${eventNumber}, Lane ${lane}, Place ${place}, Time ${time}`);
    
    try {
      // Get existing entries and merge new result
      const existing = await storage.getLiveEventData(eventNumber);
      const entries = (existing?.entries as any[]) || [];
      
      // Find or add entry for this lane
      const laneStr = String(lane);
      const existingIdx = entries.findIndex((e: any) => e.lane === laneStr);
      const newEntry = {
        lane: laneStr,
        place: String(place),
        time,
        name: athleteName,
      };
      
      if (existingIdx >= 0) {
        entries[existingIdx] = { ...entries[existingIdx], ...newEntry };
      } else {
        entries.push(newEntry);
      }
      
      // Store updated entries
      await storage.upsertLiveEventData({
        eventNumber,
        eventType: 'track',
        mode: 'results',
        heat: existing?.heat || 1,
        round: existing?.round || 1,
        flight: 1,
        entries,
        isRunning: false,
      });
      
      // Update combined events if this is a component event
      const combinedEventsToUpdate = await storage.getCombinedEventsByLynxEventNumber(eventNumber);
      for (const ce of combinedEventsToUpdate) {
        await storage.updateCombinedEventTotals(ce.id);
        const standings = await storage.getCombinedEventStandings(ce.id);
        broadcastToDisplays({
          type: 'combined_event_update',
          meetId: ce.meetId,
          combinedEventId: ce.id,
          standings
        });
        console.log(`[Lynx] Updated combined event ${ce.id} standings after track result`);
      }
    } catch (error) {
      console.error('[Lynx] Error storing result:', error);
    }
    
    // Broadcast result
    broadcastToDisplays({
      type: 'result_received',
      data: {
        eventNumber,
        lane,
        place,
        time,
        athleteName,
      }
    } as WSMessage);
  });

  lynxListener.on('field-mode-change', async (eventNumber, mode, data) => {
    console.log(`[Lynx] Field mode change: Event ${eventNumber} → ${mode}`, data);
    
    // Update field port state to reset the standings timer
    // This will exit standings mode if active and reset the idle timer
    // Prefer sourcePort from TCP listener over currentFieldPort from HTTP
    const resolvedFieldPort = (data.sourcePort && data.sourcePort >= FIELD_PORT_MIN && data.sourcePort <= FIELD_PORT_MAX) ? data.sourcePort : currentFieldPort;
    if (resolvedFieldPort) {
      updateFieldPortState(resolvedFieldPort, eventNumber, data.round || 1);
    }
    
    liveState.activeFieldEvents.set(eventNumber, {
      mode,
      athleteName: data.athleteName,
      attemptNumber: data.attemptNumber,
      mark: data.mark,
    });
    
    let accumulatedResults = data.results || [];
    let isMultiEvent = false;
    let eventType: string | null = null;
    let eventGender: string | null = null;
    
    try {
      // Auto-activate event when data arrives (set to in_progress if scheduled)
      const allFieldMatchEvents = await storage.getEventsByLynxEventNumber(eventNumber);
      // Filter to active meet's events to avoid stale data from old meets
      const fieldActiveMeetId = await getActiveMeetId();
      const fieldMeetFiltered = fieldActiveMeetId 
        ? allFieldMatchEvents.filter(e => e.meetId === fieldActiveMeetId) 
        : allFieldMatchEvents;
      const fieldEffectiveEvents = fieldMeetFiltered.length > 0 ? fieldMeetFiltered : allFieldMatchEvents;
      
      for (const event of fieldEffectiveEvents) {
        if (event.status === 'scheduled') {
          await storage.updateEventStatus(event.id, 'in_progress');
          console.log(`[Lynx] Auto-activated field event ${event.name} (${event.id}) to in_progress`);
          await broadcastCurrentEvent();
        }
        // Get multi-event info from first matching event
        if (!eventType) {
          isMultiEvent = event.isMultiEvent ?? false;
          eventType = event.eventType ?? null;
          eventGender = event.gender ?? null;
        }
      }
      
      // Store field event data to database (accumulate results, don't overwrite)
      const existing = await storage.getLiveEventData(eventNumber);
      
      // Merge with existing results if available
      if (existing?.entries && Array.isArray(existing.entries)) {
        const existingResults = existing.entries as any[];
        for (const newResult of (data.results || [])) {
          const existingIdx = existingResults.findIndex((e: any) => 
            (e.bib && e.bib === newResult.bib) || (e.name && e.name === newResult.name)
          );
          if (existingIdx >= 0) {
            existingResults[existingIdx] = { ...existingResults[existingIdx], ...newResult };
          } else {
            existingResults.push(newResult);
          }
        }
        accumulatedResults = existingResults;
      }
      
      // Sort results by place number
      accumulatedResults.sort((a: any, b: any) => {
        const placeA = parseInt(a.place) || 999;
        const placeB = parseInt(b.place) || 999;
        return placeA - placeB;
      });
      
      await storage.upsertLiveEventData({
        eventNumber,
        eventType: 'field',
        mode,
        heat: 1,
        round: data.round || 1,
        flight: data.flight || 1,
        wind: data.wind,
        status: data.officialStatus,
        eventName: data.eventName,
        entries: accumulatedResults,
      });
    } catch (error) {
      console.error('[Lynx] Error storing field mode change:', error);
    }
    
    // Determine display mode for scene template mapping
    // Multi-events use 'multi_field' instead of 'field_results' to show points
    const displayMode = isMultiEvent ? 'multi_field' : 'field_results';
    
    // Get field port for routing: prefer sourcePort from TCP listener, fall back to currentFieldPort from HTTP
    const fieldPort = (data.sourcePort && data.sourcePort >= FIELD_PORT_MIN && data.sourcePort <= FIELD_PORT_MAX) ? data.sourcePort : currentFieldPort;
    
    // Broadcast field event update with accumulated results
    // Include fieldPort for port-based routing - displays can filter by port
    const fieldBroadcastData = {
      eventNumber,
      mode,
      displayMode, // Scene template mapping mode (multi_field for multi-events)
      eventName: data.eventName,
      flight: data.flight,
      wind: data.wind,
      results: accumulatedResults,
      isMultiEvent, // For multi-event points display
      eventType, // For calculating multi-event points
      gender: eventGender, // For calculating multi-event points
      fieldPort, // Port number for device routing (4560-4569)
    };
    
    // Broadcast to global channel (for displays not using port-based routing)
    broadcastToDisplays({
      type: 'field_mode_change',
      data: fieldBroadcastData,
    } as WSMessage);
    
    // Also broadcast to port-specific channel if a field port is set
    // This allows displays to subscribe to specific field events
    if (fieldPort) {
      broadcastToDisplays({
        type: `field_mode_change_${fieldPort}`,
        data: fieldBroadcastData,
      } as WSMessage);
      console.log(`[Lynx] Broadcast field data to port-specific channel: field_mode_change_${fieldPort}`);
    }
  });

  lynxListener.on('field-result', async (eventNumber, athleteName, place, mark, attemptNumber, attempts) => {
    console.log(`[Lynx] Field result: Event ${eventNumber}, ${athleteName}, Place ${place}, Mark ${mark}`);
    
    try {
      // Get existing entries and merge new result
      const existing = await storage.getLiveEventData(eventNumber);
      const entries = (existing?.entries as any[]) || [];
      
      // Find or add entry for this athlete
      const existingIdx = entries.findIndex((e: any) => e.name === athleteName);
      const newEntry = {
        name: athleteName,
        place: String(place),
        mark,
        attemptNumber: String(attemptNumber),
        attempts,
      };
      
      if (existingIdx >= 0) {
        entries[existingIdx] = { ...entries[existingIdx], ...newEntry };
      } else {
        entries.push(newEntry);
      }
      
      // Store updated entries
      await storage.upsertLiveEventData({
        eventNumber,
        eventType: 'field',
        mode: 'results',
        heat: 1,
        round: existing?.round || 1,
        flight: existing?.flight || 1,
        entries,
      });
      
      // Update combined events if this is a component event
      const combinedEventsToUpdate = await storage.getCombinedEventsByLynxEventNumber(eventNumber);
      for (const ce of combinedEventsToUpdate) {
        await storage.updateCombinedEventTotals(ce.id);
        const standings = await storage.getCombinedEventStandings(ce.id);
        broadcastToDisplays({
          type: 'combined_event_update',
          meetId: ce.meetId,
          combinedEventId: ce.id,
          standings
        });
        console.log(`[Lynx] Updated combined event ${ce.id} standings after field result`);
      }
    } catch (error) {
      console.error('[Lynx] Error storing field result:', error);
    }
    
    // Broadcast field result
    broadcastToDisplays({
      type: 'field_result',
      data: {
        eventNumber,
        athleteName,
        place,
        mark,
        attemptNumber,
        attempts,
      }
    } as WSMessage);
  });

  lynxListener.on('field-athlete-up', async (eventNumber, athleteName, attemptNumber, mark) => {
    console.log(`[Lynx] Field athlete up: Event ${eventNumber}, ${athleteName}, Attempt ${attemptNumber}`);
    
    // Broadcast athlete up
    broadcastToDisplays({
      type: 'field_athlete_up',
      data: {
        eventNumber,
        athleteName,
        attemptNumber,
        mark,
      }
    } as WSMessage);
  });
  
  // Start list handler - ACCUMULATES entries as they arrive one-by-one
  // Layout command "Start List" clears the accumulator, then entries fill in
  // Display reads entries[0] for Line 1, entries[1] for Line 2, etc.
  // IMPORTANT: FinishLynx sends entries in display order - DO NOT sort!
  lynxListener.on('start-list', async (eventNumber, heat, entries, metadata) => {
    const isBigBoard = metadata?.sourcePortType === 'results_big';
    const acc = isBigBoard ? entryAccumulatorBig : entryAccumulator;
    
    // Update accumulator metadata
    acc.eventNumber = eventNumber;
    acc.heat = heat;
    acc.eventName = metadata?.eventName || acc.eventName;
    acc.distance = metadata?.distance || acc.distance;
    
    // Accumulate new entries in arrival order (FinishLynx sends them in display order)
    // Skip empty entries (blank lane, bib, name)
    for (const entry of entries) {
      const hasContent = entry.lane || entry.bib || entry.name;
      if (hasContent) {
        acc.entries.push(entry);
      }
    }
    
    console.log(`[Lynx] Start list (${isBigBoard ? 'BIG BOARD' : 'standard'}): Event ${eventNumber}, Heat ${heat}, +${entries.length} entries, total: ${acc.entries.length}`);
    
    // Get total heats from EVT watcher for the active meet
    const roundNum = metadata?.round ? parseInt(String(metadata.round)) : 1;
    const activeMeetId = await getActiveMeetId();
    let evtHeats: number | null = null;
    if (activeMeetId) {
      evtHeats = getTotalHeatsFromCache(activeMeetId, eventNumber, roundNum);
      console.log(`[Lynx StartList Heat] eventNumber=${eventNumber}, round=${roundNum}, totalHeats=${evtHeats} (active meet: ${activeMeetId})`);
    } else {
      // Fallback to searching all watchers if no displays connected
      evtHeats = getTotalHeatsFromAnyWatcher(eventNumber, roundNum);
      console.log(`[Lynx StartList Heat] eventNumber=${eventNumber}, round=${roundNum}, totalHeats=${evtHeats} (no active meet, searched all)`);
    }
    const totalHeats = evtHeats ?? 1;
    
    // Get round name and advancement formula from database if event exists
    let roundName = 'Finals';
    let totalRounds = 1;
    let advanceByPlace: number | null = null;
    let advanceByTime: number | null = null;
    let isMultiEvent: boolean = false;
    let eventType: string | null = null;
    let eventGender: string | null = null;
    
    try {
      const allMatchEvents = await storage.getEventsByLynxEventNumber(eventNumber);
      // Filter to active meet's events to avoid stale advancement formulas from old meets
      const meetFilteredEvents = activeMeetId 
        ? allMatchEvents.filter(e => e.meetId === activeMeetId) 
        : allMatchEvents;
      const effectiveMatchEvents = meetFilteredEvents.length > 0 ? meetFilteredEvents : allMatchEvents;
      
      if (effectiveMatchEvents.length > 0) {
        const event = effectiveMatchEvents[0];
        totalRounds = event.numRounds || 1;
        advanceByPlace = event.advanceByPlace ?? null;
        advanceByTime = event.advanceByTime ?? null;
        isMultiEvent = event.isMultiEvent ?? false;
        eventType = event.eventType ?? null;
        eventGender = event.gender ?? null;
        
        // Determine round name based on event configuration
        if (totalRounds === 1) {
          roundName = 'Finals';
        } else if (totalRounds === 2) {
          roundName = roundNum === 1 ? 'Prelims' : 'Finals';
        } else if (totalRounds === 3) {
          if (roundNum === 1) roundName = 'Prelims';
          else if (roundNum === 2) roundName = 'Semis';
          else roundName = 'Finals';
        } else if (totalRounds === 4) {
          if (roundNum === 1) roundName = 'Prelims';
          else if (roundNum === 2) roundName = 'Quarters';
          else if (roundNum === 3) roundName = 'Semis';
          else roundName = 'Finals';
        } else {
          if (roundNum === totalRounds) roundName = 'Finals';
          else if (roundNum === totalRounds - 1) roundName = 'Semis';
          else roundName = `Round ${roundNum}`;
        }
      }
    } catch (error) {
      console.error('[Lynx] Error getting round info:', error);
    }
    
    // Broadcast entries in arrival order (FinishLynx controls display order)
    // Display maps by array position: Line 1 = entries[0], Line 2 = entries[1], etc.
    const messageType = isBigBoard ? 'start_list_big' : 'start_list';
    broadcastToDisplays({
      type: messageType,
      data: {
        eventNumber,
        heat,
        totalHeats, // Include total heats for "Heat X of Y" display
        roundName, // Include round name for "Prelims", "Finals", etc.
        totalRounds, // Total rounds configured for event
        advanceByPlace, // For qualifier display (big Q)
        advanceByTime, // For qualifier display (little q)
        isMultiEvent, // For multi-event points display
        eventType, // For calculating multi-event points
        gender: eventGender, // For calculating multi-event points
        entries: acc.entries, // Arrival order = display order
        eventName: acc.eventName,
        distance: acc.distance,
      }
    } as any);
  });

  lynxListener.on('connection', (portType, connected) => {
    console.log(`[Lynx] Connection ${portType}: ${connected ? 'connected' : 'disconnected'}`);
    
    broadcastToDisplays({
      type: 'lynx_connection',
      data: {
        portType,
        connected,
      }
    } as WSMessage);
  });

  lynxListener.on('error', (error, portType) => {
    console.error(`[Lynx] Error on ${portType}:`, error.message);
  });

  // Auto-start Lynx listeners from saved configs or environment variables
  (async () => {
    try {
      // First try to load saved configs from database
      const savedConfigs = await storage.getLynxConfigs();
      
      if (savedConfigs.length > 0) {
        // Use saved database configs
        const lynxPortConfigs = savedConfigs.map(cfg => ({
          port: cfg.port,
          portType: cfg.portType as LynxPortType,
          name: cfg.name || `Lynx ${cfg.portType}`,
          host: cfg.host || undefined,
        }));
        
        lynxListener.configure(lynxPortConfigs);
        lynxListener.start();
        console.log(`✅ Lynx listeners auto-started from saved config with ${lynxPortConfigs.length} ports`);
        lynxPortConfigs.forEach(cfg => {
          console.log(`   - ${cfg.name}: port ${cfg.port} (${cfg.portType})`);
        });
      } else {
        // Fall back to environment variables
        const defaultLynxConfig = [];
        if (process.env.LYNX_CLOCK_PORT) {
          defaultLynxConfig.push({ port: parseInt(process.env.LYNX_CLOCK_PORT), portType: 'clock' as LynxPortType, name: 'FinishLynx Clock' });
        }
        if (process.env.LYNX_RESULTS_PORT) {
          defaultLynxConfig.push({ port: parseInt(process.env.LYNX_RESULTS_PORT), portType: 'results' as LynxPortType, name: 'FinishLynx Results' });
        }
        if (process.env.LYNX_FIELD_PORT) {
          defaultLynxConfig.push({ port: parseInt(process.env.LYNX_FIELD_PORT), portType: 'field' as LynxPortType, name: 'FieldLynx' });
        }
        
        if (defaultLynxConfig.length > 0) {
          lynxListener.configure(defaultLynxConfig);
          lynxListener.start();
          console.log(`✅ Lynx listeners started from env vars with ${defaultLynxConfig.length} ports`);
        } else if (process.env.EDGE_MODE === 'true') {
          // In Edge Mode, auto-start with default ports for FinishLynx
          // Port 4554: Big Board (8+ lines), Port 4555: Small Board (P10/P6)
          const edgeDefaultConfig = [
            { port: 4554, portType: 'results_big' as LynxPortType, name: 'Big Board Results' },
            { port: 4555, portType: 'results' as LynxPortType, name: 'FinishLynx Results' },
            { port: 4556, portType: 'clock' as LynxPortType, name: 'FinishLynx Clock' },
            { port: 4557, portType: 'field' as LynxPortType, name: 'FieldLynx' },
            { port: 4560, portType: 'field' as LynxPortType, name: 'FieldLynx Port 4560' },
            { port: 4561, portType: 'field' as LynxPortType, name: 'FieldLynx Port 4561' },
            { port: 4562, portType: 'field' as LynxPortType, name: 'FieldLynx Port 4562' },
            { port: 4563, portType: 'field' as LynxPortType, name: 'FieldLynx Port 4563' },
            { port: 4564, portType: 'field' as LynxPortType, name: 'FieldLynx Port 4564' },
            { port: 4565, portType: 'field' as LynxPortType, name: 'FieldLynx Port 4565' },
            { port: 4566, portType: 'field' as LynxPortType, name: 'FieldLynx Port 4566' },
            { port: 4567, portType: 'field' as LynxPortType, name: 'FieldLynx Port 4567' },
            { port: 4568, portType: 'field' as LynxPortType, name: 'FieldLynx Port 4568' },
            { port: 4569, portType: 'field' as LynxPortType, name: 'FieldLynx Port 4569' },
          ];
          lynxListener.configure(edgeDefaultConfig);
          lynxListener.start();
          console.log(`✅ Lynx listeners auto-started for Edge Mode on default ports`);
          edgeDefaultConfig.forEach(cfg => {
            console.log(`   - ${cfg.name}: port ${cfg.port} (${cfg.portType})`);
          });
        } else {
          console.log('ℹ️ No Lynx configs found - waiting for configuration');
        }
      }
    } catch (error) {
      console.error('[Lynx] Error during auto-start:', error);
      
      // Fall back to environment variables on database error
      const defaultLynxConfig = [];
      if (process.env.LYNX_CLOCK_PORT) {
        defaultLynxConfig.push({ port: parseInt(process.env.LYNX_CLOCK_PORT), portType: 'clock' as LynxPortType, name: 'FinishLynx Clock' });
      }
      if (process.env.LYNX_RESULTS_PORT) {
        defaultLynxConfig.push({ port: parseInt(process.env.LYNX_RESULTS_PORT), portType: 'results' as LynxPortType, name: 'FinishLynx Results' });
      }
      if (process.env.LYNX_FIELD_PORT) {
        defaultLynxConfig.push({ port: parseInt(process.env.LYNX_FIELD_PORT), portType: 'field' as LynxPortType, name: 'FieldLynx' });
      }
      
      if (defaultLynxConfig.length > 0) {
        lynxListener.configure(defaultLynxConfig);
        lynxListener.start();
        console.log(`✅ Lynx listeners started from env vars with ${defaultLynxConfig.length} ports`);
      }
    }
  })();

  // ===============================
  // EVT DIRECTORY CONFIG ROUTES
  // ===============================
  
  const EVT_CONFIG_FILE = './evt-config.json';
  
  interface EVTConfig {
    directoryPath: string;
    resultsDirectory?: string; // Path for LIF export output
    // Horizontal event defaults (throws and jumps except high jump/pole vault)
    horizontalPrelimAttempts?: number;
    horizontalFinalists?: number;
    horizontalFinalAttempts?: number;
  }
  
  function loadEVTConfig(): EVTConfig | null {
    try {
      if (fs.existsSync(EVT_CONFIG_FILE)) {
        const content = fs.readFileSync(EVT_CONFIG_FILE, 'utf-8');
        return JSON.parse(content);
      }
    } catch (err) {
      console.error('[EVT Config] Error loading config:', err);
    }
    return null;
  }
  
  function saveEVTConfig(config: EVTConfig): void {
    fs.writeFileSync(EVT_CONFIG_FILE, JSON.stringify(config, null, 2));
  }
  
  app.get("/api/evt-config", async (req, res) => {
    try {
      const config = loadEVTConfig();
      res.json(config || { directoryPath: "" });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });
  
  app.post("/api/evt-config", async (req, res) => {
    try {
      const { directoryPath, resultsDirectory, horizontalPrelimAttempts, horizontalFinalists, horizontalFinalAttempts } = req.body;
      if (typeof directoryPath !== 'string') {
        return res.status(400).json({ error: "directoryPath must be a string" });
      }
      const prelimAttempts = horizontalPrelimAttempts ?? 3;
      const finalists = horizontalFinalists ?? 8;
      const finalAttempts = horizontalFinalAttempts ?? 3;
      
      const config: EVTConfig = { 
        directoryPath,
        resultsDirectory: resultsDirectory || undefined,
        horizontalPrelimAttempts: prelimAttempts,
        horizontalFinalists: finalists,
        horizontalFinalAttempts: finalAttempts,
      };
      saveEVTConfig(config);
      
      // Ensure results directory exists if specified
      if (resultsDirectory && !fs.existsSync(resultsDirectory)) {
        fs.mkdirSync(resultsDirectory, { recursive: true });
      }
      
      // Apply the new defaults to all existing field event sessions
      const allSessions = await storage.getAllFieldEventSessions();
      let updatedCount = 0;
      
      for (const session of allSessions) {
        const eventName = session.evtEventName || '';
        const updates: Record<string, any> = {};
        
        // Update results directory for all sessions
        if (resultsDirectory) {
          updates.lffExportPath = resultsDirectory;
        }
        
        // Apply horizontal event defaults
        if (isHorizontalEventName(eventName)) {
          updates.prelimAttempts = prelimAttempts;
          updates.finalsAttempts = finalAttempts;
          updates.athletesToFinals = finalists;
          updates.totalAttempts = prelimAttempts + finalAttempts;
        }
        
        if (Object.keys(updates).length > 0) {
          await storage.updateFieldEventSession(session.id, updates);
          updatedCount++;
        }
      }
      
      console.log(`[EVT Config] Applied config to ${updatedCount} sessions`);
      res.json({ ...config, updatedSessions: updatedCount });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });
  
  // Helper to detect field events from event name
  function isFieldEventName(eventName: string): boolean {
    const name = eventName.toLowerCase();
    const fieldEventKeywords = [
      'shot put', 'shot', 'discus', 'javelin', 'hammer', 'weight throw', 'weight',
      'long jump', 'triple jump', 'high jump', 'pole vault',
      'hj', 'pv', 'lj', 'tj', 'sp', 'dt', 'jt', 'ht', 'wt'
    ];
    return fieldEventKeywords.some(keyword => name.includes(keyword));
  }

  // Detect if an event is a vertical event (high jump or pole vault)
  function isVerticalEventName(eventName: string): boolean {
    const name = eventName.toLowerCase();
    const verticalKeywords = ['high jump', 'pole vault', 'hj', 'pv'];
    return verticalKeywords.some(keyword => name.includes(keyword));
  }

  // Detect if an event is a horizontal event (throws and jumps except vertical)
  function isHorizontalEventName(eventName: string): boolean {
    return isFieldEventName(eventName) && !isVerticalEventName(eventName);
  }
  
  app.get("/api/evt-events", async (req, res) => {
    try {
      const config = loadEVTConfig();
      if (!config || !config.directoryPath) {
        return res.json({ events: [] });
      }
      
      const { summaries } = parseEVTDirectory(config.directoryPath);
      // Filter to only show field events
      const fieldEvents = summaries.filter(evt => isFieldEventName(evt.eventName));
      res.json({ events: fieldEvents });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });
  
  app.get("/api/evt-events/:eventNumber/athletes", async (req, res) => {
    try {
      const config = loadEVTConfig();
      if (!config || !config.directoryPath) {
        return res.json({ athletes: [] });
      }
      
      const eventNumber = parseInt(req.params.eventNumber);
      
      if (isNaN(eventNumber)) {
        return res.status(400).json({ error: "Invalid event number" });
      }
      
      // Get all athletes for this event (all rounds/flights combined)
      const athletes = getAthletesFromDirectory(config.directoryPath, eventNumber);
      res.json({ athletes });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Auto-provision sessions for all EVT events
  app.post("/api/evt-events/provision-all", async (req, res) => {
    try {
      const config = loadEVTConfig();
      if (!config || !config.directoryPath) {
        return res.json({ created: 0, sessions: [] });
      }
      
      const { summaries } = parseEVTDirectory(config.directoryPath);
      const fieldEvents = summaries.filter(evt => isFieldEventName(evt.eventName));
      
      // Get all existing sessions to check which EVT events already have sessions
      const existingSessions = await storage.getAllFieldEventSessions();
      const existingEvtSessionMap = new Map<number, typeof existingSessions[0]>();
      const duplicatesToDelete: number[] = [];
      
      // Find duplicates - keep the newest session (highest ID) for each EVT event
      for (const s of existingSessions) {
        if (s.evtEventNumber !== null) {
          const existing = existingEvtSessionMap.get(s.evtEventNumber);
          if (existing) {
            // Keep the one with higher ID (newer), delete the older one
            if (s.id > existing.id) {
              duplicatesToDelete.push(existing.id);
              existingEvtSessionMap.set(s.evtEventNumber, s);
            } else {
              duplicatesToDelete.push(s.id);
            }
          } else {
            existingEvtSessionMap.set(s.evtEventNumber, s);
          }
        }
      }
      
      // Delete duplicate sessions
      for (const dupId of duplicatesToDelete) {
        try {
          await storage.deleteFieldEventSession(dupId);
          console.log(`[EVT Provision] Deleted duplicate session ${dupId}`);
        } catch (e) {
          console.error(`[EVT Provision] Failed to delete duplicate session ${dupId}:`, e);
        }
      }
      
      const createdSessions = [];
      let updatedCount = 0;
      let athletesSyncedCount = 0;
      
      // Update any existing check_in sessions to in_progress
      for (const session of existingSessions) {
        if (session.status === "check_in") {
          await storage.updateFieldEventSession(session.id, { status: "in_progress" });
          // Also update all athletes to checked_in status
          const athletes = await storage.getFieldEventAthletes(session.id);
          for (const athlete of athletes) {
            if (athlete.checkInStatus === "pending") {
              await storage.updateFieldEventAthlete(athlete.id, { checkInStatus: "checked_in" });
            }
          }
          updatedCount++;
        }
      }
      
      // Populate athletes for existing EVT sessions that have 0 athletes
      for (const [evtEventNumber, session] of existingEvtSessionMap) {
        const existingAthletes = await storage.getFieldEventAthletes(session.id);
        if (existingAthletes.length === 0) {
          // Load athletes from EVT files for this event
          const athletes = getAthletesFromDirectory(config.directoryPath, evtEventNumber);
          let orderInFlight = 1;
          for (const athlete of athletes) {
            await storage.createFieldEventAthlete({
              sessionId: session.id,
              entryId: null,
              evtBibNumber: athlete.bibNumber,
              evtFirstName: athlete.firstName,
              evtLastName: athlete.lastName,
              evtTeam: athlete.team,
              order: athlete.order,
              orderInFlight: orderInFlight++,
              flightNumber: athlete.flight || 1,
              checkInStatus: "checked_in",
              competitionStatus: "competing",
            });
          }
          if (athletes.length > 0) {
            console.log(`[EVT Provision] Synced ${athletes.length} athletes to session ${session.id} (${session.evtEventName})`);
            athletesSyncedCount++;
          }
        }
      }
      
      for (const evt of fieldEvents) {
        // Skip if session already exists for this EVT event
        if (existingEvtSessionMap.has(evt.eventNumber)) {
          continue;
        }
        
        // Generate access code
        const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
        let accessCode = "";
        for (let i = 0; i < 6; i++) {
          accessCode += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        
        // Determine if this is a horizontal event (uses global defaults) or vertical
        const isHorizontal = isHorizontalEventName(evt.eventName);
        
        // Use config defaults for horizontal events, manual config for vertical
        const prelimAttempts = isHorizontal ? (config.horizontalPrelimAttempts ?? 3) : 3;
        const finalsAttempts = isHorizontal ? (config.horizontalFinalAttempts ?? 3) : 3;
        const athletesToFinals = isHorizontal ? (config.horizontalFinalists ?? 8) : 8;
        const totalAttempts = prelimAttempts + finalsAttempts;
        
        // Use configured results directory for LIF export if specified
        let lffExportPath: string | undefined;
        if (config.resultsDirectory) {
          lffExportPath = config.resultsDirectory;
          // Ensure the directory exists
          if (!fs.existsSync(lffExportPath)) {
            fs.mkdirSync(lffExportPath, { recursive: true });
          }
        }
        
        // Create session with in_progress status (immediately active and configurable)
        const sessionData = {
          eventId: null,
          status: "in_progress" as const,
          measurementUnit: "metric" as const,
          recordWind: false,
          hasFinals: isHorizontal, // Enable finals for horizontal events by default
          prelimAttempts,
          finalsAttempts,
          athletesToFinals,
          totalAttempts,
          accessCode,
          evtEventNumber: evt.eventNumber,
          evtEventName: evt.eventName,
          lffExportPath, // Use configured results directory
        };
        
        const session = await storage.createFieldEventSession(sessionData);
        
        // Also load athletes from EVT file and add them
        const athletes = getAthletesFromDirectory(config.directoryPath, evt.eventNumber);
        let orderInFlight = 1;
        for (const athlete of athletes) {
          await storage.createFieldEventAthlete({
            sessionId: session.id,
            entryId: null,
            evtBibNumber: athlete.bibNumber,
            evtFirstName: athlete.firstName,
            evtLastName: athlete.lastName,
            evtTeam: athlete.team,
            order: athlete.order,
            orderInFlight: orderInFlight++,
            flightNumber: athlete.flight || 1,
            checkInStatus: "checked_in",
            competitionStatus: "competing",
          });
        }
        
        createdSessions.push(session);
      }
      
      res.json({ 
        created: createdSessions.length,
        updated: updatedCount,
        athletesSynced: athletesSyncedCount,
        sessions: createdSessions,
        total: fieldEvents.length
      });
    } catch (error: any) {
      console.error("Error provisioning EVT sessions:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // ===============================
  // TRACK HEAT WATCHER ROUTES
  // ===============================
  
  const TRACK_HEAT_CONFIG_FILE = './track-heat-config.json';
  
  interface TrackHeatConfig {
    meetId: string;
    evtFilePath: string;
  }
  
  function loadTrackHeatConfigs(): TrackHeatConfig[] {
    try {
      if (fs.existsSync(TRACK_HEAT_CONFIG_FILE)) {
        const content = fs.readFileSync(TRACK_HEAT_CONFIG_FILE, 'utf-8');
        return JSON.parse(content);
      }
    } catch (err) {
      console.error('[Track Heat Config] Error loading config:', err);
    }
    return [];
  }
  
  function saveTrackHeatConfigs(configs: TrackHeatConfig[]): void {
    fs.writeFileSync(TRACK_HEAT_CONFIG_FILE, JSON.stringify(configs, null, 2));
  }
  
  // Set up the broadcast callback for heat count updates
  setHeatCountBroadcastCallback((meetId: string, data: HeatCountData[]) => {
    broadcastToDisplays({
      type: 'heat_counts_update',
      meetId,
      heatCounts: data,
    } as any);
    console.log(`[Track Heat Watcher] Broadcast heat counts for meet ${meetId}:`, data);
  });
  
  // Initialize track heat watchers on startup
  (async () => {
    try {
      const configs = loadTrackHeatConfigs();
      for (const config of configs) {
        const result = startTrackHeatWatcher(config.meetId, config.evtFilePath);
        if (result.success) {
          console.log(`[Track Heat Watcher] Initialized watcher for meet ${config.meetId}`);
        }
      }
    } catch (err) {
      console.error('[Track Heat Watcher] Error initializing watchers:', err);
    }
  })();
  
  // Set up the broadcast callback for hytek mdb imports
  setHytekImportCallback((meetId: string) => {
    broadcastToDisplays({
      type: 'hytek_import_complete',
      meetId,
    } as any);
    console.log(`[HyTek MDB Watcher] Broadcast cache invalidation for meet ${meetId}`);
  });

  // Initialize hytek mdb watchers on startup
  (async () => {
    try {
      const hytekConfigs = loadHytekMdbConfigs();
      for (const config of hytekConfigs) {
        const result = startHytekMdbWatcher(config.meetId, config.mdbDirectory);
        if (result.success) {
          console.log(`[HyTek MDB Watcher] Initialized watcher for meet ${config.meetId}`);
        }
      }
    } catch (err) {
      console.error('[HyTek MDB Watcher] Error initializing watchers:', err);
    }
  })();
  
  // Get current track heat watcher config
  app.get("/api/track-heat-watcher", async (req, res) => {
    try {
      const configs = loadTrackHeatConfigs();
      const activeWatchers = getActiveTrackHeatWatchers();
      res.json({ configs, activeWatchers });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });
  
  // Get heat counts for a specific meet
  app.get("/api/track-heat-watcher/:meetId/heats", async (req, res) => {
    try {
      const meetId = req.params.meetId;
      const heatCounts = getAllHeatCountsForMeet(meetId);
      res.json({ meetId, heatCounts });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });
  
  // Get specific heat count
  app.get("/api/track-heat-watcher/:meetId/heats/:eventNumber/:round", async (req, res) => {
    try {
      const meetId = req.params.meetId;
      const eventNumber = parseInt(req.params.eventNumber);
      const round = parseInt(req.params.round) || 1;
      
      const totalHeats = getTotalHeatsFromCache(meetId, eventNumber, round);
      res.json({ meetId, eventNumber, round, totalHeats: totalHeats ?? null });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });
  
  // Start/configure track heat watcher for a meet
  app.post("/api/track-heat-watcher", async (req, res) => {
    try {
      const { meetId, evtFilePath } = req.body;
      
      if (!meetId || typeof meetId !== 'string') {
        return res.status(400).json({ error: "meetId is required" });
      }
      
      if (!evtFilePath || typeof evtFilePath !== 'string') {
        return res.status(400).json({ error: "evtFilePath is required" });
      }
      
      // Start the watcher
      const result = startTrackHeatWatcher(meetId, evtFilePath);
      
      if (!result.success) {
        return res.status(400).json({ error: result.error });
      }
      
      // Save to config
      const configs = loadTrackHeatConfigs();
      const existingIndex = configs.findIndex(c => c.meetId === meetId);
      if (existingIndex >= 0) {
        configs[existingIndex] = { meetId, evtFilePath };
      } else {
        configs.push({ meetId, evtFilePath });
      }
      saveTrackHeatConfigs(configs);
      
      // Return current heat counts
      const heatCounts = getAllHeatCountsForMeet(meetId);
      
      res.json({ 
        success: true, 
        meetId, 
        evtFilePath,
        heatCounts 
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });
  
  // Stop track heat watcher for a meet
  app.delete("/api/track-heat-watcher/:meetId", async (req, res) => {
    try {
      const meetId = req.params.meetId;
      
      stopTrackHeatWatcher(meetId);
      
      // Remove from config
      const configs = loadTrackHeatConfigs();
      const filtered = configs.filter(c => c.meetId !== meetId);
      saveTrackHeatConfigs(filtered);
      
      res.json({ success: true, meetId });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // ===============================
  // HYTEK MDB WATCHER ROUTES
  // ===============================
  
  // Get current hytek mdb watcher config and status
  app.get("/api/hytek-mdb-watcher", async (req, res) => {
    try {
      const configs = loadHytekMdbConfigs();
      const activeWatchers = getActiveHytekMdbWatchers();
      res.json({ configs, activeWatchers });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });
  
  // Start/update hytek mdb watcher
  app.post("/api/hytek-mdb-watcher", async (req, res) => {
    try {
      const { meetId, mdbDirectory } = req.body;
      
      if (!meetId || typeof meetId !== 'string') {
        return res.status(400).json({ error: "meetId is required" });
      }
      
      if (!mdbDirectory || typeof mdbDirectory !== 'string') {
        return res.status(400).json({ error: "mdbDirectory is required" });
      }
      
      const result = startHytekMdbWatcher(meetId, mdbDirectory);
      
      if (!result.success) {
        return res.status(400).json({ error: result.error });
      }
      
      // Save to config
      const configs = loadHytekMdbConfigs();
      const existingIndex = configs.findIndex(c => c.meetId === meetId);
      if (existingIndex >= 0) {
        configs[existingIndex] = { meetId, mdbDirectory };
      } else {
        configs.push({ meetId, mdbDirectory });
      }
      saveHytekMdbConfigs(configs);
      
      res.json({ success: true, meetId, mdbDirectory });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });
  
  // Trigger manual re-import
  app.post("/api/hytek-mdb-watcher/:meetId/reimport", async (req, res) => {
    try {
      const meetId = req.params.meetId;
      const result = await triggerManualImport(meetId);
      
      if (!result.success) {
        return res.status(400).json({ error: result.error });
      }
      
      res.json(result);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });
  
  // Stop hytek mdb watcher
  app.delete("/api/hytek-mdb-watcher/:meetId", async (req, res) => {
    try {
      const meetId = req.params.meetId;
      
      stopHytekMdbWatcher(meetId);
      
      // Remove from config
      const configs = loadHytekMdbConfigs();
      const filtered = configs.filter(c => c.meetId !== meetId);
      saveHytekMdbConfigs(filtered);
      
      res.json({ success: true, meetId });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // ===============================
  // FIELD EVENT SESSION ROUTES
  // ===============================

  // Rate limiting for access code lookups (prevent brute-force)
  const accessCodeAttempts = new Map<string, { count: number; lastAttempt: number }>();
  const RATE_LIMIT_WINDOW = 60000; // 1 minute
  const MAX_ATTEMPTS = 10; // Max attempts per minute per IP

  function isRateLimited(ip: string): boolean {
    const now = Date.now();
    const record = accessCodeAttempts.get(ip);
    
    if (!record) {
      accessCodeAttempts.set(ip, { count: 1, lastAttempt: now });
      return false;
    }
    
    // Reset if window expired
    if (now - record.lastAttempt > RATE_LIMIT_WINDOW) {
      accessCodeAttempts.set(ip, { count: 1, lastAttempt: now });
      return false;
    }
    
    // Increment and check
    record.count++;
    record.lastAttempt = now;
    return record.count > MAX_ATTEMPTS;
  }

  // Get all field sessions (optionally filter by eventId or meetId query param)
  app.get("/api/field-sessions", async (req, res) => {
    try {
      const { eventId, meetId } = req.query;
      if (eventId && typeof eventId === 'string') {
        const session = await storage.getFieldEventSessionByEvent(eventId);
        return res.json(session ? [session] : []);
      }
      if (meetId && typeof meetId === 'string') {
        const sessions = await storage.getFieldEventSessionsByMeetId(meetId);
        return res.json(sessions);
      }
      // Return all sessions if no filter specified
      const sessions = await storage.getAllFieldEventSessions();
      res.json(sessions);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get field session by ID
  app.get("/api/field-sessions/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid session ID" });
      }
      const session = await storage.getFieldEventSession(id);
      if (!session) {
        return res.status(404).json({ error: "Session not found" });
      }
      res.json(session);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get field session by event ID
  app.get("/api/field-sessions/event/:eventId", async (req, res) => {
    try {
      const { eventId } = req.params;
      const session = await storage.getFieldEventSessionByEvent(eventId);
      res.json(session);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get field session by access code (for officials to join)
  app.get("/api/field-sessions/access/:code", async (req, res) => {
    try {
      // Rate limiting check
      const clientIp = req.ip || req.socket.remoteAddress || 'unknown';
      if (isRateLimited(clientIp)) {
        console.log(`[Rate Limit] Access code attempt blocked for IP: ${clientIp}`);
        return res.status(429).json({ error: "Too many attempts. Please wait a minute and try again." });
      }

      const { code } = req.params;
      const session = await storage.getFieldEventSessionByAccessCode(code);
      if (!session) {
        return res.status(404).json({ error: "Session not found with that access code" });
      }
      res.json(session);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Create field session
  app.post("/api/field-sessions", async (req, res) => {
    try {
      const validated = insertFieldEventSessionSchema.parse(req.body);
      const session = await storage.createFieldEventSession(validated);
      
      // Auto-populate athletes from event entries
      try {
        const entries = await storage.getEntriesByEvent(validated.eventId);
        let orderInFlight = 1;
        for (const entry of entries) {
          await storage.createFieldEventAthlete({
            sessionId: session.id,
            entryId: entry.id,
            flightNumber: 1,
            orderInFlight: orderInFlight++,
            checkInStatus: "pending",
            competitionStatus: "waiting"
          });
        }
        console.log(`[Field Session] Created session ${session.id} with ${entries.length} athletes from entries`);
      } catch (populateError) {
        console.error(`[Field Session] Error populating athletes:`, populateError);
        // Continue - session is still valid even without athletes
      }
      
      res.status(201).json(session);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Update field session
  app.patch("/api/field-sessions/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid session ID" });
      }
      
      // Extract deviceName before validation (not part of session schema)
      const { deviceName, ...sessionData } = req.body;
      
      const oldSession = await storage.getFieldEventSession(id);
      const validated = insertFieldEventSessionSchema.partial().parse(sessionData);
      const session = await storage.updateFieldEventSession(id, validated);
      if (!session) {
        return res.status(404).json({ error: "Session not found" });
      }
      
      // Manage EVT watcher lifecycle
      if (validated.evtFilePath !== undefined) {
        if (validated.evtFilePath) {
          startEVTWatcher(id, validated.evtFilePath);
        } else if (oldSession?.evtFilePath) {
          stopEVTWatcher(id);
        }
      }
      
      // Broadcast field event update (with device name for scoreboard routing)
      broadcastFieldEventUpdate(id, deviceName).catch(console.error);
      
      res.json(session);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });
  
  // Advance to next height (vertical events)
  app.post("/api/field-sessions/:id/advance-height", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid session ID" });
      }
      
      const { deviceName, direction: reqDirection } = req.body || {};
      
      const session = await storage.getFieldEventSession(id);
      if (!session) {
        return res.status(404).json({ error: "Session not found" });
      }
      
      const heights = await storage.getFieldHeights(id);
      if (heights.length === 0) {
        return res.status(400).json({ error: "No heights configured" });
      }
      
      const currentIndex = session.currentHeightIndex || 0;
      const maxIndex = Math.max(...heights.map(h => h.heightIndex));
      
      // Allow direction: 1 for next, -1 for previous
      const direction = reqDirection === -1 ? -1 : 1;
      const newIndex = currentIndex + direction;
      
      if (direction === 1 && newIndex > maxIndex) {
        return res.status(400).json({ error: "Already at last height" });
      }
      if (direction === -1 && newIndex < 0) {
        return res.status(400).json({ error: "Already at first height" });
      }
      
      const updated = await storage.updateFieldEventSession(id, {
        currentHeightIndex: newIndex,
      });
      
      // Broadcast update
      broadcastFieldEventUpdate(id, deviceName).catch(console.error);
      
      res.json({ success: true, currentHeightIndex: newIndex });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Sync athletes from EVT file
  app.post("/api/field-sessions/:id/sync-evt", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid session ID" });
      }
      
      const result = await syncAthletesFromEVT(id);
      
      if (result.errors.length > 0 && result.added === 0) {
        return res.status(400).json({ error: result.errors.join(', '), ...result });
      }
      
      // Broadcast update after sync
      broadcastFieldEventUpdate(id).catch(console.error);
      
      res.json(result);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Delete field session
  app.delete("/api/field-sessions/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid session ID" });
      }
      await storage.deleteFieldEventSession(id);
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get field session with all related data
  app.get("/api/field-sessions/:id/full", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid session ID" });
      }
      const session = await storage.getFieldEventSessionWithDetails(id);
      if (!session) {
        return res.status(404).json({ error: "Session not found" });
      }
      res.json(session);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // ===============================
  // FIELD HEIGHTS ROUTES
  // ===============================

  // Get heights for a session
  app.get("/api/field-sessions/:sessionId/heights", async (req, res) => {
    try {
      const sessionId = parseInt(req.params.sessionId);
      if (isNaN(sessionId)) {
        return res.status(400).json({ error: "Invalid session ID" });
      }
      const heights = await storage.getFieldHeights(sessionId);
      res.json(heights);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Create a single height
  app.post("/api/field-sessions/:sessionId/heights", async (req, res) => {
    try {
      const sessionId = parseInt(req.params.sessionId);
      if (isNaN(sessionId)) {
        return res.status(400).json({ error: "Invalid session ID" });
      }
      const validated = insertFieldHeightSchema.parse({ ...req.body, sessionId });
      const height = await storage.createFieldHeight(validated);
      res.status(201).json(height);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Bulk replace all heights for a session
  app.put("/api/field-sessions/:sessionId/heights", async (req, res) => {
    try {
      const sessionId = parseInt(req.params.sessionId);
      if (isNaN(sessionId)) {
        return res.status(400).json({ error: "Invalid session ID" });
      }
      const { heights } = req.body;
      if (!Array.isArray(heights)) {
        return res.status(400).json({ error: "heights must be an array" });
      }
      const validated = heights.map((h: any, index: number) => 
        insertFieldHeightSchema.parse({ ...h, sessionId, heightIndex: h.heightIndex ?? index })
      );
      const created = await storage.setFieldHeights(sessionId, validated);
      res.json(created);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Update a height
  app.patch("/api/field-heights/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid height ID" });
      }
      const validated = insertFieldHeightSchema.partial().parse(req.body);
      const height = await storage.updateFieldHeight(id, validated);
      if (!height) {
        return res.status(404).json({ error: "Height not found" });
      }
      res.json(height);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Delete a height
  app.delete("/api/field-heights/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid height ID" });
      }
      await storage.deleteFieldHeight(id);
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // ===============================
  // FIELD EVENT ATHLETES ROUTES
  // ===============================

  // Get athletes for a session
  app.get("/api/field-sessions/:sessionId/athletes", async (req, res) => {
    try {
      const sessionId = parseInt(req.params.sessionId);
      if (isNaN(sessionId)) {
        return res.status(400).json({ error: "Invalid session ID" });
      }
      const athletes = await storage.getFieldEventAthletes(sessionId);
      res.json(athletes);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Create field athlete
  app.post("/api/field-sessions/:sessionId/athletes", async (req, res) => {
    try {
      const sessionId = parseInt(req.params.sessionId);
      if (isNaN(sessionId)) {
        return res.status(400).json({ error: "Invalid session ID" });
      }
      const validated = insertFieldEventAthleteSchema.parse({ ...req.body, sessionId });
      const athlete = await storage.createFieldEventAthlete(validated);
      res.status(201).json(athlete);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Update field athlete
  app.patch("/api/field-athletes/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid athlete ID" });
      }
      const validated = insertFieldEventAthleteSchema.partial().parse(req.body);
      const athlete = await storage.updateFieldEventAthlete(id, validated);
      if (!athlete) {
        return res.status(404).json({ error: "Athlete not found" });
      }
      res.json(athlete);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Delete field athlete
  app.delete("/api/field-athletes/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid athlete ID" });
      }
      await storage.deleteFieldEventAthlete(id);
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Advance to next athlete in field event session (auto-advance after mark entry)
  app.post("/api/field-sessions/:sessionId/advance", async (req, res) => {
    try {
      const sessionId = parseInt(req.params.sessionId);
      if (isNaN(sessionId)) {
        return res.status(400).json({ error: "Invalid session ID" });
      }
      const { currentAthleteId } = req.body;
      
      // Get all athletes for this session
      const athletes = await storage.getFieldEventAthletes(sessionId);
      const activeAthletes = athletes
        .filter(a => a.checkInStatus === "checked_in" && a.competitionStatus !== "completed")
        .sort((a, b) => {
          if ((a.flightNumber || 1) !== (b.flightNumber || 1)) {
            return (a.flightNumber || 1) - (b.flightNumber || 1);
          }
          return a.orderInFlight - b.orderInFlight;
        });
      
      // Find current athlete index
      const currentIndex = activeAthletes.findIndex(a => a.id === currentAthleteId);
      
      // Determine next athlete (circular rotation)
      if (activeAthletes.length > 1 && currentIndex !== -1) {
        const nextIndex = (currentIndex + 1) % activeAthletes.length;
        const nextAthlete = activeAthletes[nextIndex];
        
        // Update current athlete status (no longer "up")
        if (currentAthleteId) {
          await storage.updateFieldEventAthlete(currentAthleteId, { competitionStatus: "active" });
        }
        
        // Set next athlete as "up"
        await storage.updateFieldEventAthlete(nextAthlete.id, { competitionStatus: "up" });
        
        // Broadcast field event update
        broadcastFieldEventUpdate(sessionId).catch(console.error);
        
        res.json({ success: true, nextAthleteId: nextAthlete.id });
      } else {
        res.json({ success: true, nextAthleteId: null });
      }
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Check-in field athlete
  app.post("/api/field-athletes/:id/check-in", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid athlete ID" });
      }
      const { deviceName } = req.body || {};
      const athlete = await storage.checkInFieldAthlete(id);
      if (!athlete) {
        return res.status(404).json({ error: "Athlete not found" });
      }
      
      // Broadcast field event update
      broadcastFieldEventUpdate(athlete.sessionId, deviceName).catch(console.error);
      
      res.json(athlete);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Scratch field athlete
  app.post("/api/field-athletes/:id/scratch", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid athlete ID" });
      }
      const { deviceName } = req.body || {};
      const athlete = await storage.scratchFieldAthlete(id);
      if (!athlete) {
        return res.status(404).json({ error: "Athlete not found" });
      }
      
      // Broadcast field event update
      broadcastFieldEventUpdate(athlete.sessionId, deviceName).catch(console.error);
      
      res.json(athlete);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Set opening height for vertical field events
  app.post("/api/field-athletes/:id/opening-height", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid athlete ID" });
      }
      
      const { heightIndex, deviceName } = req.body || {};
      if (typeof heightIndex !== 'number' || heightIndex < 0) {
        return res.status(400).json({ error: "Invalid heightIndex" });
      }
      
      // Get the athlete to find sessionId
      const existingAthlete = await storage.getFieldEventAthlete(id);
      if (!existingAthlete) {
        return res.status(404).json({ error: "Athlete not found" });
      }
      
      const sessionId = existingAthlete.sessionId;
      
      // Update the athlete's startingHeightIndex
      const updatedAthlete = await storage.updateFieldEventAthlete(id, { 
        startingHeightIndex: heightIndex 
      });
      
      // If heightIndex > 0, create pass marks for all heights from 0 to heightIndex-1
      if (heightIndex > 0) {
        // Get existing marks to determine next attempt number
        const existingMarks = await storage.getFieldEventMarks(sessionId);
        const athleteMarks = existingMarks.filter(m => m.athleteId === id);
        let nextAttemptNumber = athleteMarks.length + 1;
        
        // Create 3 pass marks for each height from 0 to heightIndex-1
        for (let hi = 0; hi < heightIndex; hi++) {
          for (let attempt = 1; attempt <= 3; attempt++) {
            await storage.createFieldEventMark({
              sessionId,
              athleteId: id,
              markType: 'pass',
              heightIndex: hi,
              attemptNumber: nextAttemptNumber,
              attemptAtHeight: attempt,
            });
            nextAttemptNumber++;
          }
        }
      }
      
      // Broadcast field event update
      broadcastFieldEventUpdate(sessionId, deviceName).catch(console.error);
      
      res.json({ success: true, athlete: updatedAthlete });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Generate finals - mark top N athletes as finalists
  app.post("/api/field-sessions/:sessionId/generate-finals", async (req, res) => {
    try {
      const sessionId = parseInt(req.params.sessionId);
      if (isNaN(sessionId)) {
        return res.status(400).json({ error: "Invalid session ID" });
      }
      
      const { count } = req.body;
      if (!count || typeof count !== 'number' || count < 1) {
        return res.status(400).json({ error: "Invalid count - must be a positive number" });
      }
      
      // Get all athletes with their marks for this session
      const athletes = await storage.getFieldEventAthletes(sessionId);
      const marks = await storage.getFieldEventMarks(sessionId);
      
      // Calculate best mark for each athlete
      const athleteMarks = new Map<number, number>();
      for (const mark of marks) {
        if (mark.markType === 'mark' && mark.measurement !== null) {
          const current = athleteMarks.get(mark.athleteId) || 0;
          if (mark.measurement > current) {
            athleteMarks.set(mark.athleteId, mark.measurement);
          }
        }
      }
      
      // Filter to active athletes (not DNS/scratched) and sort by best mark (descending)
      const rankedAthletes = athletes
        .filter(a => a.checkInStatus === 'checked_in' && a.competitionStatus !== 'dns')
        .map(a => ({
          ...a,
          bestMark: athleteMarks.get(a.id) || 0
        }))
        .sort((a, b) => b.bestMark - a.bestMark);
      
      // Mark top N as finalists
      const finalists = rankedAthletes.slice(0, count);
      const finalistIds: number[] = [];
      
      // Reset all athletes to non-finalist first
      for (const athlete of athletes) {
        await storage.updateFieldEventAthlete(athlete.id, { 
          isFinalist: false, 
          finalsOrder: null 
        });
      }
      
      // Mark finalists with their order (reversed so last place goes first)
      for (let i = 0; i < finalists.length; i++) {
        const finalist = finalists[i];
        // Reverse order: best mark goes last
        const finalsOrder = finalists.length - i;
        await storage.updateFieldEventAthlete(finalist.id, { 
          isFinalist: true, 
          finalsOrder 
        });
        finalistIds.push(finalist.id);
      }
      
      // Update session to finals mode
      await storage.updateFieldEventSession(sessionId, {
        isInFinals: true,
      });
      
      // Broadcast field event update
      broadcastFieldEventUpdate(sessionId).catch(console.error);
      
      res.json({ 
        success: true, 
        finalistCount: finalists.length,
        finalistIds 
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Delete finals - reset session and athletes back to prelims mode
  app.delete("/api/field-sessions/:sessionId/finals", async (req, res) => {
    try {
      const sessionId = parseInt(req.params.sessionId);
      if (isNaN(sessionId)) {
        return res.status(400).json({ error: "Invalid session ID" });
      }
      
      const { deleteFinalsMarks } = req.body || {};
      
      // Get session info
      const session = await storage.getFieldEventSession(sessionId);
      if (!session) {
        return res.status(404).json({ error: "Session not found" });
      }
      
      // Get all athletes for this session
      const athletes = await storage.getFieldEventAthletes(sessionId);
      
      // Reset all athletes - clear finalist status
      for (const athlete of athletes) {
        await storage.updateFieldEventAthlete(athlete.id, { 
          isFinalist: false, 
          finalsOrder: null 
        });
      }
      
      // If requested, delete marks made during finals (attemptNumber > prelimAttempts)
      if (deleteFinalsMarks) {
        const prelimAttempts = session.prelimAttempts || 3;
        const marks = await storage.getFieldEventMarks(sessionId);
        for (const mark of marks) {
          if (mark.attemptNumber > prelimAttempts) {
            await storage.deleteFieldEventMark(mark.id);
          }
        }
      }
      
      // Update session to exit finals mode
      await storage.updateFieldEventSession(sessionId, {
        isInFinals: false,
      });
      
      // Broadcast field event update
      broadcastFieldEventUpdate(sessionId).catch(console.error);
      
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // ===============================
  // FIELD EVENT MARKS ROUTES
  // ===============================

  // Get marks for a session
  app.get("/api/field-sessions/:sessionId/marks", async (req, res) => {
    try {
      const sessionId = parseInt(req.params.sessionId);
      if (isNaN(sessionId)) {
        return res.status(400).json({ error: "Invalid session ID" });
      }
      const marks = await storage.getFieldEventMarks(sessionId);
      res.json(marks);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get marks by athlete
  app.get("/api/field-athletes/:athleteId/marks", async (req, res) => {
    try {
      const athleteId = parseInt(req.params.athleteId);
      if (isNaN(athleteId)) {
        return res.status(400).json({ error: "Invalid athlete ID" });
      }
      const marks = await storage.getFieldEventMarksByAthlete(athleteId);
      res.json(marks);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Create field mark
  app.post("/api/field-marks", async (req, res) => {
    try {
      // Extract deviceName before validation (not part of mark schema)
      const { deviceName, ...markData } = req.body;
      const validated = insertFieldEventMarkSchema.parse(markData);
      const mark = await storage.createFieldEventMark(validated);
      
      // Handle vertical event progression (high_jump, pole_vault)
      const session = await storage.getFieldEventSession(mark.sessionId);
      if (session && isHeightEvent(session.eventType)) {
        const [allMarks, heights, athletes] = await Promise.all([
          storage.getFieldEventMarks(mark.sessionId),
          storage.getFieldHeights(mark.sessionId),
          storage.getFieldEventAthletes(mark.sessionId)
        ]);
        
        // Check if the athlete who just recorded a mark is now eliminated
        const athleteMarks = allMarks.filter(m => m.athleteId === mark.athleteId);
        const isEliminated = isEliminatedVertical(athleteMarks, heights);
        
        if (isEliminated) {
          // Update athlete's competition status to completed
          await storage.updateFieldEventAthlete(mark.athleteId, {
            competitionStatus: 'completed'
          });
        }
        
        // Check if bar should advance (all active athletes finished at current height)
        const currentHeightIndex = session.currentHeightIndex || 0;
        const activeAthletes = athletes.filter(a => 
          a.competitionStatus === 'competing' || a.competitionStatus === 'checked_in'
        );
        
        // For bar advancement, we need to check if all active athletes have either:
        // 1. Cleared the current height, or
        // 2. Been eliminated (3 consecutive misses), or
        // 3. Passed the current height
        let allFinishedAtCurrentHeight = true;
        
        for (const athlete of activeAthletes) {
          // Re-check elimination status with latest data
          const athleteCurrentMarks = allMarks.filter(m => m.athleteId === athlete.id);
          const athleteEliminated = isEliminatedVertical(athleteCurrentMarks, heights);
          
          if (athleteEliminated) {
            continue; // Eliminated athletes are done at this height
          }
          
          // Check marks at current height
          const marksAtCurrentHeight = athleteCurrentMarks.filter(
            m => m.heightIndex === currentHeightIndex
          );
          
          if (marksAtCurrentHeight.length === 0) {
            // Athlete hasn't attempted yet at this height
            allFinishedAtCurrentHeight = false;
            break;
          }
          
          // Check if athlete cleared, passed, or has 3 misses at this height
          const hasCleared = marksAtCurrentHeight.some(m => m.markType === 'cleared');
          const hasPassed = marksAtCurrentHeight.some(m => m.markType === 'pass');
          const missCount = marksAtCurrentHeight.filter(m => m.markType === 'missed').length;
          
          if (!hasCleared && !hasPassed && missCount < 3) {
            // Athlete still has attempts remaining at this height
            allFinishedAtCurrentHeight = false;
            break;
          }
        }
        
        // Advance bar if all active athletes finished at current height
        if (allFinishedAtCurrentHeight && activeAthletes.length > 0) {
          const nextHeightIndex = currentHeightIndex + 1;
          const hasNextHeight = heights.some(h => h.heightIndex === nextHeightIndex);
          
          if (hasNextHeight) {
            await storage.updateFieldEventSession(mark.sessionId, {
              currentHeightIndex: nextHeightIndex,
              currentAttemptNumber: 1
            });
          }
        }
      }
      
      // Broadcast field event update and auto-export LFF
      broadcastFieldEventUpdate(mark.sessionId, deviceName).catch(console.error);
      autoExportLFF(mark.sessionId).catch(console.error);
      
      res.status(201).json(mark);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Update field mark
  app.patch("/api/field-marks/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid mark ID" });
      }
      // Extract deviceName before validation
      const { deviceName, ...updateData } = req.body;
      const validated = insertFieldEventMarkSchema.partial().parse(updateData);
      const mark = await storage.updateFieldEventMark(id, validated);
      if (!mark) {
        return res.status(404).json({ error: "Mark not found" });
      }
      
      // Broadcast field event update and auto-export LFF
      broadcastFieldEventUpdate(mark.sessionId, deviceName).catch(console.error);
      autoExportLFF(mark.sessionId).catch(console.error);
      
      res.json(mark);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Delete field mark
  app.delete("/api/field-marks/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid mark ID" });
      }
      
      // Get mark to find session ID before deleting
      const existingMark = await storage.getFieldEventMark(id);
      const sessionId = existingMark?.sessionId;
      
      await storage.deleteFieldEventMark(id);
      
      // Broadcast field event update and auto-export LFF if we had a session ID
      if (sessionId) {
        broadcastFieldEventUpdate(sessionId).catch(console.error);
        autoExportLFF(sessionId).catch(console.error);
      }
      
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // ===============================
  // LFF EXPORT ROUTES
  // ===============================

  // Export field session results as LFF file content
  app.get("/api/field-sessions/:id/lff", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid session ID" });
      }
      
      // Use getFieldEventSessionWithDetails to include athletes and marks
      const session = await storage.getFieldEventSessionWithDetails(id);
      if (!session) {
        return res.status(404).json({ error: "Session not found" });
      }
      
      const measurementSystem = (req.query.units === 'english' ? 'English' : 'Metric') as 'Metric' | 'English';
      const content = generateLFFContent(session, measurementSystem);
      
      // Use evtEventNumber for EVT sessions, fall back to eventId or session id
      const eventNum = session.evtEventNumber || session.eventId || session.id;
      res.setHeader('Content-Type', 'text/plain');
      res.setHeader('Content-Disposition', `attachment; filename="${eventNum}-1-01.lff"`);
      res.send(content);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Export field session results to a file on disk
  app.post("/api/field-sessions/:id/export-lff", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid session ID" });
      }
      
      // Use getFieldEventSessionWithDetails to include athletes and marks
      const session = await storage.getFieldEventSessionWithDetails(id);
      if (!session) {
        return res.status(404).json({ error: "Session not found" });
      }
      
      const outputDir = req.body.outputDir || './exports/lff';
      const measurementSystem = (req.body.units === 'english' ? 'English' : 'Metric') as 'Metric' | 'English';
      
      const filePath = await exportSessionToLFF(session, {
        outputDir,
        measurementSystem
      });
      
      res.json({ success: true, filePath });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // ===============================
  // EXTERNAL SCOREBOARD ROUTES
  // ===============================

  // List all external scoreboards
  app.get("/api/external-scoreboards", async (req, res) => {
    try {
      const scoreboards = await storage.getExternalScoreboards();
      res.json(scoreboards);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get single external scoreboard
  app.get("/api/external-scoreboards/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid scoreboard ID" });
      }
      const scoreboard = await storage.getExternalScoreboard(id);
      if (!scoreboard) {
        return res.status(404).json({ error: "Scoreboard not found" });
      }
      res.json(scoreboard);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Create external scoreboard
  app.post("/api/external-scoreboards", async (req, res) => {
    try {
      const validated = insertExternalScoreboardSchema.parse(req.body);
      const scoreboard = await storage.createExternalScoreboard(validated);
      res.status(201).json(scoreboard);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Update external scoreboard
  app.patch("/api/external-scoreboards/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid scoreboard ID" });
      }
      const scoreboard = await storage.updateExternalScoreboard(id, req.body);
      if (!scoreboard) {
        return res.status(404).json({ error: "Scoreboard not found" });
      }
      res.json(scoreboard);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Delete external scoreboard
  app.delete("/api/external-scoreboards/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid scoreboard ID" });
      }
      const deleted = await storage.deleteExternalScoreboard(id);
      if (!deleted) {
        return res.status(404).json({ error: "Scoreboard not found" });
      }
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Start external scoreboard - initiates TCP connection
  app.post("/api/external-scoreboards/:id/start", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid scoreboard ID" });
      }
      const success = await externalScoreboardService.startScoreboard(id);
      if (!success) {
        return res.status(404).json({ error: "Scoreboard not found" });
      }
      const scoreboard = await storage.getExternalScoreboard(id);
      res.json(scoreboard);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Stop external scoreboard - closes TCP connection
  app.post("/api/external-scoreboards/:id/stop", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid scoreboard ID" });
      }
      await externalScoreboardService.stopScoreboard(id);
      const scoreboard = await storage.getExternalScoreboard(id);
      if (!scoreboard) {
        return res.status(404).json({ error: "Scoreboard not found" });
      }
      res.json(scoreboard);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Trigger immediate send to scoreboard
  app.post("/api/external-scoreboards/:id/send", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid scoreboard ID" });
      }
      const scoreboard = await storage.getExternalScoreboard(id);
      if (!scoreboard) {
        return res.status(404).json({ error: "Scoreboard not found" });
      }
      if (scoreboard.sessionId) {
        await broadcastFieldEventUpdate(scoreboard.sessionId);
      }
      res.json({ success: true, message: "Send triggered" });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  return httpServer;
}
